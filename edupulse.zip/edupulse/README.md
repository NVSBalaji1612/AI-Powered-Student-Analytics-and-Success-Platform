# EduPulse AI: Intelligent Student Success & Institutional Intelligence Platform
Independently developed hackathon prototype (KPMG India Challenge 04 style). Not affiliated with or endorsed by KPMG. All data is synthetic.

**What it does:** joins attendance, marks, academic history, LMS, engagement, placement, skills and feedback into one student view; computes a transparent Student Success Score with explained drivers; flags academic and placement risk; groups students into segments with suggested actions; runs a human-reviewed support-case workflow with before/after outcomes; offers a Copilot over verified data and policy documents; records audit events and model-approval decisions; keeps each institution's data isolated.

**Quick start (Windows):** see `docs/LOCAL_SETUP.md`. Short version: `scripts\start.cmd`, then `cd frontend && npm install && npm run dev`, open http://localhost:5173, sign in as `admin@inst-a.demo` with the DEMO_PASSWORD from `.env`. Verify everything with `scripts\run-checks.cmd`.

**Docs:** ARCHITECTURE, SUCCESS_SCORE, SECURITY, AI_GOVERNANCE, API_REFERENCE, TESTING, DEMO_SCRIPT, HACKATHON_PITCH, KNOWN_LIMITATIONS, PROGRESS (all in `docs/`). Read KNOWN_LIMITATIONS before presenting.

**Phase 1 upgrade:** Super Admin user management, first-admin bootstrap (`docs/BOOTSTRAP_SUPER_ADMIN.md`), roles matrix (`docs/ROLES_AND_PERMISSIONS.md`), free local AI (`docs/AI_COPILOT_LOCAL.md`, `scripts\enable-local-ai.cmd`), upgrade roadmap (`docs/UPGRADE_PLAN.md`).
