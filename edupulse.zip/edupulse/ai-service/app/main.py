import os, joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from .synthetic import FEATURES

MODEL_PATH = os.getenv("MODEL_PATH", "model.joblib")
app = FastAPI(title="EduPulse AI service")
_art = None

def art():
    global _art
    if _art is None:
        if not os.path.exists(MODEL_PATH):
            raise HTTPException(503, "No model artifact. Run: python -m app.train")
        _art = joblib.load(MODEL_PATH)
    return _art

class Features(BaseModel):
    model_config = {"extra": "forbid"}  # rejects identifiers / unknown fields
    prev_score_mean: float | None = Field(None, ge=0, le=100)
    score_slope: float | None = Field(None, ge=-50, le=50)
    attendance_pct: float | None = Field(None, ge=0, le=100)
    attendance_slope: float | None = Field(None, ge=-50, le=50)
    assignment_completion: float | None = Field(None, ge=0, le=100)
    missing_score_rate: float | None = Field(None, ge=0, le=1)

@app.get("/health")
def health():
    return {"status": "UP", "model_loaded": os.path.exists(MODEL_PATH)}

@app.post("/v1/predict")
def predict(f: Features):
    a = art(); X = pd.DataFrame([f.model_dump()])[FEATURES]
    p = float(a["chosen_model"].predict_proba(X)[0, 1])
    imp, sc, lr = (s for _, s in a["baseline"].steps)
    z = sc.transform(imp.transform(X))[0] * lr.coef_[0]
    missing = [k for k, v in f.model_dump().items() if v is None]
    factors = sorted(({"feature": k, "contribution": float(c), "direction": "raises" if c > 0 else "lowers"}
                      for k, c in zip(FEATURES, z)), key=lambda d: -abs(d["contribution"]))
    return {"probability": p, "model_version": a["meta"]["version"], "approval_status": a["meta"]["approval_status"],
            "calibrated": a["meta"]["chosen"].startswith("hist"), "factors": factors[:4], "missing_inputs": missing,
            "notes": ["Decision-support signal for human review, not a judgment about the student.",
                      "Contributions show statistical association (baseline logistic model), not causation.",
                      a["meta"]["disclaimer"]]}

@app.get("/v1/model")
def model():
    m = art()["meta"]
    return {"version": m["version"], "trained_at_utc": m["trained_at_utc"], "dataset": m["dataset"], "features": m["features"],
            "chosen": m["chosen"], "evaluation": m["evaluation"], "approval_status": m["approval_status"], "disclaimer": m["disclaimer"]}
