"""Deterministic SYNTHETIC data. Metrics measured on it say nothing about real-world performance."""
import numpy as np, pandas as pd

FEATURES = ["prev_score_mean", "score_slope", "attendance_pct", "attendance_slope",
            "assignment_completion", "missing_score_rate"]

def generate(n=3000, seed=42):
    r = np.random.default_rng(seed)
    df = pd.DataFrame({
        "term": r.integers(1, 9, n),  # used for time-based split only, not a feature
        "prev_score_mean": r.normal(65, 15, n).clip(0, 100),
        "score_slope": r.normal(0, 5, n),
        "attendance_pct": r.beta(8, 2, n) * 100,
        "attendance_slope": r.normal(0, 4, n),
        "assignment_completion": r.beta(6, 2, n) * 100,
        "missing_score_rate": r.beta(1, 8, n),
    })
    z = (-0.06 * (df.prev_score_mean - 60) - 0.25 * df.score_slope - 0.04 * (df.attendance_pct - 75)
         - 0.03 * (df.assignment_completion - 70) + 4 * df.missing_score_rate - 0.8 + r.normal(0, 1, n))
    df["needs_support"] = (1 / (1 + np.exp(-z)) > r.random(n)).astype(int)  # label = NEXT period outcome
    df.loc[r.random(n) < 0.05, "attendance_pct"] = np.nan
    return df
