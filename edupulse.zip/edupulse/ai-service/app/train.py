import json, time, joblib
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.metrics import (roc_auc_score, average_precision_score, precision_score,
                             recall_score, f1_score, confusion_matrix, brier_score_loss)
from .synthetic import generate, FEATURES

def evaluate(m, X, y, thr=0.5):
    p = m.predict_proba(X)[:, 1]; yh = (p >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, yh).ravel()
    return {"roc_auc": roc_auc_score(y, p), "pr_auc": average_precision_score(y, p),
            "precision": precision_score(y, yh), "recall": recall_score(y, yh), "f1": f1_score(y, yh),
            "brier": brier_score_loss(y, p), "fpr": fp / (fp + tn), "fnr": fn / (fn + tp),
            "confusion": [[int(tn), int(fp)], [int(fn), int(tp)]], "positive_rate": float(y.mean())}

def train(path="model.joblib", seed=42):
    df = generate(seed=seed)
    tr, te = df[df.term <= 6], df[df.term > 6]   # time-based split
    Xtr, ytr, Xte, yte = tr[FEATURES], tr.needs_support, te[FEATURES], te.needs_support
    base = make_pipeline(SimpleImputer(strategy="median"), StandardScaler(),
                         LogisticRegression(class_weight="balanced", max_iter=1000)).fit(Xtr, ytr)
    gbm = CalibratedClassifierCV(HistGradientBoostingClassifier(random_state=seed), cv=3, method="isotonic").fit(Xtr, ytr)
    res = {"baseline_logreg": evaluate(base, Xte, yte), "hist_gbm_calibrated": evaluate(gbm, Xte, yte)}
    chosen = "hist_gbm_calibrated" if res["hist_gbm_calibrated"]["pr_auc"] > res["baseline_logreg"]["pr_auc"] else "baseline_logreg"
    meta = {"version": f"demo-{int(time.time())}", "dataset": f"synthetic-v1 seed={seed}", "features": FEATURES,
            "trained_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "chosen": chosen,
            "evaluation": res, "approval_status": "UNAPPROVED_DEMO",
            "disclaimer": "Trained on synthetic data; not evidence of real-world performance."}
    joblib.dump({"baseline": base, "chosen_model": gbm if chosen.startswith("hist") else base, "meta": meta}, path)
    json.dump(meta, open(path + ".meta.json", "w"), indent=2)
    return meta

if __name__ == "__main__":
    for k, v in train()["evaluation"].items():
        print(k, {m: round(x, 3) for m, x in v.items() if m in ("roc_auc", "pr_auc", "precision", "recall", "f1")})
