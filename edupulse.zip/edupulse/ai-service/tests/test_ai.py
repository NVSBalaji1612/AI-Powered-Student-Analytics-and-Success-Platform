import os, pytest
from fastapi.testclient import TestClient
from app.synthetic import generate, FEATURES
from app.train import train

@pytest.fixture(scope="module")
def client(tmp_path_factory):
    p = str(tmp_path_factory.mktemp("m") / "model.joblib")
    meta = train(p)
    from app import main; main._art = None; main.MODEL_PATH = p
    return TestClient(main.app), meta

def test_deterministic_data():
    assert generate(100).equals(generate(100))

def test_no_leakage_or_identifiers():
    assert "needs_support" not in FEATURES and "term" not in FEATURES
    assert not {"name", "phone", "address"} & set(FEATURES)

def test_beats_chance_on_time_split(client):
    assert client[1]["evaluation"]["baseline_logreg"]["roc_auc"] > 0.6

def test_predict_and_explain(client):
    r = client[0].post("/v1/predict", json={"prev_score_mean": 35, "score_slope": -8, "attendance_pct": 50,
        "attendance_slope": -5, "assignment_completion": 30, "missing_score_rate": 0.4}).json()
    assert 0 <= r["probability"] <= 1 and r["factors"] and r["approval_status"] == "UNAPPROVED_DEMO"

def test_missing_inputs_reported(client):
    assert "attendance_pct" in client[0].post("/v1/predict", json={"prev_score_mean": 70}).json()["missing_inputs"]

def test_rejects_identifier_and_bad_range(client):
    assert client[0].post("/v1/predict", json={"name": "x"}).status_code == 422
    assert client[0].post("/v1/predict", json={"attendance_pct": 150}).status_code == 422

def test_model_card_reports_evaluation_and_unapproved_status(client):
    r = client[0].get("/v1/model").json()
    assert r["approval_status"] == "UNAPPROVED_DEMO" and r["features"] and "synthetic" in r["disclaimer"].lower()
    assert 0 < r["evaluation"]["baseline_logreg"]["roc_auc"] <= 1
