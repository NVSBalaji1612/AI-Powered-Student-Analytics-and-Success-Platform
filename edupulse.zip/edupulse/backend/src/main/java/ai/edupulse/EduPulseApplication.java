package ai.edupulse;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication public class EduPulseApplication {
  public static void main(String[] a) { SpringApplication.run(EduPulseApplication.class, a); } }
