package ai.edupulse.admin;
import java.util.Set;
/** Rules for user administration that must hold regardless of who calls the API. */
public final class AdminRules {
  private AdminRules() {}
  /** Roles that an administrator may assign. PLATFORM_ADMIN is deliberately excluded. */
  public static final Set<String> ROLES = Set.of("INSTITUTION_ADMIN", "FACULTY", "MENTOR", "ACADEMIC_ANALYST", "STUDENT", "AUDITOR");
  /** The institution must always keep at least one active Super Admin (INSTITUTION_ADMIN). */
  public static boolean mayRemoveActiveAdmin(int activeAdmins) { return activeAdmins > 1; }
}
