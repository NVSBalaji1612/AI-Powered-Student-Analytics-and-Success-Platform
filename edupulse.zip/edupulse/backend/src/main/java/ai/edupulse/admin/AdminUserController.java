package ai.edupulse.admin;
import ai.edupulse.common.Db;
import ai.edupulse.security.PasswordPolicy;
import ai.edupulse.security.TenantUser;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.*;
import java.util.regex.Pattern;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

/** Super Admin user management, scoped to the caller's institution. Deletion is soft (the row is kept for audit and history). */
@RestController @RequestMapping("/api/v1/admin/users")
public class AdminUserController {
  public record UserRow(Long id, String email, String fullName, String role, boolean active, String createdAt) {}
  public record UserPage(List<UserRow> content, int page, int size, long total) {}
  public record CreateUser(String email, String fullName, String role, String password) {}
  public record UpdateUser(String role, Boolean active, String fullName) {}
  public record NewPassword(String password) {}
  private static final Pattern EMAIL = Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");
  private static final String COLS = "SELECT id, email, full_name, role, active, created_at FROM users WHERE institution_id = ? AND deleted_at IS NULL";
  private final JdbcTemplate jdbc; private final PasswordEncoder enc;
  public AdminUserController(JdbcTemplate jdbc, PasswordEncoder enc) { this.jdbc = jdbc; this.enc = enc; }

  private static ResponseStatusException bad(String m) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, m); }
  private static ResponseStatusException conflict(String m) { return new ResponseStatusException(HttpStatus.CONFLICT, m); }
  private UserRow map(ResultSet rs, int i) throws SQLException {
    Timestamp t = rs.getTimestamp("created_at");
    return new UserRow(rs.getLong("id"), rs.getString("email"), rs.getString("full_name"), rs.getString("role"), rs.getBoolean("active"), t == null ? null : t.toString());
  }
  private UserRow load(long inst, long id) {
    List<UserRow> l = jdbc.query(COLS + " AND id = ?", this::map, inst, id);
    if (l.isEmpty()) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    return l.get(0);
  }
  private long actorId(TenantUser u) {
    List<Long> l = jdbc.queryForList("SELECT id FROM users WHERE email = ?", Long.class, u.getUsername());
    return l.isEmpty() ? -1 : l.get(0);
  }
  private int activeAdmins(long inst) {
    Integer n = jdbc.queryForObject("SELECT COUNT(*) FROM users WHERE institution_id = ? AND role = 'INSTITUTION_ADMIN' AND active = TRUE AND deleted_at IS NULL", Integer.class, inst);
    return n == null ? 0 : n;
  }

  @GetMapping
  UserPage list(@AuthenticationPrincipal TenantUser u, @RequestParam(required = false) String q, @RequestParam(required = false) String role,
                @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "10") int size) {
    int sz = Math.max(1, Math.min(size, 100)), pg = Math.max(0, page);
    StringBuilder filters = new StringBuilder();
    List<Object> args = new ArrayList<>();
    args.add(u.institutionId());
    if (q != null && !q.isBlank()) { filters.append(" AND (email LIKE ? OR full_name LIKE ?)"); String like = "%" + q.trim() + "%"; args.add(like); args.add(like); }
    if (role != null && !role.isBlank()) { if (!AdminRules.ROLES.contains(role)) throw bad("Unknown role"); filters.append(" AND role = ?"); args.add(role); }
    Long total = jdbc.queryForObject("SELECT COUNT(*) FROM users WHERE institution_id = ? AND deleted_at IS NULL" + filters, Long.class, args.toArray());
    List<UserRow> rows = jdbc.query(COLS + filters + " ORDER BY id LIMIT " + sz + " OFFSET " + (pg * sz), this::map, args.toArray());
    return new UserPage(rows, pg, sz, total == null ? 0 : total);
  }

  @PostMapping
  UserRow create(@AuthenticationPrincipal TenantUser u, @RequestBody CreateUser b) {
    if (b == null || b.email() == null || b.role() == null || b.password() == null) throw bad("email, role and password are required");
    String email = b.email().trim().toLowerCase();
    if (email.length() > 254 || !EMAIL.matcher(email).matches()) throw bad("Enter a valid email address");
    if (!AdminRules.ROLES.contains(b.role())) throw bad("Role not allowed");
    String err = PasswordPolicy.validate(b.password());
    if (err != null) throw bad(err);
    String name = b.fullName() == null || b.fullName().isBlank() ? null : b.fullName().trim();
    if (name != null && name.length() > 200) throw bad("Name is too long (max 200 characters)");
    long id;
    try {
      id = Db.insert(jdbc, "INSERT INTO users (institution_id, email, password_hash, role, active, full_name) VALUES (?, ?, ?, ?, TRUE, ?)",
          u.institutionId(), email, enc.encode(b.password()), b.role(), name);
    } catch (DuplicateKeyException e) { throw conflict("That email is already in use (including deleted accounts)"); }
    Db.audit(jdbc, u.institutionId(), u.getUsername(), "USER_CREATED", "user:" + id + " role=" + b.role());
    return load(u.institutionId(), id);
  }

  @PutMapping("/{id}")
  UserRow update(@AuthenticationPrincipal TenantUser u, @PathVariable Long id, @RequestBody UpdateUser b) {
    long inst = u.institutionId();
    UserRow t = load(inst, id);
    if (b == null) throw bad("No changes given");
    String newRole = b.role() == null ? t.role() : b.role();
    boolean newActive = b.active() == null ? t.active() : b.active();
    boolean roleChanged = !newRole.equals(t.role()), activeChanged = newActive != t.active();
    if (roleChanged && !AdminRules.ROLES.contains(newRole)) throw bad("Role not allowed");
    if ((roleChanged || activeChanged) && actorId(u) == t.id()) throw conflict("You cannot change your own role or status");
    boolean removingAdmin = "INSTITUTION_ADMIN".equals(t.role()) && t.active() && (!"INSTITUTION_ADMIN".equals(newRole) || !newActive);
    if (removingAdmin && !AdminRules.mayRemoveActiveAdmin(activeAdmins(inst))) throw conflict("The last active Super Admin cannot be demoted or deactivated");
    String name = b.fullName() == null ? t.fullName() : (b.fullName().isBlank() ? null : b.fullName().trim());
    if (name != null && name.length() > 200) throw bad("Name is too long (max 200 characters)");
    jdbc.update("UPDATE users SET role = ?, active = ?, full_name = ? WHERE id = ? AND institution_id = ? AND deleted_at IS NULL", newRole, newActive, name, id, inst);
    Db.audit(jdbc, inst, u.getUsername(), "USER_UPDATED", "user:" + id + " role=" + newRole + " active=" + newActive);
    return load(inst, id);
  }

  @PostMapping("/{id}/reset-password")
  Map<String, Object> resetPassword(@AuthenticationPrincipal TenantUser u, @PathVariable Long id, @RequestBody NewPassword b) {
    long inst = u.institutionId();
    UserRow t = load(inst, id);
    if (actorId(u) == t.id()) throw conflict("Use Change password for your own account");
    String err = PasswordPolicy.validate(b == null ? null : b.password());
    if (err != null) throw bad(err);
    jdbc.update("UPDATE users SET password_hash = ? WHERE id = ? AND institution_id = ? AND deleted_at IS NULL", enc.encode(b.password()), id, inst);
    Db.audit(jdbc, inst, u.getUsername(), "USER_PASSWORD_RESET", "user:" + id);
    return Map.of("reset", true);
  }

  @DeleteMapping("/{id}")
  Map<String, Object> delete(@AuthenticationPrincipal TenantUser u, @PathVariable Long id) {
    long inst = u.institutionId();
    UserRow t = load(inst, id);
    if (actorId(u) == t.id()) throw conflict("You cannot delete your own account");
    if ("INSTITUTION_ADMIN".equals(t.role()) && t.active() && !AdminRules.mayRemoveActiveAdmin(activeAdmins(inst))) throw conflict("The last active Super Admin cannot be deleted");
    jdbc.update("UPDATE users SET deleted_at = CURRENT_TIMESTAMP, active = FALSE WHERE id = ? AND institution_id = ? AND deleted_at IS NULL", id, inst);
    Db.audit(jdbc, inst, u.getUsername(), "USER_DELETED", "user:" + id);
    return Map.of("deleted", true);
  }
}
