package ai.edupulse.analytics;
import ai.edupulse.security.TenantUser;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/** Institution-level KPIs computed from stored records. Every query is scoped by the authenticated institution. */
@RestController @RequestMapping("/api/v1/analytics")
public class AnalyticsController {
  /** Groups smaller than this are suppressed so individuals cannot be inferred from aggregates. */
  static final int MIN_COHORT = 3;
  record Metric(String label, Double attendancePercent, Double averageScorePercent, int students, boolean suppressed) {}
  record WeekPoint(LocalDate weekStart, Double attendancePercent, int sessions) {}
  record Overview(int activeStudents, Double attendancePercent, Double averageScorePercent, Double missingResultPercent,
                  List<Metric> bySubject, List<Metric> byDepartment, List<WeekPoint> attendanceTrend, List<String> definitions) {}

  private final JdbcTemplate jdbc;
  public AnalyticsController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

  private static Double pct(double part, double whole) { return whole == 0 ? null : Math.round(part * 1000.0 / whole) / 10.0; }

  private Map<String, double[]> grouped(String sql, Object... args) {
    return jdbc.query(sql, (ResultSet rs) -> {
      Map<String, double[]> m = new LinkedHashMap<>();
      while (rs.next()) m.put(rs.getString(1), new double[] {rs.getDouble(2), rs.getDouble(3), rs.getDouble(4)});
      return m;
    }, args);
  }

  private List<Metric> merge(Map<String, double[]> att, Map<String, double[]> sc) {
    List<Metric> out = new ArrayList<>();
    for (String k : new TreeSet<>(att.keySet())) {
      double[] a = att.get(k); double[] s = sc.getOrDefault(k, new double[3]);
      int n = (int) a[2]; boolean sup = n < MIN_COHORT;
      out.add(new Metric(k, sup ? null : pct(a[0], a[0] + a[1]), sup ? null : (s[1] == 0 ? null : Math.round(s[0] * 10.0 / s[1]) / 10.0), n, sup));
    }
    return out;
  }

  @GetMapping("/overview")
  Overview overview(@AuthenticationPrincipal TenantUser u) {
    long inst = u.institutionId();
    Integer students = jdbc.queryForObject("SELECT COUNT(*) FROM student_profiles WHERE institution_id = ?", Integer.class, inst);
    double[] att = jdbc.queryForObject("""
        SELECT SUM(CASE WHEN status = 'PRESENT' THEN 1 ELSE 0 END), SUM(CASE WHEN status = 'ABSENT' THEN 1 ELSE 0 END)
        FROM attendance_records WHERE institution_id = ?""", (rs, i) -> new double[] {rs.getDouble(1), rs.getDouble(2)}, inst);
    double[] sc = jdbc.queryForObject("""
        SELECT SUM(CASE WHEN r.status = 'SCORED' THEN r.marks * 100 / a.max_marks END),
               SUM(CASE WHEN r.status = 'SCORED' THEN 1 ELSE 0 END), SUM(CASE WHEN r.status = 'MISSING' THEN 1 ELSE 0 END)
        FROM assessment_results r JOIN assessments a ON a.id = r.assessment_id WHERE r.institution_id = ?""",
        (rs, i) -> new double[] {rs.getDouble(1), rs.getDouble(2), rs.getDouble(3)}, inst);

    String attBy = """
        SELECT %s, SUM(CASE WHEN ar.status = 'PRESENT' THEN 1 ELSE 0 END), SUM(CASE WHEN ar.status = 'ABSENT' THEN 1 ELSE 0 END),
               COUNT(DISTINCT ar.student_id)
        FROM attendance_records ar JOIN subjects sub ON sub.id = ar.subject_id JOIN student_profiles sp ON sp.id = ar.student_id
        WHERE ar.institution_id = ? GROUP BY 1""";
    String scBy = """
        SELECT %s, SUM(CASE WHEN r.status = 'SCORED' THEN r.marks * 100 / a.max_marks END),
               SUM(CASE WHEN r.status = 'SCORED' THEN 1 ELSE 0 END), COUNT(DISTINCT r.student_id)
        FROM assessment_results r JOIN assessments a ON a.id = r.assessment_id JOIN subjects sub ON sub.id = a.subject_id
        JOIN student_profiles sp ON sp.id = r.student_id WHERE r.institution_id = ? GROUP BY 1""";
    String subj = "sub.code", dept = "COALESCE(sp.department, 'Unassigned')";
    List<Metric> bySubject = merge(grouped(attBy.formatted(subj), inst), grouped(scBy.formatted(subj), inst));
    List<Metric> byDept = merge(grouped(attBy.formatted(dept), inst), grouped(scBy.formatted(dept), inst));

    List<WeekPoint> trend = jdbc.query("""
        SELECT DATE_SUB(class_date, INTERVAL WEEKDAY(class_date) DAY) AS wk,
               SUM(CASE WHEN status = 'PRESENT' THEN 1 ELSE 0 END) AS p, SUM(CASE WHEN status = 'ABSENT' THEN 1 ELSE 0 END) AS a
        FROM attendance_records WHERE institution_id = ? GROUP BY wk ORDER BY wk""",
        (rs, i) -> new WeekPoint(rs.getDate("wk").toLocalDate(), pct(rs.getDouble("p"), rs.getDouble("p") + rs.getDouble("a")),
            (int) (rs.getDouble("p") + rs.getDouble("a"))), inst);

    return new Overview(students == null ? 0 : students, pct(att[0], att[0] + att[1]),
        sc[1] == 0 ? null : Math.round(sc[0] * 10.0 / sc[1]) / 10.0, pct(sc[2], sc[1] + sc[2]), bySubject, byDept, trend,
        List.of("Attendance % = PRESENT / (PRESENT + ABSENT); EXCUSED excluded.",
                "Average score % = mean of marks/max over SCORED results only; MISSING and WITHDRAWN are never treated as zero.",
                "Missing result % = MISSING / (SCORED + MISSING); WITHDRAWN excluded.",
                "Groups with fewer than " + MIN_COHORT + " students are suppressed.",
                "Synthetic demo data; descriptive statistics, not causal claims."));
  }
}
