package ai.edupulse.audit;
import ai.edupulse.security.TenantUser;
import java.util.List;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/** Read-only view of this institution's audit events. The application never updates or deletes audit rows. */
@RestController @RequestMapping("/api/v1/audit")
public class AuditController {
  public record Event(Long id, String actor, String action, String resource, String at) {}
  private final JdbcTemplate jdbc;
  public AuditController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

  @GetMapping("/events")
  List<Event> events(@AuthenticationPrincipal TenantUser u, @RequestParam(required = false) String action, @RequestParam(defaultValue = "100") int limit) {
    int lim = Math.max(1, Math.min(limit, 200));
    String base = "SELECT id, actor, action, resource, at_utc FROM audit_events WHERE institution_id = ?";
    String tail = " ORDER BY id DESC LIMIT " + lim;
    if (action != null && !action.isBlank()) {
      return jdbc.query(base + " AND action = ?" + tail,
          (rs, i) -> new Event(rs.getLong("id"), rs.getString("actor"), rs.getString("action"), rs.getString("resource"), rs.getTimestamp("at_utc").toString()),
          u.institutionId(), action.trim());
    }
    return jdbc.query(base + tail,
        (rs, i) -> new Event(rs.getLong("id"), rs.getString("actor"), rs.getString("action"), rs.getString("resource"), rs.getTimestamp("at_utc").toString()),
        u.institutionId());
  }
}
