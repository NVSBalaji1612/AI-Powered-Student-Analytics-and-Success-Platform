package ai.edupulse.common;
import java.sql.PreparedStatement;
import java.sql.Statement;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
public final class Db {
  private Db() {}
  public static long insert(JdbcTemplate jdbc, String sql, Object... args) {
    KeyHolder kh = new GeneratedKeyHolder();
    jdbc.update(con -> {
      PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
      for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
      return ps;
    }, kh);
    Number k = kh.getKey();
    if (k == null) throw new IllegalStateException("No generated key");
    return k.longValue();
  }
  public static void audit(JdbcTemplate jdbc, long institutionId, String actor, String action, String resource) {
    jdbc.update("INSERT INTO audit_events (institution_id, actor, action, resource) VALUES (?, ?, ?, ?)", institutionId, actor, action, resource);
  }
}
