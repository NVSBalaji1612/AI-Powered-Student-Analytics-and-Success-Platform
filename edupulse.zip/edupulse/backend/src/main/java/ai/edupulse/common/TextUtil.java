package ai.edupulse.common;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
public final class TextUtil {
  private TextUtil() {}
  /** Strict UTF-8 decode: malformed input is rejected, never silently replaced. */
  public static String decodeUtf8(byte[] b) throws CharacterCodingException {
    return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
        .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(b)).toString();
  }
  public static String safeName(String n) {
    if (n == null) return "upload";
    String base = n.replace('\\', '/');
    base = base.substring(base.lastIndexOf('/') + 1).replaceAll("[^A-Za-z0-9._-]", "_");
    return base.isEmpty() ? "upload" : base.substring(0, Math.min(100, base.length()));
  }
}
