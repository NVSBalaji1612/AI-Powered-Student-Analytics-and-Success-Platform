package ai.edupulse.copilot;
import ai.edupulse.common.Db;
import ai.edupulse.security.TenantUser;
import java.net.URI;
import java.util.LinkedHashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

/** Super Admin view of the Copilot model connection. Never returns the API key. Settings still come from .env (see docs/AI_COPILOT_LOCAL.md). */
@RestController @RequestMapping("/api/v1/admin/ai")
public class AiAdminController {
  private final JdbcTemplate jdbc; private final LlmProvider llm; private final String provider, model, baseUrl; private final boolean hasKey;
  public AiAdminController(JdbcTemplate jdbc, @Value("${edupulse.llm.provider:disabled}") String provider, @Value("${edupulse.llm.api-key:}") String key,
                           @Value("${edupulse.llm.model:}") String model, @Value("${edupulse.llm.base-url:}") String baseUrl) {
    this.jdbc = jdbc; this.provider = provider; this.model = model; this.baseUrl = baseUrl; this.hasKey = !key.isBlank();
    LlmProvider p = null;
    if ("anthropic".equalsIgnoreCase(provider) && hasKey) p = new AnthropicProvider(key, model);
    else if ("openai-compatible".equalsIgnoreCase(provider) && !baseUrl.isBlank()) p = new OpenAiCompatibleProvider(baseUrl, key, model);
    this.llm = p;
  }
  private static String trunc(String s, int n) { return s == null ? "" : (s.length() > n ? s.substring(0, n) + "..." : s); }

  @GetMapping("/status")
  Map<String, Object> status() {
    Map<String, Object> m = new LinkedHashMap<>();
    String host = null;
    try { host = URI.create(baseUrl).getHost(); } catch (Exception e) { /* leave null */ }
    m.put("provider", provider); m.put("model", model); m.put("baseUrlHost", host); m.put("apiKeyConfigured", hasKey); m.put("enabled", llm != null);
    m.put("hint", llm != null ? "A model connection is configured. Use Test connection to confirm it works."
        : "No model is connected. For a free local model see docs/AI_COPILOT_LOCAL.md (scripts\\enable-local-ai.cmd).");
    return m;
  }

  @PostMapping("/test")
  Map<String, Object> test(@AuthenticationPrincipal TenantUser u) {
    Map<String, Object> m = new LinkedHashMap<>();
    if (llm == null) { m.put("ok", false); m.put("message", "No model is configured."); return m; }
    try {
      String r = llm.complete("Reply with the single word OK.", "Say OK");
      m.put("ok", true); m.put("message", "The model replied: " + trunc(r.trim(), 80));
    } catch (Exception e) { m.put("ok", false); m.put("message", trunc(e.getMessage(), 300)); }
    Db.audit(jdbc, u.institutionId(), u.getUsername(), "AI_CONNECTION_TEST", "ok=" + m.get("ok"));
    return m;
  }
}
