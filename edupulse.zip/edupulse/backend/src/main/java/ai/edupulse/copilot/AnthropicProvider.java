package ai.edupulse.copilot;
import java.util.List;
import java.util.Map;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;
/** Used only when LLM_PROVIDER=anthropic and LLM_API_KEY is set. Single bounded call, no retries. */
class AnthropicProvider implements LlmProvider {
  private final RestClient http; private final String key; private final String model;
  AnthropicProvider(String key, String model) {
    SimpleClientHttpRequestFactory f = new SimpleClientHttpRequestFactory();
    f.setConnectTimeout(3000); f.setReadTimeout(30000);
    this.http = RestClient.builder().baseUrl("https://api.anthropic.com").requestFactory(f).build();
    this.key = key; this.model = model;
  }
  @Override public String complete(String system, String user) {
    Map<String, Object> body = Map.of("model", model, "max_tokens", 600, "system", system,
        "messages", List.of(Map.of("role", "user", "content", user)));
    Map<String, Object> resp = http.post().uri("/v1/messages").header("x-api-key", key).header("anthropic-version", "2023-06-01")
        .contentType(MediaType.APPLICATION_JSON).body(body).retrieve().body(new ParameterizedTypeReference<Map<String, Object>>() {});
    if (resp != null && resp.get("content") instanceof List<?> l && !l.isEmpty() && l.get(0) instanceof Map<?, ?> m && m.get("text") != null)
      return m.get("text").toString();
    throw new IllegalStateException("Empty model response");
  }
}
