package ai.edupulse.copilot;
import ai.edupulse.common.Db;
import ai.edupulse.common.TextUtil;
import ai.edupulse.security.TenantUser;
import java.io.IOException;
import java.nio.charset.CharacterCodingException;
import java.time.Instant;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

/** Institution knowledge base: text and markdown only. Every query is scoped to the caller's institution. */
@RestController @RequestMapping("/api/v1/documents")
public class DocumentController {
  static final int MAX_BYTES = 200_000;
  public record DocRow(Long id, String title, String uploadedBy, String createdAt, int chunks) {}
  private final JdbcTemplate jdbc;
  public DocumentController(JdbcTemplate jdbc) { this.jdbc = jdbc; }
  private static ResponseStatusException bad(String m) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, m); }

  static List<String> chunk(String text) {
    List<String> out = new ArrayList<>();
    StringBuilder cur = new StringBuilder();
    for (String p : text.split("\\R\\s*\\R")) {
      String t = p.trim();
      if (t.isEmpty()) continue;
      if (cur.length() > 0 && cur.length() + t.length() > 800) { out.add(cur.toString()); cur.setLength(0); }
      if (t.length() > 1500) {
        if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); }
        for (int i = 0; i < t.length(); i += 1500) out.add(t.substring(i, Math.min(t.length(), i + 1500)));
      } else {
        if (cur.length() > 0) cur.append("\n\n");
        cur.append(t);
      }
    }
    if (cur.length() > 0) out.add(cur.toString());
    return out;
  }

  @GetMapping
  List<DocRow> list(@AuthenticationPrincipal TenantUser u) {
    return jdbc.query("SELECT d.id, d.title, d.uploaded_by, d.created_at, (SELECT COUNT(*) FROM knowledge_chunks c WHERE c.document_id = d.id) AS n "
        + "FROM knowledge_documents d WHERE d.institution_id = ? ORDER BY d.id",
        (rs, i) -> new DocRow(rs.getLong("id"), rs.getString("title"), rs.getString("uploaded_by"), rs.getTimestamp("created_at").toString(), rs.getInt("n")),
        u.institutionId());
  }

  @PostMapping @Transactional
  public DocRow upload(@AuthenticationPrincipal TenantUser u, @RequestParam("file") MultipartFile file,
                       @RequestParam(value = "title", required = false) String title) {
    if (file == null || file.isEmpty()) throw bad("No file uploaded");
    String name = TextUtil.safeName(file.getOriginalFilename()).toLowerCase();
    if (!(name.endsWith(".txt") || name.endsWith(".md"))) throw bad("Only .txt and .md files are supported (PDF extraction is not implemented yet)");
    if (file.getSize() > MAX_BYTES) throw bad("File too large (max 200 KB)");
    String text;
    try { text = TextUtil.decodeUtf8(file.getBytes()); }
    catch (CharacterCodingException e) { throw bad("File must be valid UTF-8 text"); }
    catch (IOException e) { throw bad("Could not read the file"); }
    List<String> chunks = chunk(text);
    if (chunks.isEmpty()) throw bad("The document has no text");
    if (chunks.size() > 300) throw bad("Document is too large");
    long inst = u.institutionId();
    String t = (title == null || title.isBlank()) ? name : title.trim();
    if (t.length() > 200) t = t.substring(0, 200);
    long id = Db.insert(jdbc, "INSERT INTO knowledge_documents (institution_id, title, uploaded_by) VALUES (?, ?, ?)", inst, t, u.getUsername());
    List<Object[]> rows = new ArrayList<>();
    for (int i = 0; i < chunks.size(); i++) rows.add(new Object[] {inst, id, i, chunks.get(i)});
    jdbc.batchUpdate("INSERT INTO knowledge_chunks (institution_id, document_id, chunk_index, content) VALUES (?, ?, ?, ?)", rows);
    Db.audit(jdbc, inst, u.getUsername(), "DOCUMENT_UPLOADED", "document:" + id);
    return new DocRow(id, t, u.getUsername(), Instant.now().toString(), chunks.size());
  }

  @DeleteMapping("/{id}")
  Map<String, Object> delete(@AuthenticationPrincipal TenantUser u, @PathVariable Long id) {
    int rows = jdbc.update("DELETE FROM knowledge_documents WHERE id = ? AND institution_id = ?", id, u.institutionId());
    if (rows != 1) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    Db.audit(jdbc, u.institutionId(), u.getUsername(), "DOCUMENT_DELETED", "document:" + id);
    return Map.of("deleted", true);
  }
}
