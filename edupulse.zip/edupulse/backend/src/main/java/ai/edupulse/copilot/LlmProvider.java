package ai.edupulse.copilot;
/** Provider-independent LLM interface. The backend holds credentials; the browser never sees them. */
public interface LlmProvider {
  String complete(String system, String user) throws Exception;
}
