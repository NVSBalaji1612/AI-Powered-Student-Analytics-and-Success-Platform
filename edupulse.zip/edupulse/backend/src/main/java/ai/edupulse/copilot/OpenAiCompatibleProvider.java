package ai.edupulse.copilot;
import java.util.List;
import java.util.Map;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

/**
 * Works with any server that speaks the OpenAI chat API: Google Gemini (OpenAI-compatible endpoint), Groq, OpenRouter free models,
 * and a local Ollama. The key is optional (Ollama needs none). One bounded call, no retries.
 */
class OpenAiCompatibleProvider implements LlmProvider {
  private final RestClient http; private final String key; private final String model;
  OpenAiCompatibleProvider(String baseUrl, String key, String model) {
    SimpleClientHttpRequestFactory f = new SimpleClientHttpRequestFactory();
    f.setConnectTimeout(3000); f.setReadTimeout(120_000);
    String b = baseUrl.endsWith("/") ? baseUrl.substring(0, baseUrl.length() - 1) : baseUrl;
    this.http = RestClient.builder().baseUrl(b).requestFactory(f).build();
    this.key = key; this.model = model;
  }
  @Override public String complete(String system, String user) {
    Map<String, Object> body = Map.of("model", model, "max_tokens", 1500, "temperature", 0.2,
        "messages", List.of(Map.of("role", "system", "content", system), Map.of("role", "user", "content", user)));
    RestClient.RequestBodySpec req = http.post().uri("/chat/completions").contentType(MediaType.APPLICATION_JSON);
    if (key != null && !key.isBlank()) req = req.header("Authorization", "Bearer " + key);
    Map<String, Object> resp = req.body(body).retrieve().body(new ParameterizedTypeReference<Map<String, Object>>() {});
    if (resp != null && resp.get("choices") instanceof List<?> l && !l.isEmpty() && l.get(0) instanceof Map<?, ?> c
        && c.get("message") instanceof Map<?, ?> m && m.get("content") != null) return m.get("content").toString();
    throw new IllegalStateException("Empty model response");
  }
}
