package ai.edupulse.governance;
import ai.edupulse.common.Db;
import ai.edupulse.security.TenantUser;
import java.util.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import org.springframework.web.server.ResponseStatusException;

/** Model card plus a recorded human approval decision per institution and model version. A new model version starts UNREVIEWED. */
@RestController @RequestMapping("/api/v1/governance")
public class GovernanceController {
  public record Decision(String modelVersion, String decision, String reason) {}
  private final JdbcTemplate jdbc; private final RestClient ai;
  public GovernanceController(JdbcTemplate jdbc, @Value("${edupulse.ai-service-url}") String url) {
    this.jdbc = jdbc;
    SimpleClientHttpRequestFactory f = new SimpleClientHttpRequestFactory(); f.setConnectTimeout(2000); f.setReadTimeout(5000);
    this.ai = RestClient.builder().baseUrl(url).requestFactory(f).build();
  }

  private Map<String, Object> model() {
    try { return ai.get().uri("/v1/model").retrieve().body(new ParameterizedTypeReference<Map<String, Object>>() {}); }
    catch (Exception e) { throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "AI service unavailable"); }
  }

  @GetMapping("/model")
  Map<String, Object> get(@AuthenticationPrincipal TenantUser u) {
    Map<String, Object> m = model();
    String version = String.valueOf(m.get("version"));
    List<Map<String, Object>> decisions = jdbc.queryForList("SELECT id, model_version AS modelVersion, decision, reason, decided_by AS decidedBy, decided_at AS decidedAt "
        + "FROM model_decisions WHERE institution_id = ? ORDER BY id DESC LIMIT 20", u.institutionId());
    String status = "UNREVIEWED";
    for (Map<String, Object> d : decisions) if (version.equals(String.valueOf(d.get("modelVersion")))) { status = String.valueOf(d.get("decision")); break; }
    Map<String, Object> out = new LinkedHashMap<>();
    out.put("model", m); out.put("currentStatus", status); out.put("decisions", decisions);
    out.put("notes", List.of("Metrics are measured on synthetic data and are not evidence of real-world performance.",
        "Feature drift and subgroup monitoring are not implemented yet; no outcome labels exist to measure real accuracy.",
        "A decision applies to one model version; a new version must be reviewed again."));
    return out;
  }

  @PostMapping("/model/decision")
  Map<String, Object> decide(@AuthenticationPrincipal TenantUser u, @RequestBody Decision d) {
    if (d == null || d.decision() == null || !Set.of("APPROVED", "REJECTED", "RETIRED").contains(d.decision())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "decision must be APPROVED, REJECTED or RETIRED");
    if (d.reason() == null || d.reason().trim().length() < 10 || d.reason().length() > 500) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "A reason of 10-500 characters is required");
    Map<String, Object> m = model();
    if (d.modelVersion() == null || !d.modelVersion().equals(String.valueOf(m.get("version")))) throw new ResponseStatusException(HttpStatus.CONFLICT, "The running model version changed; reload and review again");
    Db.insert(jdbc, "INSERT INTO model_decisions (institution_id, model_version, decision, reason, decided_by) VALUES (?, ?, ?, ?, ?)",
        u.institutionId(), d.modelVersion(), d.decision(), d.reason().trim(), u.getUsername());
    Db.audit(jdbc, u.institutionId(), u.getUsername(), "MODEL_DECISION_" + d.decision(), "model:" + d.modelVersion());
    return get(u);
  }
}
