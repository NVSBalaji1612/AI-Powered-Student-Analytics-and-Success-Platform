package ai.edupulse.imports;
import java.util.ArrayList;
import java.util.List;
/** Minimal RFC 4180 style parser: quoted fields, escaped quotes, CRLF or LF. Never executes content. */
public final class CsvParser {
  private CsvParser() {}
  public static List<List<String>> parse(String t) {
    List<List<String>> rows = new ArrayList<>();
    List<String> row = new ArrayList<>();
    StringBuilder cur = new StringBuilder();
    boolean q = false;
    for (int i = 0; i < t.length(); i++) {
      char c = t.charAt(i);
      if (q) {
        if (c == '"') {
          if (i + 1 < t.length() && t.charAt(i + 1) == '"') { cur.append('"'); i++; } else q = false;
        } else cur.append(c);
      } else if (c == '"') q = true;
      else if (c == ',') { row.add(cur.toString()); cur.setLength(0); }
      else if (c == '\n' || c == '\r') {
        if (c == '\r' && i + 1 < t.length() && t.charAt(i + 1) == '\n') i++;
        row.add(cur.toString()); cur.setLength(0);
        if (!(row.size() == 1 && row.get(0).isEmpty())) rows.add(row);
        row = new ArrayList<>();
      } else cur.append(c);
    }
    if (q) throw new IllegalArgumentException("unterminated quote");
    if (cur.length() > 0 || !row.isEmpty()) { row.add(cur.toString()); rows.add(row); }
    return rows;
  }
}
