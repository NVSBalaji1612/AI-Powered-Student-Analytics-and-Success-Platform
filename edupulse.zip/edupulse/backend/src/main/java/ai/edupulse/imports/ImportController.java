package ai.edupulse.imports;
import ai.edupulse.common.Db;
import ai.edupulse.common.TextUtil;
import ai.edupulse.security.TenantUser;
import java.io.IOException;
import java.nio.charset.CharacterCodingException;
import java.util.*;
import java.util.regex.Pattern;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

/** Student CSV import: validate, preview, then commit. Existing records are never overwritten. */
@RestController @RequestMapping("/api/v1/imports")
public class ImportController {
  static final int MAX_BYTES = 1_000_000, MAX_ROWS = 2000;
  static final List<String> HEADER = List.of("student_code", "full_name", "department");
  private static final Pattern CODE = Pattern.compile("^[A-Za-z0-9_-]{2,40}$");
  public record RowError(int row, String message) {}
  record Analysis(int total, List<List<String>> valid, List<RowError> errors) {}
  public record Preview(int rowsTotal, int validRows, int rejectedRows, List<RowError> errors, List<List<String>> sample) {}
  public record Result(int imported, int rejected, List<RowError> errors) {}

  private final JdbcTemplate jdbc;
  public ImportController(JdbcTemplate jdbc) { this.jdbc = jdbc; }
  private static ResponseStatusException bad(String m) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, m); }
  private static boolean startsFormula(String s) { return !s.isEmpty() && "=+-@\t\r".indexOf(s.charAt(0)) >= 0; }

  private Analysis analyse(long inst, MultipartFile file) {
    if (file == null || file.isEmpty()) throw bad("No file uploaded");
    if (file.getSize() > MAX_BYTES) throw bad("File too large (max 1 MB)");
    String text;
    try { text = TextUtil.decodeUtf8(file.getBytes()); }
    catch (CharacterCodingException e) { throw bad("File must be valid UTF-8 text"); }
    catch (IOException e) { throw bad("Could not read the file"); }
    if (text.startsWith("\uFEFF")) text = text.substring(1);
    List<List<String>> rows;
    try { rows = CsvParser.parse(text); } catch (IllegalArgumentException e) { throw bad("Malformed CSV: " + e.getMessage()); }
    if (rows.isEmpty()) throw bad("File is empty");
    List<String> head = rows.get(0).stream().map(s -> s.trim().toLowerCase()).toList();
    if (!head.equals(HEADER)) throw bad("Header must be exactly: " + String.join(",", HEADER));
    if (rows.size() - 1 > MAX_ROWS) throw bad("Too many rows (max " + MAX_ROWS + ")");
    Set<String> existing = new HashSet<>(jdbc.queryForList("SELECT student_code FROM student_profiles WHERE institution_id = ?", String.class, inst));
    Set<String> seen = new HashSet<>();
    List<RowError> errors = new ArrayList<>();
    List<List<String>> valid = new ArrayList<>();
    for (int i = 1; i < rows.size(); i++) {
      List<String> r = rows.get(i);
      int line = i + 1;
      if (r.size() != 3) { errors.add(new RowError(line, "Expected 3 columns")); continue; }
      String code = r.get(0).trim(), name = r.get(1).trim(), dept = r.get(2).trim();
      String err = null;
      if (startsFormula(code) || startsFormula(name) || startsFormula(dept)) err = "Cell starts with = + - @ (possible formula injection)";
      else if (!CODE.matcher(code).matches()) err = "student_code must be 2-40 letters, digits, - or _";
      else if (name.isEmpty() || name.length() > 200) err = "full_name is required (max 200 characters)";
      else if (dept.length() > 100) err = "department is too long (max 100 characters)";
      else if (existing.contains(code)) err = "student_code already exists (existing records are never overwritten)";
      else if (!seen.add(code)) err = "Duplicate student_code within the file";
      if (err != null) errors.add(new RowError(line, err)); else valid.add(List.of(code, name, dept));
    }
    return new Analysis(rows.size() - 1, valid, errors);
  }

  @GetMapping("/students/template")
  ResponseEntity<String> template() {
    return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"students_template.csv\"")
        .contentType(MediaType.parseMediaType("text/csv")).body("student_code,full_name,department\nX-001,Example Student,Mathematics\n");
  }

  @PostMapping("/students/preview")
  Preview preview(@AuthenticationPrincipal TenantUser u, @RequestParam("file") MultipartFile file) {
    Analysis a = analyse(u.institutionId(), file);
    return new Preview(a.total(), a.valid().size(), a.errors().size(), a.errors().stream().limit(50).toList(), a.valid().stream().limit(5).toList());
  }

  @PostMapping("/students/commit") @Transactional
  public Result commit(@AuthenticationPrincipal TenantUser u, @RequestParam("file") MultipartFile file) {
    long inst = u.institutionId();
    Analysis a = analyse(inst, file);
    if (!a.valid().isEmpty()) {
      jdbc.batchUpdate("INSERT INTO student_profiles (institution_id, student_code, full_name, department) VALUES (?, ?, ?, ?)",
          a.valid().stream().map(r -> new Object[] {inst, r.get(0), r.get(1), r.get(2).isEmpty() ? null : r.get(2)}).toList());
    }
    jdbc.update("INSERT INTO import_jobs (institution_id, actor, filename, total_rows, imported, rejected) VALUES (?, ?, ?, ?, ?, ?)",
        inst, u.getUsername(), TextUtil.safeName(file.getOriginalFilename()), a.total(), a.valid().size(), a.errors().size());
    Db.audit(jdbc, inst, u.getUsername(), "STUDENT_IMPORT", "imported=" + a.valid().size() + ",rejected=" + a.errors().size());
    return new Result(a.valid().size(), a.errors().size(), a.errors().stream().limit(50).toList());
  }

  @GetMapping
  List<Map<String, Object>> history(@AuthenticationPrincipal TenantUser u) {
    return jdbc.queryForList("SELECT id, actor, filename, total_rows AS totalRows, imported, rejected, created_at AS createdAt "
        + "FROM import_jobs WHERE institution_id = ? ORDER BY id DESC LIMIT 20", u.institutionId());
  }
}
