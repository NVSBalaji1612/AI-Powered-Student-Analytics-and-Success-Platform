package ai.edupulse.imports;
import ai.edupulse.common.Db;
import ai.edupulse.common.TextUtil;
import ai.edupulse.imports.ImportController.RowError;
import ai.edupulse.security.TenantUser;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.charset.CharacterCodingException;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.*;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;

/** CSV import for LMS, placement, skills, feedback and engagement data. Rows reference existing students; existing rows are never overwritten. */
@RestController @RequestMapping("/api/v1/imports")
public class SourceImportController {
  interface RowParser { Object[] parse(List<String> c, Map<String, Long> ids); }
  record Spec(String label, List<String> header, String insertSql, String existsSql, int keyCols, RowParser parser, String example) {}
  record Analysis(int total, List<Object[]> valid, List<RowError> errors) {}
  private static final Map<String, Spec> SPECS = new LinkedHashMap<>();
  private static final Set<String> CATEGORIES = Set.of("EVENT", "CLUB", "HACKATHON", "CERTIFICATION");

  private static BigDecimal num(String s, String name, double min, double max, boolean required) {
    String t = s.trim();
    if (t.isEmpty()) { if (required) throw new IllegalArgumentException(name + " is required"); return null; }
    BigDecimal v;
    try { v = new BigDecimal(t); } catch (NumberFormatException e) { throw new IllegalArgumentException(name + " must be a number"); }
    if (v.doubleValue() < min || v.doubleValue() > max) throw new IllegalArgumentException(name + " must be between " + min + " and " + max);
    return v;
  }
  private static int whole(String s, String name, int min, int max) {
    int v;
    try { v = Integer.parseInt(s.trim()); } catch (NumberFormatException e) { throw new IllegalArgumentException(name + " must be a whole number"); }
    if (v < min || v > max) throw new IllegalArgumentException(name + " must be between " + min + " and " + max);
    return v;
  }
  private static LocalDate date(String s, String name) {
    try { return LocalDate.parse(s.trim()); } catch (DateTimeParseException e) { throw new IllegalArgumentException(name + " must be a date like 2026-09-30"); }
  }
  private static Long student(String code, Map<String, Long> ids) {
    Long id = ids.get(code.trim());
    if (id == null) throw new IllegalArgumentException("Unknown student_code (students must already exist in this institution)");
    return id;
  }

  static {
    SPECS.put("placement", new Spec("Placement readiness", List.of("student_code", "aptitude_score", "coding_score", "mock_interview_score", "assessed_on"),
        "INSERT INTO placement_readiness (institution_id, student_id, aptitude_score, coding_score, mock_interview_score, assessed_on) VALUES (?, ?, ?, ?, ?, ?)",
        "SELECT student_id FROM placement_readiness WHERE institution_id = ?", 1, (c, ids) -> {
          BigDecimal a = num(c.get(1), "aptitude_score", 0, 100, false), k = num(c.get(2), "coding_score", 0, 100, false), m = num(c.get(3), "mock_interview_score", 0, 100, false);
          if (a == null && k == null && m == null) throw new IllegalArgumentException("At least one score is required");
          return new Object[] {student(c.get(0), ids), a, k, m, date(c.get(4), "assessed_on")};
        }, "A-101,70,65,60,2026-09-20"));
    SPECS.put("skills", new Spec("Skills assessments", List.of("student_code", "technical_score", "soft_skill_score", "assessed_on"),
        "INSERT INTO skills_assessments (institution_id, student_id, technical_score, soft_skill_score, assessed_on) VALUES (?, ?, ?, ?, ?)",
        "SELECT student_id FROM skills_assessments WHERE institution_id = ?", 1, (c, ids) -> {
          BigDecimal t = num(c.get(1), "technical_score", 0, 100, false), s = num(c.get(2), "soft_skill_score", 0, 100, false);
          if (t == null && s == null) throw new IllegalArgumentException("At least one score is required");
          return new Object[] {student(c.get(0), ids), t, s, date(c.get(3), "assessed_on")};
        }, "A-101,72,68,2026-09-22"));
    SPECS.put("feedback", new Spec("Feedback", List.of("student_code", "satisfaction", "faculty_feedback", "recorded_on"),
        "INSERT INTO feedback_records (institution_id, student_id, satisfaction, faculty_feedback, recorded_on) VALUES (?, ?, ?, ?, ?)",
        "SELECT CONCAT_WS('|', student_id, recorded_on) FROM feedback_records WHERE institution_id = ?", 2, (c, ids) -> {
          BigDecimal s = num(c.get(1), "satisfaction", 1, 5, false), f = num(c.get(2), "faculty_feedback", 1, 5, false);
          if (s == null && f == null) throw new IllegalArgumentException("At least one rating is required");
          return new Object[] {student(c.get(0), ids), date(c.get(3), "recorded_on"), s, f};
        }, "A-101,4.0,4.5,2026-10-01"));
    SPECS.put("lms", new Spec("LMS activity", List.of("student_code", "week_start", "logins", "assignments_due", "assignments_submitted"),
        "INSERT INTO lms_activity (institution_id, student_id, week_start, logins, assignments_due, assignments_submitted) VALUES (?, ?, ?, ?, ?, ?)",
        "SELECT CONCAT_WS('|', student_id, week_start) FROM lms_activity WHERE institution_id = ?", 2, (c, ids) -> {
          int logins = whole(c.get(2), "logins", 0, 1000), due = whole(c.get(3), "assignments_due", 0, 1000), sub = whole(c.get(4), "assignments_submitted", 0, 1000);
          if (sub > due) throw new IllegalArgumentException("assignments_submitted cannot exceed assignments_due");
          return new Object[] {student(c.get(0), ids), date(c.get(1), "week_start"), logins, due, sub};
        }, "A-101,2026-10-12,4,2,2"));
    SPECS.put("engagement", new Spec("Engagement", List.of("student_code", "category", "title", "occurred_on"),
        "INSERT INTO engagement_records (institution_id, student_id, category, title, occurred_on) VALUES (?, ?, ?, ?, ?)",
        "SELECT CONCAT_WS('|', student_id, category, title, occurred_on) FROM engagement_records WHERE institution_id = ?", 4, (c, ids) -> {
          String cat = c.get(1).trim().toUpperCase(), title = c.get(2).trim();
          if (!CATEGORIES.contains(cat)) throw new IllegalArgumentException("category must be EVENT, CLUB, HACKATHON or CERTIFICATION");
          if (title.isEmpty() || title.length() > 120) throw new IllegalArgumentException("title is required (max 120 characters)");
          return new Object[] {student(c.get(0), ids), cat, title, date(c.get(3), "occurred_on")};
        }, "A-101,CLUB,Robotics Club session,2026-10-05"));
  }

  private final JdbcTemplate jdbc;
  public SourceImportController(JdbcTemplate jdbc) { this.jdbc = jdbc; }
  private static ResponseStatusException bad(String m) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, m); }
  private static Spec spec(String source) {
    Spec s = SPECS.get(source);
    if (s == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Unknown import source");
    return s;
  }
  private static boolean startsFormula(String s) { return !s.isEmpty() && "=+-@\t\r".indexOf(s.charAt(0)) >= 0; }

  private Analysis analyse(long inst, Spec spec, MultipartFile file) {
    if (file == null || file.isEmpty()) throw bad("No file uploaded");
    if (file.getSize() > ImportController.MAX_BYTES) throw bad("File too large (max 1 MB)");
    String text;
    try { text = TextUtil.decodeUtf8(file.getBytes()); }
    catch (CharacterCodingException e) { throw bad("File must be valid UTF-8 text"); }
    catch (IOException e) { throw bad("Could not read the file"); }
    if (text.startsWith("\uFEFF")) text = text.substring(1);
    List<List<String>> rows;
    try { rows = CsvParser.parse(text); } catch (IllegalArgumentException e) { throw bad("Malformed CSV: " + e.getMessage()); }
    if (rows.isEmpty()) throw bad("File is empty");
    if (!rows.get(0).stream().map(s -> s.trim().toLowerCase()).toList().equals(spec.header())) throw bad("Header must be exactly: " + String.join(",", spec.header()));
    if (rows.size() - 1 > ImportController.MAX_ROWS) throw bad("Too many rows (max " + ImportController.MAX_ROWS + ")");
    Map<String, Long> ids = new HashMap<>();
    jdbc.query("SELECT id, student_code FROM student_profiles WHERE institution_id = ?", rs -> { ids.put(rs.getString("student_code"), rs.getLong("id")); }, inst);
    Set<String> existing = new HashSet<>(jdbc.queryForList(spec.existsSql(), String.class, inst));
    Set<String> seen = new HashSet<>();
    List<RowError> errors = new ArrayList<>();
    List<Object[]> valid = new ArrayList<>();
    for (int i = 1; i < rows.size(); i++) {
      List<String> r = rows.get(i);
      int line = i + 1;
      if (r.size() != spec.header().size()) { errors.add(new RowError(line, "Expected " + spec.header().size() + " columns")); continue; }
      if (r.stream().anyMatch(s -> startsFormula(s.trim()))) { errors.add(new RowError(line, "Cell starts with = + - @ (possible formula injection)")); continue; }
      try {
        Object[] p = spec.parser().parse(r, ids);
        StringBuilder k = new StringBuilder();
        for (int j = 0; j < spec.keyCols(); j++) { if (j > 0) k.append('|'); k.append(p[j]); }
        if (existing.contains(k.toString())) errors.add(new RowError(line, "This record already exists (existing data is never overwritten)"));
        else if (!seen.add(k.toString())) errors.add(new RowError(line, "Duplicate record within the file"));
        else valid.add(p);
      } catch (IllegalArgumentException e) { errors.add(new RowError(line, e.getMessage())); }
    }
    return new Analysis(rows.size() - 1, valid, errors);
  }

  @GetMapping("/{source}/template")
  ResponseEntity<String> template(@PathVariable String source) {
    Spec s = spec(source);
    return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + source + "_template.csv\"")
        .contentType(MediaType.parseMediaType("text/csv")).body(String.join(",", s.header()) + "\n" + s.example() + "\n");
  }

  @PostMapping("/{source}/preview")
  ImportController.Preview preview(@AuthenticationPrincipal TenantUser u, @PathVariable String source, @RequestParam("file") MultipartFile file) {
    Analysis a = analyse(u.institutionId(), spec(source), file);
    return new ImportController.Preview(a.total(), a.valid().size(), a.errors().size(), a.errors().stream().limit(50).toList(), List.of());
  }

  @PostMapping("/{source}/commit") @Transactional
  public ImportController.Result commit(@AuthenticationPrincipal TenantUser u, @PathVariable String source, @RequestParam("file") MultipartFile file) {
    long inst = u.institutionId();
    Spec spec = spec(source);
    Analysis a = analyse(inst, spec, file);
    if (!a.valid().isEmpty()) {
      jdbc.batchUpdate(spec.insertSql(), a.valid().stream().map(p -> {
        Object[] r = new Object[p.length + 1];
        r[0] = inst;
        System.arraycopy(p, 0, r, 1, p.length);
        return r;
      }).toList());
    }
    String fname = (source + "-" + TextUtil.safeName(file.getOriginalFilename()));
    jdbc.update("INSERT INTO import_jobs (institution_id, actor, filename, total_rows, imported, rejected) VALUES (?, ?, ?, ?, ?, ?)",
        inst, u.getUsername(), fname.substring(0, Math.min(100, fname.length())), a.total(), a.valid().size(), a.errors().size());
    Db.audit(jdbc, inst, u.getUsername(), "SOURCE_IMPORT", source + ":imported=" + a.valid().size() + ",rejected=" + a.errors().size());
    return new ImportController.Result(a.valid().size(), a.errors().size(), a.errors().stream().limit(50).toList());
  }
}
