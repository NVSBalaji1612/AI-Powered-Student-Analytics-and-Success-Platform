package ai.edupulse.intervention;
import ai.edupulse.common.Db;
import ai.edupulse.prediction.StudentFeatureService;
import ai.edupulse.security.TenantUser;
import ai.edupulse.student.StudentRepository;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

/** Support cases for human follow-up. Advisory risk signals never create or change cases automatically. */
@RestController @RequestMapping("/api/v1")
public class InterventionController {
  static final Set<String> ACTION_TYPES = Set.of("TUTORING", "ASSIGNMENT_SUPPORT", "FACULTY_CONSULTATION",
      "ATTENDANCE_DISCUSSION", "STUDY_PLANNING", "COUNSELLING_REFERRAL", "FOLLOW_UP_MEETING");
  public record CreateCase(Long studentId, String reason) {}
  public record Transition(String to, String note, String assignee) {}
  public record NewAction(String type, String note, LocalDate dueDate) {}
  public record CaseRow(Long id, Long studentId, String studentCode, String reason, String status, String assignedTo, String createdBy,
                        String openedAt, String closedAt, String outcomeNote, Double openAttendance, Double openScore,
                        Double closeAttendance, Double closeScore) {}
  public record ActionRow(Long id, String type, String note, LocalDate dueDate, String status, String completedAt, String createdBy) {}
  public record Detail(CaseRow info, List<ActionRow> actions) {}
  public record Rec(String type, String title, String evidence) {}

  private static final String CASE_SQL = "SELECT c.id, c.student_id, sp.student_code, c.reason, c.status, c.assigned_to, c.created_by, "
      + "c.opened_at, c.closed_at, c.outcome_note, c.open_attendance, c.open_score, c.close_attendance, c.close_score "
      + "FROM intervention_cases c JOIN student_profiles sp ON sp.id = c.student_id WHERE c.institution_id = ?";
  private final JdbcTemplate jdbc; private final StudentRepository students; private final StudentFeatureService features;
  public InterventionController(JdbcTemplate jdbc, StudentRepository students, StudentFeatureService features) {
    this.jdbc = jdbc; this.students = students; this.features = features;
  }

  private static ResponseStatusException bad(String m) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, m); }
  private static ResponseStatusException conflict(String m) { return new ResponseStatusException(HttpStatus.CONFLICT, m); }
  private static Double dbl(ResultSet rs, String c) throws SQLException { BigDecimal b = rs.getBigDecimal(c); return b == null ? null : b.doubleValue(); }
  private static String ts(ResultSet rs, String c) throws SQLException { Timestamp t = rs.getTimestamp(c); return t == null ? null : t.toString(); }

  private CaseRow mapCase(ResultSet rs, int i) throws SQLException {
    return new CaseRow(rs.getLong("id"), rs.getLong("student_id"), rs.getString("student_code"), rs.getString("reason"), rs.getString("status"),
        rs.getString("assigned_to"), rs.getString("created_by"), ts(rs, "opened_at"), ts(rs, "closed_at"), rs.getString("outcome_note"),
        dbl(rs, "open_attendance"), dbl(rs, "open_score"), dbl(rs, "close_attendance"), dbl(rs, "close_score"));
  }

  private CaseRow load(long inst, long id) {
    List<CaseRow> l = jdbc.query(CASE_SQL + " AND c.id = ?", this::mapCase, inst, id);
    if (l.isEmpty()) throw new ResponseStatusException(HttpStatus.NOT_FOUND);
    return l.get(0);
  }

  private Detail detail(long inst, long id) {
    CaseRow c = load(inst, id);
    List<ActionRow> a = jdbc.query("SELECT id, action_type, note, due_date, status, completed_at, created_by FROM intervention_actions "
        + "WHERE case_id = ? AND institution_id = ? ORDER BY id",
        (rs, i) -> new ActionRow(rs.getLong("id"), rs.getString("action_type"), rs.getString("note"),
            rs.getDate("due_date") == null ? null : rs.getDate("due_date").toLocalDate(), rs.getString("status"),
            ts(rs, "completed_at"), rs.getString("created_by")), id, inst);
    return new Detail(c, a);
  }

  @PostMapping("/interventions")
  Detail create(@AuthenticationPrincipal TenantUser u, @RequestBody CreateCase b) {
    if (b == null || b.studentId() == null || b.reason() == null || b.reason().isBlank() || b.reason().length() > 300)
      throw bad("studentId and a reason (max 300 characters) are required");
    long inst = u.institutionId();
    students.findByIdAndInstitutionId(b.studentId(), inst).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    Integer open = jdbc.queryForObject("SELECT COUNT(*) FROM intervention_cases WHERE institution_id = ? AND student_id = ? AND status <> 'RESOLVED'",
        Integer.class, inst, b.studentId());
    if (open != null && open > 0) throw conflict("An open case already exists for this student");
    Map<String, Object> f = features.compute(inst, b.studentId());
    long id = Db.insert(jdbc, "INSERT INTO intervention_cases (institution_id, student_id, reason, status, created_by, open_attendance, open_score) "
        + "VALUES (?, ?, ?, 'NEW', ?, ?, ?)", inst, b.studentId(), b.reason().trim(), u.getUsername(), f.get("attendance_pct"), f.get("prev_score_mean"));
    Db.audit(jdbc, inst, u.getUsername(), "CASE_CREATED", "case:" + id);
    return detail(inst, id);
  }

  @GetMapping("/interventions")
  List<CaseRow> list(@AuthenticationPrincipal TenantUser u, @RequestParam(required = false) String status) {
    if (status != null && !InterventionWorkflow.isValidStatus(status)) throw bad("Unknown status");
    if (status == null) return jdbc.query(CASE_SQL + " ORDER BY c.id DESC LIMIT 100", this::mapCase, u.institutionId());
    return jdbc.query(CASE_SQL + " AND c.status = ? ORDER BY c.id DESC LIMIT 100", this::mapCase, u.institutionId(), status);
  }

  @GetMapping("/interventions/{id}")
  Detail get(@AuthenticationPrincipal TenantUser u, @PathVariable Long id) { return detail(u.institutionId(), id); }

  @PostMapping("/interventions/{id}/transition")
  Detail transition(@AuthenticationPrincipal TenantUser u, @PathVariable Long id, @RequestBody Transition t) {
    long inst = u.institutionId();
    CaseRow c = load(inst, id);
    if (t == null || t.to() == null || !InterventionWorkflow.allowed(c.status(), t.to()))
      throw conflict("Transition " + c.status() + " -> " + (t == null ? null : t.to()) + " is not allowed");
    String note = t.note() == null ? "" : t.note().trim();
    if (note.length() > 1000) throw bad("note too long (max 1000 characters)");
    int rows;
    if ("RESOLVED".equals(t.to())) {
      if (note.isEmpty()) throw bad("A resolution note is required");
      Map<String, Object> f = features.compute(inst, c.studentId());
      rows = jdbc.update("UPDATE intervention_cases SET status = 'RESOLVED', closed_at = CURRENT_TIMESTAMP, outcome_note = ?, "
          + "close_attendance = ?, close_score = ?, version = version + 1 WHERE id = ? AND institution_id = ? AND status = ?",
          note, f.get("attendance_pct"), f.get("prev_score_mean"), id, inst, c.status());
    } else {
      String assignee = c.assignedTo();
      if ("ASSIGNED".equals(t.to())) assignee = (t.assignee() == null || t.assignee().isBlank()) ? u.getUsername() : t.assignee().trim();
      rows = jdbc.update("UPDATE intervention_cases SET status = ?, assigned_to = ?, closed_at = NULL, version = version + 1 "
          + "WHERE id = ? AND institution_id = ? AND status = ?", t.to(), assignee, id, inst, c.status());
    }
    if (rows != 1) throw conflict("The case changed concurrently; reload and retry");
    Db.audit(jdbc, inst, u.getUsername(), "CASE_" + t.to(), "case:" + id);
    return detail(inst, id);
  }

  @PostMapping("/interventions/{id}/actions")
  Detail addAction(@AuthenticationPrincipal TenantUser u, @PathVariable Long id, @RequestBody NewAction a) {
    long inst = u.institutionId();
    CaseRow c = load(inst, id);
    if ("RESOLVED".equals(c.status())) throw conflict("Reopen the case before adding actions");
    if (a == null || a.type() == null || !ACTION_TYPES.contains(a.type())) throw bad("Unknown action type");
    String note = a.note() == null ? null : a.note().trim();
    if (note != null && note.length() > 500) throw bad("note too long (max 500 characters)");
    Db.insert(jdbc, "INSERT INTO intervention_actions (institution_id, case_id, action_type, note, due_date, created_by) VALUES (?, ?, ?, ?, ?, ?)",
        inst, id, a.type(), note, a.dueDate(), u.getUsername());
    Db.audit(jdbc, inst, u.getUsername(), "CASE_ACTION_ADDED", "case:" + id);
    return detail(inst, id);
  }

  @PostMapping("/interventions/{id}/actions/{actionId}/complete")
  Detail complete(@AuthenticationPrincipal TenantUser u, @PathVariable Long id, @PathVariable Long actionId) {
    long inst = u.institutionId();
    int rows = jdbc.update("UPDATE intervention_actions SET status = 'DONE', completed_at = CURRENT_TIMESTAMP "
        + "WHERE id = ? AND case_id = ? AND institution_id = ? AND status = 'OPEN'", actionId, id, inst);
    if (rows != 1) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Open action not found");
    Db.audit(jdbc, inst, u.getUsername(), "CASE_ACTION_DONE", "case:" + id);
    return detail(inst, id);
  }

  @GetMapping("/interventions/metrics")
  Map<String, Object> metrics(@AuthenticationPrincipal TenantUser u) {
    long inst = u.institutionId();
    Map<String, Integer> byStatus = new LinkedHashMap<>();
    for (String s : List.of("NEW", "REVIEWED", "ASSIGNED", "IN_PROGRESS", "FOLLOW_UP", "RESOLVED")) byStatus.put(s, 0);
    jdbc.query("SELECT status, COUNT(*) AS n FROM intervention_cases WHERE institution_id = ? GROUP BY status",
        rs -> { byStatus.put(rs.getString("status"), rs.getInt("n")); }, inst);
    Integer overdue = jdbc.queryForObject("SELECT COUNT(*) FROM intervention_actions WHERE institution_id = ? AND status = 'OPEN' AND due_date < CURRENT_DATE", Integer.class, inst);
    Integer open = jdbc.queryForObject("SELECT COUNT(*) FROM intervention_actions WHERE institution_id = ? AND status = 'OPEN'", Integer.class, inst);
    Integer done = jdbc.queryForObject("SELECT COUNT(*) FROM intervention_actions WHERE institution_id = ? AND status = 'DONE'", Integer.class, inst);
    Double days = jdbc.queryForObject("SELECT AVG(TIMESTAMPDIFF(HOUR, opened_at, closed_at)) / 24 FROM intervention_cases "
        + "WHERE institution_id = ? AND status = 'RESOLVED' AND closed_at IS NOT NULL", Double.class, inst);
    Map<String, Object> outcome = jdbc.queryForObject("SELECT COUNT(*) AS n, AVG(close_attendance - open_attendance) AS d_att, AVG(close_score - open_score) AS d_score "
        + "FROM intervention_cases WHERE institution_id = ? AND status = 'RESOLVED' AND close_attendance IS NOT NULL AND open_attendance IS NOT NULL",
        (rs, i) -> {
          Map<String, Object> m = new LinkedHashMap<>();
          m.put("casesWithBeforeAfter", rs.getInt("n"));
          BigDecimal a = rs.getBigDecimal("d_att"); BigDecimal s = rs.getBigDecimal("d_score");
          m.put("avgAttendanceChangePoints", a == null ? null : Math.round(a.doubleValue() * 10.0) / 10.0);
          m.put("avgScoreChangePoints", s == null ? null : Math.round(s.doubleValue() * 10.0) / 10.0);
          return m;
        }, inst);
    Map<String, Object> out = new LinkedHashMap<>();
    out.put("byStatus", byStatus); out.put("openFollowUps", open); out.put("overdueFollowUps", overdue); out.put("completedFollowUps", done);
    out.put("avgDaysToResolve", days == null ? null : Math.round(days * 10.0) / 10.0); out.put("beforeAfter", outcome);
    out.put("note", "Before/after changes are descriptive. They do not show that an intervention caused the change.");
    return out;
  }

  @GetMapping("/students/{id}/recommendations")
  List<Rec> recommendations(@AuthenticationPrincipal TenantUser u, @PathVariable Long id) {
    long inst = u.institutionId();
    students.findByIdAndInstitutionId(id, inst).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    Map<String, Object> f = features.compute(inst, id);
    Double slope = (Double) f.get("score_slope"), att = (Double) f.get("attendance_pct"),
        miss = (Double) f.get("missing_score_rate"), mean = (Double) f.get("prev_score_mean");
    List<Rec> out = new ArrayList<>();
    if (slope != null && slope <= -3) out.add(new Rec("TUTORING", "Offer subject tutoring", "Scores changed by " + slope + " points per assessment"));
    if (att != null && att < 75) out.add(new Rec("ATTENDANCE_DISCUSSION", "Offer a supportive attendance conversation", "Attendance is " + att + "% (guide: 75%)"));
    if (miss != null && miss >= 0.1) out.add(new Rec("ASSIGNMENT_SUPPORT", "Provide assignment guidance", "Missing results rate is " + Math.round(miss * 100) + "%"));
    if (mean != null && mean < 50) out.add(new Rec("FACULTY_CONSULTATION", "Suggest a faculty consultation", "Average score is " + mean + "%"));
    return out;
  }
}
