package ai.edupulse.intervention;
import java.util.Map;
import java.util.Set;
/** Server-side case workflow: NEW -> REVIEWED -> ASSIGNED -> IN_PROGRESS -> FOLLOW_UP -> RESOLVED (with reopen). */
public final class InterventionWorkflow {
  private InterventionWorkflow() {}
  private static final Map<String, Set<String>> NEXT = Map.of(
      "NEW", Set.of("REVIEWED", "RESOLVED"), "REVIEWED", Set.of("ASSIGNED", "RESOLVED"), "ASSIGNED", Set.of("IN_PROGRESS"),
      "IN_PROGRESS", Set.of("FOLLOW_UP"), "FOLLOW_UP", Set.of("RESOLVED", "IN_PROGRESS"), "RESOLVED", Set.of("IN_PROGRESS"));
  public static boolean allowed(String from, String to) { return NEXT.getOrDefault(from, Set.of()).contains(to); }
  public static boolean isValidStatus(String s) { return NEXT.containsKey(s); }
}
