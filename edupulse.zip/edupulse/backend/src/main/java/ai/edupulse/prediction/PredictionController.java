package ai.edupulse.prediction;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import org.springframework.web.server.ResponseStatusException;
/** Authenticated proxy so the browser never reaches the AI service directly. */
@RestController @RequestMapping("/api/v1/predictions") public class PredictionController {
  private final RestClient ai;
  public PredictionController(@Value("${edupulse.ai-service-url}") String url) {
    var f = new org.springframework.http.client.SimpleClientHttpRequestFactory(); f.setConnectTimeout(2000); f.setReadTimeout(5000);
    ai = RestClient.builder().baseUrl(url).requestFactory(f).build();
  }
  @PostMapping("/what-if") Map<String, Object> predict(@RequestBody Map<String, Double> features) {
    try { return ai.post().uri("/v1/predict").body(features).retrieve().body(new org.springframework.core.ParameterizedTypeReference<>() {}); }
    catch (Exception e) { throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "AI service unavailable or rejected input"); }
  }
}
