package ai.edupulse.prediction;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

/** Builds model inputs from stored records. Only data available at prediction time is used. */
@Service
public class StudentFeatureService {
  private final JdbcTemplate jdbc;
  public StudentFeatureService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

  public static final List<String> NOTES = List.of(
      "prev_score_mean: mean of SCORED results as % of max marks.",
      "score_slope: change in per-date mean score % from first to last assessment date, per step (percentage points).",
      "attendance_pct: PRESENT / (PRESENT + ABSENT) x 100; EXCUSED excluded.",
      "attendance_slope: (attendance % in later half of sessions - earlier half) / 2.",
      "assignment_completion: not collected in this schema yet, so it is sent as missing, never invented.",
      "missing_score_rate: MISSING / (SCORED + MISSING); WITHDRAWN excluded.",
      "These definitions are approximations of the synthetic training features; the demo model is unvalidated for real use.");

  private static Double r2(double v) { return Math.round(v * 100.0) / 100.0; }
  private static double clamp(double v) { return Math.max(-50, Math.min(50, v)); }
  private static double pctOf(List<Boolean> l) { return l.stream().filter(b -> b).count() * 100.0 / l.size(); }

  public Map<String, Object> compute(long inst, long studentId) {
    Map<String, Object> f = new LinkedHashMap<>();
    TreeMap<LocalDate, List<Double>> byDate = new TreeMap<>();
    List<Double> all = new ArrayList<>();
    int[] counts = new int[2];
    jdbc.query("""
        SELECT a.held_on AS d, r.status AS st, r.marks AS m, a.max_marks AS mx
        FROM assessment_results r JOIN assessments a ON a.id = r.assessment_id
        WHERE r.student_id = ? AND r.institution_id = ? ORDER BY a.held_on""",
        rs -> {
          String st = rs.getString("st"); BigDecimal m = rs.getBigDecimal("m"); BigDecimal mx = rs.getBigDecimal("mx");
          if ("SCORED".equals(st) && m != null) {
            double pct = m.doubleValue() * 100.0 / mx.doubleValue();
            all.add(pct);
            byDate.computeIfAbsent(rs.getDate("d").toLocalDate(), k -> new ArrayList<>()).add(pct);
            counts[0]++;
          } else if ("MISSING".equals(st)) {
            counts[1]++;
          }
        }, studentId, inst);
    List<Double> dateMeans = byDate.values().stream().map(l -> l.stream().mapToDouble(Double::doubleValue).average().orElse(0)).toList();

    List<Boolean> present = new ArrayList<>();
    jdbc.query("""
        SELECT status AS st FROM attendance_records
        WHERE student_id = ? AND institution_id = ? AND status IN ('PRESENT', 'ABSENT') ORDER BY class_date, subject_id""",
        rs -> { present.add("PRESENT".equals(rs.getString("st"))); }, studentId, inst);
    int n = present.size();

    f.put("prev_score_mean", all.isEmpty() ? null : r2(all.stream().mapToDouble(Double::doubleValue).average().orElse(0)));
    f.put("score_slope", dateMeans.size() < 2 ? null
        : r2(clamp((dateMeans.get(dateMeans.size() - 1) - dateMeans.get(0)) / (dateMeans.size() - 1))));
    f.put("attendance_pct", n == 0 ? null : r2(pctOf(present)));
    f.put("attendance_slope", n < 4 ? null : r2(clamp((pctOf(present.subList(n / 2, n)) - pctOf(present.subList(0, n / 2))) / 2.0)));
    f.put("assignment_completion", null);
    int scored = counts[0], missing = counts[1];
    f.put("missing_score_rate", scored + missing == 0 ? null : r2(missing * 1.0 / (scored + missing)));
    return f;
  }
}
