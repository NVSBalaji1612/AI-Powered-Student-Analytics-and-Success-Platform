package ai.edupulse.prediction;
import ai.edupulse.security.TenantUser;
import ai.edupulse.student.StudentProfile;
import ai.edupulse.student.StudentRepository;
import java.util.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestClient;
import org.springframework.web.server.ResponseStatusException;

/** Risk signals for support review. Not a decision: every result is advisory and needs human review. */
@RestController @RequestMapping("/api/v1")
public class StudentPredictionController {
  private static final String GUIDANCE = "A support signal for human review, not a judgment about the student or a decision. "
      + "Contributions are associations, not causes. The demo model is trained on synthetic data and is unapproved.";
  private final StudentRepository repo; private final StudentFeatureService features; private final JdbcTemplate jdbc; private final RestClient ai;

  public StudentPredictionController(StudentRepository repo, StudentFeatureService features, JdbcTemplate jdbc,
                                     @Value("${edupulse.ai-service-url}") String url) {
    this.repo = repo; this.features = features; this.jdbc = jdbc;
    SimpleClientHttpRequestFactory f = new SimpleClientHttpRequestFactory(); f.setConnectTimeout(2000); f.setReadTimeout(5000);
    this.ai = RestClient.builder().baseUrl(url).requestFactory(f).build();
  }

  static String band(double p) { return p >= 0.7 ? "REVIEW_RECOMMENDED" : p >= 0.4 ? "MONITOR" : "NO_FLAG"; }

  private Map<String, Object> call(Map<String, Object> f) {
    try {
      return ai.post().uri("/v1/predict").body(f).retrieve().body(new ParameterizedTypeReference<Map<String, Object>>() {});
    } catch (Exception e) {
      throw new ResponseStatusException(HttpStatus.BAD_GATEWAY, "AI service unavailable or rejected input");
    }
  }

  private void audit(TenantUser u, String action, String resource) {
    jdbc.update("INSERT INTO audit_events (institution_id, actor, action, resource) VALUES (?, ?, ?, ?)",
        u.institutionId(), u.getUsername(), action, resource);
  }

  @GetMapping("/students/{id}/prediction")
  Map<String, Object> one(@AuthenticationPrincipal TenantUser u, @PathVariable Long id) {
    StudentProfile s = repo.findByIdAndInstitutionId(id, u.institutionId())
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    Map<String, Object> f = features.compute(u.institutionId(), id);
    Map<String, Object> pred = call(f);
    audit(u, "PREDICTION_VIEW", "student:" + id);
    Map<String, Object> out = new LinkedHashMap<>();
    out.put("studentId", s.getId()); out.put("studentCode", s.getStudentCode());
    out.put("features", f); out.put("featureNotes", StudentFeatureService.NOTES);
    out.put("prediction", pred); out.put("band", band(((Number) pred.get("probability")).doubleValue()));
    out.put("guidance", GUIDANCE);
    return out;
  }

  @GetMapping("/risk/overview")
  List<Map<String, Object>> overview(@AuthenticationPrincipal TenantUser u) {
    List<Map<String, Object>> rows = new ArrayList<>();
    for (StudentProfile s : repo.findByInstitutionId(u.institutionId(), PageRequest.of(0, 50, Sort.by("id"))).getContent()) {
      Map<String, Object> pred = call(features.compute(u.institutionId(), s.getId()));
      double p = ((Number) pred.get("probability")).doubleValue();
      String top = null;
      if (pred.get("factors") instanceof List<?> l && !l.isEmpty() && l.get(0) instanceof Map<?, ?> m) {
        top = m.get("feature") + " (" + m.get("direction") + " risk)";
      }
      Map<String, Object> row = new LinkedHashMap<>();
      row.put("studentId", s.getId()); row.put("studentCode", s.getStudentCode()); row.put("probability", p);
      row.put("band", band(p)); row.put("topFactor", top); row.put("missingInputs", pred.get("missing_inputs"));
      rows.add(row);
    }
    rows.sort((a, b) -> Double.compare((Double) b.get("probability"), (Double) a.get("probability")));
    audit(u, "RISK_OVERVIEW_VIEW", "institution:" + u.institutionId());
    return rows;
  }
}
