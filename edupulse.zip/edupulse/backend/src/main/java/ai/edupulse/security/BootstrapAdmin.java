package ai.edupulse.security;
import ai.edupulse.common.Db;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Creates the very first Super Admin (INSTITUTION_ADMIN) from environment variables, only when no admin exists yet.
 * The password is never logged. Remove BOOTSTRAP_ADMIN_PASSWORD from .env after the first start.
 */
@Component
public class BootstrapAdmin implements ApplicationRunner {
  private static final Logger log = LoggerFactory.getLogger(BootstrapAdmin.class);
  private final JdbcTemplate jdbc; private final PasswordEncoder enc; private final String email, pw, institution;
  public BootstrapAdmin(JdbcTemplate jdbc, PasswordEncoder enc, @Value("${edupulse.bootstrap.email:}") String email,
                        @Value("${edupulse.bootstrap.password:}") String pw, @Value("${edupulse.bootstrap.institution:My Institution}") String institution) {
    this.jdbc = jdbc; this.enc = enc; this.email = email.trim().toLowerCase(); this.pw = pw; this.institution = institution;
  }
  @Override public void run(ApplicationArguments args) {
    if (email.isBlank() || pw.isBlank()) return;
    Integer admins = jdbc.queryForObject("SELECT COUNT(*) FROM users WHERE role = 'INSTITUTION_ADMIN' AND deleted_at IS NULL", Integer.class);
    if (admins != null && admins > 0) { log.info("Bootstrap admin skipped: a Super Admin already exists."); return; }
    String err = PasswordPolicy.validate(pw);
    if (err != null) { log.error("Bootstrap admin NOT created: {}", err); return; }
    try {
      List<Long> ids = jdbc.queryForList("SELECT id FROM institutions ORDER BY id LIMIT 1", Long.class);
      long inst = ids.isEmpty() ? Db.insert(jdbc, "INSERT INTO institutions (name) VALUES (?)", institution) : ids.get(0);
      Db.insert(jdbc, "INSERT INTO users (institution_id, email, password_hash, role, active) VALUES (?, ?, ?, 'INSTITUTION_ADMIN', TRUE)", inst, email, enc.encode(pw));
      Db.audit(jdbc, inst, email, "BOOTSTRAP_ADMIN_CREATED", "first Super Admin");
      log.info("Bootstrap Super Admin created for {}. Remove BOOTSTRAP_ADMIN_PASSWORD from .env now.", email);
    } catch (Exception e) { log.error("Bootstrap admin could not be created: {}", e.getMessage()); }
  }
}
