package ai.edupulse.security;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

/** Dev only: creates demo users in the users table when DEMO_USERS_ENABLED=true. The password comes from the environment, never from source. */
@Component
public class DemoUserSeeder implements ApplicationRunner {
  private static final Logger log = LoggerFactory.getLogger(DemoUserSeeder.class);
  private final JdbcTemplate jdbc; private final PasswordEncoder enc; private final boolean enabled; private final String pw;
  public DemoUserSeeder(JdbcTemplate jdbc, PasswordEncoder enc, @Value("${edupulse.demo-users-enabled}") boolean enabled, @Value("${edupulse.demo-password}") String pw) {
    this.jdbc = jdbc; this.enc = enc; this.enabled = enabled; this.pw = pw;
  }
  @Override public void run(ApplicationArguments args) {
    if (!enabled || pw.length() < 12) return;
    String hash = enc.encode(pw);
    String[][] users = {{"admin@inst-a.demo", "1", "INSTITUTION_ADMIN"}, {"faculty@inst-a.demo", "1", "FACULTY"}, {"auditor@inst-a.demo", "1", "AUDITOR"},
        {"locktest@inst-a.demo", "1", "FACULTY"}, {"admin@inst-b.demo", "2", "INSTITUTION_ADMIN"}, {"faculty@inst-b.demo", "2", "FACULTY"}};
    for (String[] u : users) {
      try {
        jdbc.update("INSERT INTO users (institution_id, email, password_hash, role, active) VALUES (?, ?, ?, ?, TRUE) "
            + "ON DUPLICATE KEY UPDATE password_hash = VALUES(password_hash), role = VALUES(role), institution_id = VALUES(institution_id), active = TRUE",
            Long.parseLong(u[1]), u[0], hash, u[2]);
      } catch (Exception e) { log.warn("Could not seed demo user {}: {}", u[0], e.getMessage()); }
    }
  }
}
