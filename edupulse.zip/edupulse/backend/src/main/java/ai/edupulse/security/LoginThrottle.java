package ai.edupulse.security;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.stereotype.Component;

/** Locks a real account for 15 minutes after 5 bad passwords within 15 minutes. In memory: resets on restart, single instance only. */
@Component
public class LoginThrottle {
  private static final int MAX = 5;
  private static final long WINDOW_MS = 15 * 60_000L, LOCK_MS = 15 * 60_000L;
  private final Map<String, Deque<Long>> fails = new ConcurrentHashMap<>();
  private final Map<String, Long> lockedUntil = new ConcurrentHashMap<>();
  private final JdbcTemplate jdbc;
  public LoginThrottle(JdbcTemplate jdbc) { this.jdbc = jdbc; }

  public boolean isLocked(String email) {
    Long t = lockedUntil.get(email);
    if (t == null) return false;
    if (t < System.currentTimeMillis()) { lockedUntil.remove(email); fails.remove(email); return false; }
    return true;
  }

  @EventListener
  public void onFailure(AuthenticationFailureBadCredentialsEvent ev) {
    String email = String.valueOf(ev.getAuthentication().getName()).trim().toLowerCase();
    List<Long> inst;
    try { inst = jdbc.queryForList("SELECT institution_id FROM users WHERE email = ?", Long.class, email); } catch (Exception e) { return; }
    if (inst.isEmpty()) return; // unknown names are neither tracked nor stored (no unbounded growth)
    long now = System.currentTimeMillis();
    Deque<Long> d = fails.computeIfAbsent(email, k -> new ArrayDeque<>());
    boolean lock = false;
    synchronized (d) {
      while (!d.isEmpty() && now - d.peekFirst() > WINDOW_MS) d.pollFirst();
      d.addLast(now);
      if (d.size() >= MAX) { lockedUntil.put(email, now + LOCK_MS); lock = true; }
    }
    try {
      jdbc.update("INSERT INTO audit_events (institution_id, actor, action, resource) VALUES (?, ?, ?, ?)", inst.get(0), email, lock ? "ACCOUNT_LOCKED" : "LOGIN_FAILED", "login");
    } catch (Exception e) { /* auditing must never block authentication */ }
  }

  @EventListener
  public void onSuccess(AuthenticationSuccessEvent ev) { fails.remove(String.valueOf(ev.getAuthentication().getName()).trim().toLowerCase()); }
}
