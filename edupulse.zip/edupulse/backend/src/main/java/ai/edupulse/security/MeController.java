package ai.edupulse.security;
import ai.edupulse.common.Db;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController @RequestMapping("/api/v1")
public class MeController {
  record Me(String email, String role, long institutionId) {}
  public record PasswordChange(String currentPassword, String newPassword) {}
  private final JdbcTemplate jdbc; private final PasswordEncoder enc;
  public MeController(JdbcTemplate jdbc, PasswordEncoder enc) { this.jdbc = jdbc; this.enc = enc; }

  @GetMapping("/me")
  Me me(@AuthenticationPrincipal TenantUser u) {
    String role = u.getAuthorities().stream().map(GrantedAuthority::getAuthority).map(a -> a.startsWith("ROLE_") ? a.substring(5) : a).findFirst().orElse("NONE");
    return new Me(u.getUsername(), role, u.institutionId());
  }

  @PostMapping("/me/password")
  Map<String, Object> changePassword(@AuthenticationPrincipal TenantUser u, @RequestBody PasswordChange b) {
    if (b == null || b.currentPassword() == null || b.newPassword() == null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "currentPassword and newPassword are required");
    String hash = jdbc.queryForObject("SELECT password_hash FROM users WHERE email = ? AND deleted_at IS NULL", String.class, u.getUsername());
    if (hash == null || !enc.matches(b.currentPassword(), hash)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Current password is incorrect");
    String err = PasswordPolicy.validate(b.newPassword());
    if (err != null) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, err);
    if (b.newPassword().equals(b.currentPassword())) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Choose a different password");
    jdbc.update("UPDATE users SET password_hash = ? WHERE email = ?", enc.encode(b.newPassword()), u.getUsername());
    Db.audit(jdbc, u.institutionId(), u.getUsername(), "PASSWORD_CHANGED", "self");
    return Map.of("changed", true);
  }
}
