package ai.edupulse.security;
/** Minimum password rules for accounts created or changed through the application. */
public final class PasswordPolicy {
  private PasswordPolicy() {}
  /** Returns null when the password is acceptable, otherwise a short message for the user. */
  public static String validate(String p) {
    if (p == null || p.length() < 12) return "Password must be at least 12 characters";
    if (p.length() > 72) return "Password must be at most 72 characters";
    boolean lower = false, upper = false, digit = false;
    for (char c : p.toCharArray()) { if (Character.isLowerCase(c)) lower = true; else if (Character.isUpperCase(c)) upper = true; else if (Character.isDigit(c)) digit = true; }
    if (!(lower && upper && digit)) return "Password needs a lower-case letter, an upper-case letter and a digit";
    return null;
  }
}
