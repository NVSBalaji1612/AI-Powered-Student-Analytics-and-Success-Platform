package ai.edupulse.security;
import java.util.List;
import org.springframework.context.annotation.*;
import org.springframework.http.HttpMethod;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

/** Role rules are enforced here on the server. The UI hiding tabs is cosmetic only. */
@Configuration public class SecurityConfig {
  @Bean PasswordEncoder encoder() { return new BCryptPasswordEncoder(); }

  @Bean SecurityFilterChain chain(HttpSecurity h) throws Exception {
    h.authorizeHttpRequests(a -> a
            .requestMatchers("/actuator/health", "/error").permitAll() // /error must be open or every 400/404/409 turns into 403
            .requestMatchers("/api/v1/me", "/api/v1/me/**").authenticated()
            .requestMatchers("/api/v1/audit/**").hasAnyRole("INSTITUTION_ADMIN", "AUDITOR")
            .requestMatchers("/api/v1/admin/**").hasRole("INSTITUTION_ADMIN")
            .requestMatchers("/api/v1/imports/**", "/api/v1/governance/**").hasRole("INSTITUTION_ADMIN")
            .requestMatchers(HttpMethod.POST, "/api/v1/documents").hasRole("INSTITUTION_ADMIN")
            .requestMatchers(HttpMethod.DELETE, "/api/v1/documents/**").hasRole("INSTITUTION_ADMIN")
            .requestMatchers("/api/**").hasAnyRole("INSTITUTION_ADMIN", "FACULTY", "MENTOR", "ACADEMIC_ANALYST")
            .anyRequest().denyAll())
        .httpBasic(b -> {})
        .csrf(c -> c.ignoringRequestMatchers("/api/**")) // DEV ONLY with httpBasic; enable CSRF tokens when cookie sessions are used
        .headers(x -> x.contentSecurityPolicy(p -> p.policyDirectives("default-src 'self'")));
    return h.build();
  }

  /** Users live in the database (BCrypt hashes). A locked or inactive account cannot authenticate. */
  @Bean UserDetailsService users(JdbcTemplate jdbc, LoginThrottle throttle) {
    return email -> {
      String e = email == null ? "" : email.trim().toLowerCase();
      List<TenantUser> l = jdbc.query("SELECT institution_id, email, password_hash, role, active FROM users WHERE email = ? AND deleted_at IS NULL",
          (rs, i) -> new TenantUser(rs.getString("email"), rs.getString("password_hash"), rs.getLong("institution_id"),
              List.of(new SimpleGrantedAuthority("ROLE_" + rs.getString("role"))), rs.getBoolean("active"), !throttle.isLocked(e)), e);
      if (l.isEmpty()) throw new UsernameNotFoundException("unknown user");
      return l.get(0);
    };
  }
}
