package ai.edupulse.security;
public final class TenantGuard {
  private TenantGuard() {}
  /** Fail closed: a resource of another institution is reported as not found (no existence leak). */
  public static void requireSame(long principalInstitution, long resourceInstitution) {
    if (principalInstitution != resourceInstitution)
      throw new org.springframework.web.server.ResponseStatusException(org.springframework.http.HttpStatus.NOT_FOUND);
  }
}
