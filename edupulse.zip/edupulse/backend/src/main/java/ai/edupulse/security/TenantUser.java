package ai.edupulse.security;
import java.util.Collection;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.User;
/** Authenticated principal; the institution comes from here, never from the request. */
public class TenantUser extends User {
  private final long institutionId;
  public TenantUser(String u, String p, long inst, Collection<? extends GrantedAuthority> a) { super(u, p, a); institutionId = inst; }
  public TenantUser(String u, String p, long inst, Collection<? extends GrantedAuthority> a, boolean enabled, boolean nonLocked) {
    super(u, p, enabled, true, true, nonLocked, a); institutionId = inst;
  }
  public long institutionId() { return institutionId; }
}
