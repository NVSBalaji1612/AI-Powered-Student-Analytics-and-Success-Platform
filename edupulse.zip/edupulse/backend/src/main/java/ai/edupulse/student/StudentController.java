package ai.edupulse.student;
import ai.edupulse.security.TenantUser;
import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
@RestController @RequestMapping("/api/v1/students") public class StudentController {
  record StudentDto(Long id, String studentCode, String fullName, String department) {}
  private final StudentRepository repo; public StudentController(StudentRepository r) { repo = r; }
  @GetMapping Page<StudentDto> list(@AuthenticationPrincipal TenantUser u, @RequestParam(defaultValue = "0") int page, @RequestParam(defaultValue = "20") int size) {
    return repo.findByInstitutionId(u.institutionId(), PageRequest.of(page, Math.min(size, 100), Sort.by("id"))).map(this::dto);
  }
  @GetMapping("/{id}") StudentDto get(@AuthenticationPrincipal TenantUser u, @PathVariable Long id) {
    return repo.findByIdAndInstitutionId(id, u.institutionId()).map(this::dto).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
  }
  private StudentDto dto(StudentProfile s) { return new StudentDto(s.getId(), s.getStudentCode(), s.getFullName(), s.getDepartment()); }
}
