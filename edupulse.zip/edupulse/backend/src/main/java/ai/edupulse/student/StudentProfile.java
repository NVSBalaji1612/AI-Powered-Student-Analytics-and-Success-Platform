package ai.edupulse.student;
import jakarta.persistence.*;
@Entity @Table(name = "student_profiles") public class StudentProfile {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) Long id;
  @Column(name = "institution_id") Long institutionId;
  @Column(name = "student_code") String studentCode;
  @Column(name = "full_name") String fullName; String department; @Version Long version;
  public Long getId() { return id; } public Long getInstitutionId() { return institutionId; }
  public String getStudentCode() { return studentCode; } public String getFullName() { return fullName; } public String getDepartment() { return department; }
}
