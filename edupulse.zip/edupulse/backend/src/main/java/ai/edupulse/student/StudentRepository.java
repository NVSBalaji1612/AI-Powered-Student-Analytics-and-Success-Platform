package ai.edupulse.student;
import java.util.Optional;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.JpaRepository;
public interface StudentRepository extends JpaRepository<StudentProfile, Long> {
  Optional<StudentProfile> findByIdAndInstitutionId(Long id, Long institutionId); // tenant-scoped lookup
  Page<StudentProfile> findByInstitutionId(Long institutionId, Pageable p);
}
