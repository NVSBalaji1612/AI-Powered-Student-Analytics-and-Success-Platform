package ai.edupulse.student;
import ai.edupulse.security.TenantUser;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

/** Per-student attendance and marks. Every query is scoped by the authenticated institution. */
@RestController @RequestMapping("/api/v1/students")
public class StudentSummaryController {
  record SubjectAttendance(String subjectCode, String subjectName, int present, int absent, Double percent) {}
  record ResultRow(String subjectCode, String assessment, BigDecimal maxMarks, BigDecimal marks, String status, LocalDate heldOn) {}
  record Summary(Long studentId, String studentCode, String fullName, List<SubjectAttendance> attendance,
                 Double overallAttendancePercent, List<ResultRow> results, Double averageScorePercent, List<String> definitions) {}

  private final StudentRepository repo; private final JdbcTemplate jdbc;
  public StudentSummaryController(StudentRepository repo, JdbcTemplate jdbc) { this.repo = repo; this.jdbc = jdbc; }

  private static Double pct(double part, double whole) { return whole == 0 ? null : Math.round(part * 1000.0 / whole) / 10.0; }

  @GetMapping("/{id}/summary")
  Summary summary(@AuthenticationPrincipal TenantUser u, @PathVariable Long id) {
    StudentProfile s = repo.findByIdAndInstitutionId(id, u.institutionId())
        .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    long inst = u.institutionId();
    List<SubjectAttendance> att = jdbc.query("""
        SELECT sub.code AS code, sub.name AS name,
               SUM(CASE WHEN ar.status = 'PRESENT' THEN 1 ELSE 0 END) AS present_count,
               SUM(CASE WHEN ar.status = 'ABSENT' THEN 1 ELSE 0 END) AS absent_count
        FROM attendance_records ar JOIN subjects sub ON sub.id = ar.subject_id
        WHERE ar.student_id = ? AND ar.institution_id = ?
        GROUP BY sub.id, sub.code, sub.name ORDER BY sub.code""",
        (rs, i) -> {
          int p = rs.getInt("present_count"), a = rs.getInt("absent_count");
          return new SubjectAttendance(rs.getString("code"), rs.getString("name"), p, a, pct(p, p + a));
        }, id, inst);
    int totalP = att.stream().mapToInt(SubjectAttendance::present).sum();
    int totalA = att.stream().mapToInt(SubjectAttendance::absent).sum();
    List<ResultRow> results = jdbc.query("""
        SELECT sub.code AS code, a.name AS name, a.max_marks AS max_marks, r.marks AS marks, r.status AS status, a.held_on AS held_on
        FROM assessment_results r JOIN assessments a ON a.id = r.assessment_id JOIN subjects sub ON sub.id = a.subject_id
        WHERE r.student_id = ? AND r.institution_id = ? ORDER BY a.held_on, sub.code""",
        (rs, i) -> new ResultRow(rs.getString("code"), rs.getString("name"), rs.getBigDecimal("max_marks"),
            rs.getBigDecimal("marks"), rs.getString("status"), rs.getDate("held_on").toLocalDate()), id, inst);
    double sum = 0; int n = 0;
    for (ResultRow r : results) {
      if ("SCORED".equals(r.status()) && r.marks() != null) { sum += r.marks().doubleValue() * 100.0 / r.maxMarks().doubleValue(); n++; }
    }
    return new Summary(s.getId(), s.getStudentCode(), s.getFullName(), att, pct(totalP, totalP + totalA), results,
        n == 0 ? null : Math.round(sum * 10.0 / n) / 10.0,
        List.of("Attendance % = PRESENT / (PRESENT + ABSENT); EXCUSED sessions are excluded.",
                "Average score % = mean of marks/max over SCORED results only; MISSING and WITHDRAWN are never counted as zero.",
                "Synthetic demo data."));
  }
}
