package ai.edupulse.success;
import static ai.edupulse.success.SuccessScoreService.*;
import ai.edupulse.common.Db;
import ai.edupulse.security.TenantUser;
import java.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

/** Dashboard APIs for the Student Success Score, risk flags, segments, explanations and data quality. All scoped to the caller's institution. */
@RestController @RequestMapping("/api/v1/success")
public class SuccessController {
  static final int MIN_COHORT = 3;
  public record Row(Long id, String code, String name, String department, Double successScore, Double completeness, String segment,
                    String segmentLabel, String academicRisk, String placementRisk, Map<String, Double> components) {}
  public record Bucket(String label, int count) {}
  public record SegmentCount(String code, String label, int count, String action) {}
  public record DeptRow(String department, int students, Double avgSuccess, boolean suppressed) {}
  public record CompMean(String code, String label, double weight, Double mean) {}
  public record Week(String weekStart, Double avgLogins, Double completionPercent) {}
  public record Summary(int students, Double avgSuccess, int highAcademicRisk, int highPlacementRisk, Double avgCompletenessPercent) {}
  public record Overview(Summary summary, List<Bucket> distribution, List<SegmentCount> segments, List<DeptRow> departments, List<CompMean> components,
                         List<Row> students, List<Week> lmsTrend, List<String> departmentsAvailable, Map<String, Object> method) {}
  public record Driver(String code, String label, double weight, Double normalisedWeight, Double score, Double institutionMean, Double points, Double deltaPoints) {}
  public record Detail(Row row, String suggestedAction, List<Driver> drivers, List<String> missingComponents, List<Map<String, Object>> engagement,
                       List<Map<String, Object>> lmsWeeks, Map<String, Object> placement, List<String> notes) {}

  private final SuccessScoreService svc; private final JdbcTemplate jdbc;
  public SuccessController(SuccessScoreService svc, JdbcTemplate jdbc) { this.svc = svc; this.jdbc = jdbc; }

  private static Double n(double v) { return Double.isNaN(v) ? null : Math.round(v * 10.0) / 10.0; }

  private static Row row(Scored s) {
    Map<String, Double> comps = new LinkedHashMap<>();
    for (int i = 0; i < NAMES.length; i++) comps.put(NAMES[i], n(s.comp()[i]));
    return new Row(s.id(), s.code(), s.name(), s.department(), n(s.score()), n(s.completeness() * 100), s.segment(),
        SEGMENT_LABELS.get(s.segment()), s.academicRisk(), s.placementRisk(), comps);
  }

  @GetMapping("/overview")
  Overview overview(@AuthenticationPrincipal TenantUser u, @RequestParam(required = false) String department, @RequestParam(required = false) String segment) {
    long inst = u.institutionId();
    if (segment != null && !segment.isBlank() && !SEGMENT_LABELS.containsKey(segment)) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Unknown segment");
    List<Scored> all = svc.computeAll(inst);
    List<Scored> scoped = all.stream().filter(s -> department == null || department.isBlank() || department.equalsIgnoreCase(s.department())).toList();

    int hiAcad = (int) scoped.stream().filter(s -> "HIGH".equals(s.academicRisk())).count();
    int hiPlc = (int) scoped.stream().filter(s -> "HIGH".equals(s.placementRisk())).count();
    Summary summary = new Summary(scoped.size(), n(SuccessScoreService.mean(scoped.stream().mapToDouble(Scored::score).toArray())), hiAcad, hiPlc,
        n(SuccessScoreService.mean(scoped.stream().mapToDouble(Scored::completeness).toArray()) * 100));

    int[] buckets = new int[4];
    for (Scored s : scoped) buckets[s.score() < 40 ? 0 : s.score() < 60 ? 1 : s.score() < 80 ? 2 : 3]++;
    List<Bucket> dist = List.of(new Bucket("0-39", buckets[0]), new Bucket("40-59", buckets[1]), new Bucket("60-79", buckets[2]), new Bucket("80-100", buckets[3]));

    List<SegmentCount> segs = new ArrayList<>();
    for (String code : SEGMENT_LABELS.keySet())
      segs.add(new SegmentCount(code, SEGMENT_LABELS.get(code), (int) scoped.stream().filter(s -> s.segment().equals(code)).count(), SEGMENT_ACTIONS.get(code)));

    Map<String, List<Scored>> byDept = new TreeMap<>();
    for (Scored s : all) byDept.computeIfAbsent(s.department(), k -> new ArrayList<>()).add(s);
    List<DeptRow> depts = new ArrayList<>();
    for (Map.Entry<String, List<Scored>> e : byDept.entrySet()) {
      boolean sup = e.getValue().size() < MIN_COHORT;
      depts.add(new DeptRow(e.getKey(), e.getValue().size(), sup ? null : n(SuccessScoreService.mean(e.getValue().stream().mapToDouble(Scored::score).toArray())), sup));
    }

    double[] means = SuccessScoreService.componentMeans(scoped);
    List<CompMean> comps = new ArrayList<>();
    for (int i = 0; i < NAMES.length; i++) comps.add(new CompMean(NAMES[i], LABELS[i], W[i], n(means[i])));

    List<Row> students = scoped.stream().filter(s -> segment == null || segment.isBlank() || s.segment().equals(segment))
        .sorted(Comparator.comparingDouble(Scored::score)).map(SuccessController::row).toList();

    List<Week> trend = jdbc.query("SELECT week_start, AVG(logins) AS l, SUM(assignments_submitted) AS s, SUM(assignments_due) AS d FROM lms_activity "
        + "WHERE institution_id = ? GROUP BY week_start ORDER BY week_start",
        (rs, i) -> new Week(rs.getDate("week_start").toString(), n(rs.getDouble("l")), rs.getDouble("d") == 0 ? null : n(rs.getDouble("s") * 100 / rs.getDouble("d"))), inst);

    Map<String, Object> method = new LinkedHashMap<>();
    List<Map<String, Object>> weights = new ArrayList<>();
    for (int i = 0; i < NAMES.length; i++) weights.add(Map.of("code", NAMES[i], "label", LABELS[i], "weight", W[i]));
    method.put("weights", weights);
    method.put("definitions", List.of(
        "Success Score = weighted mean of the available indicator groups (0-100). Missing groups are skipped and weights re-normalised; completeness shows the weight available.",
        "Academic = mean(average assessment %, CGPA x 10) minus 5 points per backlog, limited to 0-100. Missing marks are never counted as zero.",
        "Attendance = PRESENT / (PRESENT + ABSENT); excused sessions excluded.",
        "LMS = mean(assignment completion %, login activity where 5+ logins a week = 100).",
        "Co-curricular = points (hackathon and certification 2, event and club 1) capped at 8, scaled to 100; no record counts as 0.",
        "Placement readiness = mean of available aptitude, coding and mock interview scores. Skills = mean of technical and soft skill scores.",
        "Feedback = mean of student satisfaction and faculty feedback, rescaled from 1-5 to 0-100.",
        "Academic risk: HIGH if academic < 50 or attendance < 65; MEDIUM if academic < 65 or attendance < 75. Placement risk: HIGH < 40, MEDIUM < 55.",
        "Segments are assigned in order: score < 50, then the rules shown per segment. They are descriptive, not judgments about a student's potential.",
        "Demo data is synthetic. Weights and thresholds are configurable defaults, not validated findings."));
    return new Overview(summary, dist, segs, depts, comps, students, trend, new ArrayList<>(byDept.keySet()), method);
  }

  @GetMapping("/students/{id}")
  Detail detail(@AuthenticationPrincipal TenantUser u, @PathVariable Long id) {
    long inst = u.institutionId();
    List<Scored> all = svc.computeAll(inst);
    Scored s = all.stream().filter(x -> x.id() == id).findFirst().orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND));
    double[] means = SuccessScoreService.componentMeans(all);
    List<Driver> drivers = new ArrayList<>(); List<String> missing = new ArrayList<>();
    for (int i = 0; i < NAMES.length; i++) {
      double c = s.comp()[i];
      if (Double.isNaN(c)) { missing.add(LABELS[i]); continue; }
      double nw = W[i] / s.completeness();
      drivers.add(new Driver(NAMES[i], LABELS[i], W[i], n(nw * 100), n(c), n(means[i]), n(nw * c), n(nw * (c - means[i]))));
    }
    drivers.sort(Comparator.comparingDouble(d -> d.deltaPoints() == null ? 0 : d.deltaPoints()));
    List<Map<String, Object>> eng = jdbc.queryForList("SELECT category, title, occurred_on AS occurredOn FROM engagement_records WHERE student_id = ? AND institution_id = ? ORDER BY occurred_on DESC LIMIT 20", id, inst);
    List<Map<String, Object>> weeks = jdbc.queryForList("SELECT week_start AS weekStart, logins, assignments_due AS due, assignments_submitted AS submitted FROM lms_activity WHERE student_id = ? AND institution_id = ? ORDER BY week_start", id, inst);
    List<Map<String, Object>> pl = jdbc.queryForList("SELECT aptitude_score AS aptitude, coding_score AS coding, mock_interview_score AS mockInterview FROM placement_readiness WHERE student_id = ? AND institution_id = ?", id, inst);
    Db.audit(jdbc, inst, u.getUsername(), "SUCCESS_SCORE_VIEW", "student:" + id);
    return new Detail(row(s), SEGMENT_ACTIONS.get(s.segment()), drivers, missing, eng, weeks, pl.isEmpty() ? Map.of() : pl.get(0),
        List.of("Drivers show how far each indicator sits above or below the institution average, weighted by importance. This is association, not cause.",
                "A risk flag is a prompt for a supportive human conversation, not a judgment about the student.",
                "Synthetic demo data."));
  }

  @GetMapping("/data-quality")
  List<Map<String, Object>> quality(@AuthenticationPrincipal TenantUser u) {
    long inst = u.institutionId();
    Integer total = jdbc.queryForObject("SELECT COUNT(*) FROM student_profiles WHERE institution_id = ?", Integer.class, inst);
    int t = total == null ? 0 : total;
    String[][] sources = {
        {"Attendance records", "attendance_records", ""}, {"Assessment marks (scored)", "assessment_results", " AND status = 'SCORED'"},
        {"Academic history (CGPA, backlogs)", "student_academic", ""}, {"LMS activity", "lms_activity", ""},
        {"Engagement (events, clubs, hackathons, certifications)", "engagement_records", ""}, {"Placement readiness", "placement_readiness", ""},
        {"Skills assessments", "skills_assessments", ""}, {"Feedback", "feedback_records", ""}};
    List<Map<String, Object>> out = new ArrayList<>();
    for (String[] src : sources) {
      Integer have = jdbc.queryForObject("SELECT COUNT(DISTINCT student_id) FROM " + src[1] + " WHERE institution_id = ?" + src[2], Integer.class, inst);
      int h = have == null ? 0 : have;
      Map<String, Object> m = new LinkedHashMap<>();
      m.put("source", src[0]); m.put("studentsWithData", h); m.put("totalStudents", t);
      m.put("coveragePercent", t == 0 ? null : Math.round(h * 1000.0 / t) / 10.0);
      String note = "Range checks enforced by database constraints.";
      if ("placement_readiness".equals(src[1])) {
        Map<String, Object> nulls = jdbc.queryForMap("SELECT COALESCE(SUM(aptitude_score IS NULL), 0) AS a, COALESCE(SUM(coding_score IS NULL), 0) AS c, COALESCE(SUM(mock_interview_score IS NULL), 0) AS m FROM placement_readiness WHERE institution_id = ?", inst);
        note = "Missing values: aptitude " + nulls.get("a") + ", coding " + nulls.get("c") + ", mock interview " + nulls.get("m") + ". Missing values are skipped, never treated as zero.";
      }
      m.put("note", note);
      out.add(m);
    }
    return out;
  }
}
