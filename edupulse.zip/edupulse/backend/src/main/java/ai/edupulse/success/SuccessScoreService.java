package ai.edupulse.success;
import java.sql.ResultSet;
import java.util.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

/**
 * Student Success Score: a transparent weighted blend of seven indicator groups, each scaled 0-100.
 * Missing groups are left out and the remaining weights are re-normalised; completeness reports how much weight was available.
 */
@Service
public class SuccessScoreService {
  public static final String[] NAMES = {"ACADEMIC", "ATTENDANCE", "LMS_ENGAGEMENT", "CO_CURRICULAR", "PLACEMENT_READINESS", "SKILLS", "FEEDBACK"};
  public static final String[] LABELS = {"Academic performance", "Attendance", "LMS engagement", "Co-curricular engagement", "Placement readiness", "Skills", "Student feedback"};
  public static final double[] W = {0.30, 0.20, 0.15, 0.10, 0.15, 0.05, 0.05};
  public static final Map<String, String> SEGMENT_LABELS = new LinkedHashMap<>();
  public static final Map<String, String> SEGMENT_ACTIONS = new LinkedHashMap<>();
  static {
    SEGMENT_LABELS.put("NEEDS_HOLISTIC_SUPPORT", "Needs holistic support");
    SEGMENT_ACTIONS.put("NEEDS_HOLISTIC_SUPPORT", "Open a support case: mentor meeting, academic tutoring and an engagement plan.");
    SEGMENT_LABELS.put("HIGH_ACADEMIC_LOW_PLACEMENT", "High academics, low placement readiness");
    SEGMENT_ACTIONS.put("HIGH_ACADEMIC_LOW_PLACEMENT", "Enrol in aptitude and coding practice and schedule mock interviews.");
    SEGMENT_LABELS.put("PLACEMENT_READY_ACADEMIC_RISK", "Placement-ready, academically at risk");
    SEGMENT_ACTIONS.put("PLACEMENT_READY_ACADEMIC_RISK", "Offer subject tutoring and backlog planning before placement season.");
    SEGMENT_LABELS.put("DISENGAGED", "Disengaged");
    SEGMENT_ACTIONS.put("DISENGAGED", "Mentor outreach: find out what is getting in the way and re-introduce clubs and the LMS.");
    SEGMENT_LABELS.put("STAR_PERFORMER", "Star performers");
    SEGMENT_ACTIONS.put("STAR_PERFORMER", "Offer stretch opportunities: peer mentoring, hackathons, advanced placements.");
    SEGMENT_LABELS.put("ON_TRACK", "On track");
    SEGMENT_ACTIONS.put("ON_TRACK", "No action needed; keep monitoring.");
  }

  public record Scored(long id, String code, String name, String department, double[] comp, double score, double completeness,
                       String segment, String academicRisk, String placementRisk) {}
  private record Stu(long id, String code, String name, String dept) {}

  private final JdbcTemplate jdbc;
  public SuccessScoreService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

  static double mean(double... v) {
    double s = 0; int n = 0;
    for (double x : v) if (!Double.isNaN(x)) { s += x; n++; }
    return n == 0 ? Double.NaN : s / n;
  }
  static double clamp(double v) { return Double.isNaN(v) ? v : Math.max(0, Math.min(100, v)); }
  private static boolean ge(double x, double t) { return !Double.isNaN(x) && x >= t; }
  private static boolean lt(double x, double t) { return !Double.isNaN(x) && x < t; }

  static String academicRisk(double acad, double att) {
    if (Double.isNaN(acad) && Double.isNaN(att)) return "UNKNOWN";
    if (lt(acad, 50) || lt(att, 65)) return "HIGH";
    if (lt(acad, 65) || lt(att, 75)) return "MEDIUM";
    return "LOW";
  }
  static String placementRisk(double p) { return Double.isNaN(p) ? "UNKNOWN" : p < 40 ? "HIGH" : p < 55 ? "MEDIUM" : "LOW"; }
  static String segment(double score, double acad, double att, double lms, double eng, double plc) {
    if (score < 50) return "NEEDS_HOLISTIC_SUPPORT";
    if (ge(acad, 65) && lt(plc, 55)) return "HIGH_ACADEMIC_LOW_PLACEMENT";
    if (ge(plc, 65) && lt(acad, 55)) return "PLACEMENT_READY_ACADEMIC_RISK";
    if (lt(lms, 40) && lt(eng, 25)) return "DISENGAGED";
    if (ge(acad, 70) && ge(plc, 65) && ge(att, 80)) return "STAR_PERFORMER";
    return "ON_TRACK";
  }

  /** Reads n numeric columns (after the student id) per student; SQL NULL becomes NaN. */
  private Map<Long, double[]> cols(String sql, int n, Object... args) {
    return jdbc.query(sql, (ResultSet rs) -> {
      Map<Long, double[]> m = new HashMap<>();
      while (rs.next()) {
        double[] v = new double[n];
        for (int i = 0; i < n; i++) { double x = rs.getDouble(i + 2); v[i] = rs.wasNull() ? Double.NaN : x; }
        m.put(rs.getLong(1), v);
      }
      return m;
    }, args);
  }

  public List<Scored> computeAll(long inst) {
    List<Stu> students = jdbc.query("SELECT id, student_code, full_name, department FROM student_profiles WHERE institution_id = ? ORDER BY id",
        (rs, i) -> new Stu(rs.getLong("id"), rs.getString("student_code"), rs.getString("full_name"),
            rs.getString("department") == null ? "Unassigned" : rs.getString("department")), inst);
    Map<Long, double[]> att = cols("SELECT student_id, SUM(CASE WHEN status = 'PRESENT' THEN 1 ELSE 0 END), SUM(CASE WHEN status = 'ABSENT' THEN 1 ELSE 0 END) "
        + "FROM attendance_records WHERE institution_id = ? GROUP BY student_id", 2, inst);
    Map<Long, double[]> scores = cols("SELECT r.student_id, SUM(CASE WHEN r.status = 'SCORED' THEN r.marks * 100 / a.max_marks END), "
        + "SUM(CASE WHEN r.status = 'SCORED' THEN 1 ELSE 0 END) FROM assessment_results r JOIN assessments a ON a.id = r.assessment_id "
        + "WHERE r.institution_id = ? GROUP BY r.student_id", 2, inst);
    Map<Long, double[]> acad = cols("SELECT student_id, cgpa, backlogs FROM student_academic WHERE institution_id = ?", 2, inst);
    Map<Long, double[]> lms = cols("SELECT student_id, AVG(logins), SUM(assignments_submitted), SUM(assignments_due) FROM lms_activity "
        + "WHERE institution_id = ? GROUP BY student_id", 3, inst);
    Map<Long, double[]> eng = cols("SELECT student_id, SUM(CASE category WHEN 'HACKATHON' THEN 2 WHEN 'CERTIFICATION' THEN 2 ELSE 1 END) "
        + "FROM engagement_records WHERE institution_id = ? GROUP BY student_id", 1, inst);
    Map<Long, double[]> plc = cols("SELECT student_id, aptitude_score, coding_score, mock_interview_score FROM placement_readiness WHERE institution_id = ?", 3, inst);
    Map<Long, double[]> skl = cols("SELECT student_id, technical_score, soft_skill_score FROM skills_assessments WHERE institution_id = ?", 2, inst);
    Map<Long, double[]> fbk = cols("SELECT student_id, AVG(satisfaction), AVG(faculty_feedback) FROM feedback_records WHERE institution_id = ? GROUP BY student_id", 2, inst);

    List<Scored> out = new ArrayList<>();
    for (Stu s : students) {
      double[] a = att.get(s.id());
      double attPct = (a == null || a[0] + a[1] == 0) ? Double.NaN : a[0] * 100 / (a[0] + a[1]);
      double[] sc = scores.get(s.id());
      double avg = (sc == null || sc[1] == 0 || Double.isNaN(sc[0])) ? Double.NaN : sc[0] / sc[1];
      double[] ac = acad.get(s.id());
      double cgpa = ac == null ? Double.NaN : ac[0] * 10;
      double backlogs = (ac == null || Double.isNaN(ac[1])) ? 0 : ac[1];
      double academic = clamp(mean(avg, cgpa) - 5 * backlogs);
      double[] l = lms.get(s.id());
      double lmsC = l == null ? Double.NaN : mean(l[2] > 0 ? l[1] * 100 / l[2] : Double.NaN, Math.min(l[0], 5) / 5 * 100);
      double[] e = eng.get(s.id());
      double engC = Math.min(e == null ? 0 : e[0], 8) / 8 * 100;
      double[] p = plc.get(s.id());
      double plcC = p == null ? Double.NaN : mean(p[0], p[1], p[2]);
      double[] k = skl.get(s.id());
      double sklC = k == null ? Double.NaN : mean(k[0], k[1]);
      double[] f = fbk.get(s.id());
      double fbC = f == null ? Double.NaN : mean((f[0] - 1) / 4 * 100, (f[1] - 1) / 4 * 100);
      double[] comp = {academic, attPct, lmsC, engC, plcC, sklC, fbC};
      double wa = 0, sum = 0;
      for (int i = 0; i < comp.length; i++) if (!Double.isNaN(comp[i])) { wa += W[i]; sum += W[i] * comp[i]; }
      double score = sum / wa;
      out.add(new Scored(s.id(), s.code(), s.name(), s.dept(), comp, score, wa, segment(score, academic, attPct, lmsC, engC, plcC),
          academicRisk(academic, attPct), placementRisk(plcC)));
    }
    return out;
  }

  /** Institution mean of each component over students who have it. */
  public static double[] componentMeans(List<Scored> list) {
    double[] m = new double[NAMES.length];
    for (int i = 0; i < m.length; i++) {
      final int idx = i;
      m[i] = mean(list.stream().mapToDouble(s -> s.comp()[idx]).toArray());
    }
    return m;
  }
}
