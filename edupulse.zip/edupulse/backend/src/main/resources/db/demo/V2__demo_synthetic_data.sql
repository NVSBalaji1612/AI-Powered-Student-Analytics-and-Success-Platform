-- SYNTHETIC DEMO DATA ONLY. Dev profile; never load in production.
INSERT INTO institutions (name, timezone) VALUES ('DEMO Institution A (synthetic)','Asia/Kolkata'),('DEMO Institution B (synthetic)','Asia/Kolkata');
INSERT INTO student_profiles (institution_id, student_code, full_name, department) VALUES
(1,'A-001','Demo Student A001','Mechanical'),
(1,'A-002','Demo Student A002','Mathematics'),
(1,'A-003','Demo Student A003','Computer Science'),
(1,'A-004','Demo Student A004','Mechanical'),
(1,'A-005','Demo Student A005','Mathematics'),
(1,'A-006','Demo Student A006','Computer Science'),
(1,'A-007','Demo Student A007','Mechanical'),
(1,'A-008','Demo Student A008','Mathematics'),
(1,'A-009','Demo Student A009','Computer Science'),
(1,'A-010','Demo Student A010','Mechanical'),
(2,'B-001','Demo Student B001','Mechanical'),
(2,'B-002','Demo Student B002','Mathematics'),
(2,'B-003','Demo Student B003','Computer Science'),
(2,'B-004','Demo Student B004','Mechanical'),
(2,'B-005','Demo Student B005','Mathematics'),
(2,'B-006','Demo Student B006','Computer Science'),
(2,'B-007','Demo Student B007','Mechanical'),
(2,'B-008','Demo Student B008','Mathematics'),
(2,'B-009','Demo Student B009','Computer Science'),
(2,'B-010','Demo Student B010','Mechanical');
