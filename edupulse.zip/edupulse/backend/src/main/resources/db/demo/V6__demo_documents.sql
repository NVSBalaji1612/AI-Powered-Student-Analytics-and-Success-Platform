-- SYNTHETIC DEMO POLICIES ONLY. Dev profile; never load in production.
INSERT INTO knowledge_documents (id, institution_id, title, uploaded_by) VALUES
 (1,1,'Attendance Policy (DEMO, Institution A)','seed'),(2,1,'Student Support Resources (DEMO, Institution A)','seed'),
 (3,2,'Attendance Policy (DEMO, Institution B)','seed'),(4,2,'Student Support Resources (DEMO, Institution B)','seed');
INSERT INTO knowledge_chunks (institution_id, document_id, chunk_index, content) VALUES
 (1,1,0,'Institution A attendance policy: students are expected to attend at least 75 percent of scheduled sessions in each subject. A supportive attendance conversation is offered after three consecutive absences.'),
 (1,1,1,'Excused absences, such as documented illness, are not counted against the attendance percentage. Students may request a correction of attendance records through their mentor.'),
 (1,2,0,'Institution A support resources: free peer tutoring for mathematics runs on Tuesday afternoons. Programming help sessions run on Thursdays. Study planning workshops are offered each month.'),
 (2,3,0,'Institution B attendance policy: students must attend at least 80 percent of sessions. Mentors contact students after two consecutive absences to offer help.'),
 (2,3,1,'Institution B treats medical absences as excused when documentation is provided within seven days.'),
 (2,4,0,'Institution B support resources: a writing and study skills lab is open on Mondays and Wednesdays. Mathematics drop-in tutoring is available on Fridays.');
