-- Adds profile and soft-delete support for user administration. Existing users are preserved.
ALTER TABLE users ADD COLUMN full_name VARCHAR(200) NULL, ADD COLUMN deleted_at TIMESTAMP NULL, ADD COLUMN created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP;
