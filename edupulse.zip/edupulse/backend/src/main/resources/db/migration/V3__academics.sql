CREATE TABLE subjects (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL,
  code VARCHAR(20) NOT NULL, name VARCHAR(120) NOT NULL, UNIQUE (institution_id, code),
  FOREIGN KEY (institution_id) REFERENCES institutions(id));
CREATE TABLE attendance_records (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL,
  student_id BIGINT NOT NULL, subject_id BIGINT NOT NULL, class_date DATE NOT NULL,
  status VARCHAR(10) NOT NULL CHECK (status IN ('PRESENT','ABSENT','EXCUSED')),
  UNIQUE (student_id, subject_id, class_date), INDEX idx_att_inst_student (institution_id, student_id),
  FOREIGN KEY (student_id) REFERENCES student_profiles(id), FOREIGN KEY (subject_id) REFERENCES subjects(id));
CREATE TABLE assessments (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL,
  subject_id BIGINT NOT NULL, name VARCHAR(80) NOT NULL, max_marks DECIMAL(6,2) NOT NULL CHECK (max_marks > 0),
  held_on DATE NOT NULL, FOREIGN KEY (subject_id) REFERENCES subjects(id));
CREATE TABLE assessment_results (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL,
  assessment_id BIGINT NOT NULL, student_id BIGINT NOT NULL, marks DECIMAL(6,2) NULL,
  status VARCHAR(10) NOT NULL CHECK (status IN ('SCORED','MISSING','WITHDRAWN')),
  UNIQUE (assessment_id, student_id), INDEX idx_res_inst_student (institution_id, student_id),
  FOREIGN KEY (assessment_id) REFERENCES assessments(id), FOREIGN KEY (student_id) REFERENCES student_profiles(id));
