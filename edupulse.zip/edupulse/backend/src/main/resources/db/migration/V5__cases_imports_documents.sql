CREATE TABLE intervention_cases (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL, student_id BIGINT NOT NULL,
  reason VARCHAR(300) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'NEW' CHECK (status IN ('NEW','REVIEWED','ASSIGNED','IN_PROGRESS','FOLLOW_UP','RESOLVED')),
  assigned_to VARCHAR(254), created_by VARCHAR(254) NOT NULL,
  opened_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, closed_at TIMESTAMP NULL, outcome_note VARCHAR(1000),
  open_attendance DECIMAL(5,2) NULL, open_score DECIMAL(5,2) NULL, close_attendance DECIMAL(5,2) NULL, close_score DECIMAL(5,2) NULL,
  version BIGINT NOT NULL DEFAULT 0, INDEX idx_case_inst (institution_id, status),
  FOREIGN KEY (student_id) REFERENCES student_profiles(id));
CREATE TABLE intervention_actions (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL, case_id BIGINT NOT NULL,
  action_type VARCHAR(40) NOT NULL, note VARCHAR(500), due_date DATE NULL,
  status VARCHAR(10) NOT NULL DEFAULT 'OPEN' CHECK (status IN ('OPEN','DONE','MISSED')),
  completed_at TIMESTAMP NULL, created_by VARCHAR(254) NOT NULL, INDEX idx_act_inst (institution_id, status),
  FOREIGN KEY (case_id) REFERENCES intervention_cases(id));
CREATE TABLE import_jobs (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL, actor VARCHAR(254) NOT NULL,
  filename VARCHAR(100) NOT NULL, total_rows INT NOT NULL, imported INT NOT NULL, rejected INT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_imp_inst (institution_id));
CREATE TABLE knowledge_documents (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL, title VARCHAR(200) NOT NULL,
  uploaded_by VARCHAR(254) NOT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_doc_inst (institution_id));
CREATE TABLE knowledge_chunks (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL, document_id BIGINT NOT NULL,
  chunk_index INT NOT NULL, content TEXT NOT NULL, INDEX idx_chunk_inst (institution_id),
  FOREIGN KEY (document_id) REFERENCES knowledge_documents(id) ON DELETE CASCADE);
