CREATE TABLE student_academic (student_id BIGINT PRIMARY KEY, institution_id BIGINT NOT NULL,
  cgpa DECIMAL(4,2) NOT NULL CHECK (cgpa BETWEEN 0 AND 10), backlogs INT NOT NULL DEFAULT 0 CHECK (backlogs >= 0),
  INDEX idx_sa_inst (institution_id), FOREIGN KEY (student_id) REFERENCES student_profiles(id));
CREATE TABLE lms_activity (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL, student_id BIGINT NOT NULL,
  week_start DATE NOT NULL, logins INT NOT NULL CHECK (logins >= 0), assignments_due INT NOT NULL CHECK (assignments_due >= 0),
  assignments_submitted INT NOT NULL CHECK (assignments_submitted >= 0), CHECK (assignments_submitted <= assignments_due),
  UNIQUE (student_id, week_start), INDEX idx_lms_inst (institution_id), FOREIGN KEY (student_id) REFERENCES student_profiles(id));
CREATE TABLE engagement_records (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL, student_id BIGINT NOT NULL,
  category VARCHAR(20) NOT NULL CHECK (category IN ('EVENT','CLUB','HACKATHON','CERTIFICATION')), title VARCHAR(120) NOT NULL,
  occurred_on DATE NOT NULL, INDEX idx_eng_inst (institution_id), FOREIGN KEY (student_id) REFERENCES student_profiles(id));
CREATE TABLE placement_readiness (student_id BIGINT PRIMARY KEY, institution_id BIGINT NOT NULL,
  aptitude_score DECIMAL(5,2) NULL CHECK (aptitude_score IS NULL OR aptitude_score BETWEEN 0 AND 100),
  coding_score DECIMAL(5,2) NULL CHECK (coding_score IS NULL OR coding_score BETWEEN 0 AND 100),
  mock_interview_score DECIMAL(5,2) NULL CHECK (mock_interview_score IS NULL OR mock_interview_score BETWEEN 0 AND 100),
  assessed_on DATE NOT NULL, INDEX idx_pr_inst (institution_id), FOREIGN KEY (student_id) REFERENCES student_profiles(id));
CREATE TABLE skills_assessments (student_id BIGINT PRIMARY KEY, institution_id BIGINT NOT NULL,
  technical_score DECIMAL(5,2) NULL CHECK (technical_score IS NULL OR technical_score BETWEEN 0 AND 100),
  soft_skill_score DECIMAL(5,2) NULL CHECK (soft_skill_score IS NULL OR soft_skill_score BETWEEN 0 AND 100),
  assessed_on DATE NOT NULL, INDEX idx_sk_inst (institution_id), FOREIGN KEY (student_id) REFERENCES student_profiles(id));
CREATE TABLE feedback_records (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL, student_id BIGINT NOT NULL,
  satisfaction DECIMAL(3,1) NULL CHECK (satisfaction IS NULL OR satisfaction BETWEEN 1 AND 5),
  faculty_feedback DECIMAL(3,1) NULL CHECK (faculty_feedback IS NULL OR faculty_feedback BETWEEN 1 AND 5),
  recorded_on DATE NOT NULL, UNIQUE (student_id, recorded_on), INDEX idx_fb_inst (institution_id), FOREIGN KEY (student_id) REFERENCES student_profiles(id));
