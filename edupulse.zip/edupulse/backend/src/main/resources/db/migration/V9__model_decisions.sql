CREATE TABLE model_decisions (id BIGINT AUTO_INCREMENT PRIMARY KEY, institution_id BIGINT NOT NULL, model_version VARCHAR(80) NOT NULL,
  decision VARCHAR(10) NOT NULL CHECK (decision IN ('APPROVED','REJECTED','RETIRED')), reason VARCHAR(500) NOT NULL,
  decided_by VARCHAR(254) NOT NULL, decided_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, INDEX idx_md_inst (institution_id, model_version));
