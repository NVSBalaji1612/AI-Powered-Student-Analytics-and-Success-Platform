package ai.edupulse;
import static org.junit.jupiter.api.Assertions.*;
import ai.edupulse.admin.AdminRules;
import ai.edupulse.security.PasswordPolicy;
import org.junit.jupiter.api.Test;
class AdminRulesTest {
  @Test void lastActiveSuperAdminCannotBeRemoved() { assertFalse(AdminRules.mayRemoveActiveAdmin(1)); assertFalse(AdminRules.mayRemoveActiveAdmin(0)); assertTrue(AdminRules.mayRemoveActiveAdmin(2)); }
  @Test void platformAdminCannotBeAssigned() { assertFalse(AdminRules.ROLES.contains("PLATFORM_ADMIN")); assertTrue(AdminRules.ROLES.contains("FACULTY")); }
  @Test void weakPasswordsRejected() { assertNotNull(PasswordPolicy.validate("short1A")); assertNotNull(PasswordPolicy.validate("alllowercase12345")); assertNotNull(PasswordPolicy.validate(null)); }
  @Test void strongPasswordAccepted() { assertNull(PasswordPolicy.validate("Temp-Pass-2026-Xy")); }
}
