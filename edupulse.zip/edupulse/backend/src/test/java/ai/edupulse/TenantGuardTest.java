package ai.edupulse;
import static org.junit.jupiter.api.Assertions.*;
import ai.edupulse.security.TenantGuard;
import org.junit.jupiter.api.Test;
import org.springframework.web.server.ResponseStatusException;
class TenantGuardTest {
  @Test void sameTenantAllowed() { assertDoesNotThrow(() -> TenantGuard.requireSame(1, 1)); }
  @Test void otherTenantLooksNotFound() {
    var e = assertThrows(ResponseStatusException.class, () -> TenantGuard.requireSame(1, 2));
    assertEquals(404, e.getStatusCode().value());
  }
}
