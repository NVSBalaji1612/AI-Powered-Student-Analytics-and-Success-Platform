package ai.edupulse;
import static org.junit.jupiter.api.Assertions.*;
import ai.edupulse.imports.CsvParser;
import ai.edupulse.intervention.InterventionWorkflow;
import java.util.List;
import org.junit.jupiter.api.Test;
class WorkflowAndCsvTest {
  @Test void forwardTransitionsAllowed() {
    assertTrue(InterventionWorkflow.allowed("NEW", "REVIEWED"));
    assertTrue(InterventionWorkflow.allowed("FOLLOW_UP", "RESOLVED"));
    assertTrue(InterventionWorkflow.allowed("RESOLVED", "IN_PROGRESS"));
  }
  @Test void skippingStepsAndReturningToNewRejected() {
    assertFalse(InterventionWorkflow.allowed("NEW", "IN_PROGRESS"));
    for (String s : List.of("NEW", "REVIEWED", "ASSIGNED", "IN_PROGRESS", "FOLLOW_UP", "RESOLVED")) assertFalse(InterventionWorkflow.allowed(s, "NEW"));
  }
  @Test void csvQuotesAndNewlines() {
    List<List<String>> rows = CsvParser.parse("a,b\r\n1,\"x,y\"\n\"q\"\"z\",2\n");
    assertEquals(3, rows.size());
    assertEquals(List.of("1", "x,y"), rows.get(1));
    assertEquals("q\"z", rows.get(2).get(0));
  }
  @Test void unterminatedQuoteRejected() { assertThrows(IllegalArgumentException.class, () -> CsvParser.parse("a,\"b\n")); }
}
