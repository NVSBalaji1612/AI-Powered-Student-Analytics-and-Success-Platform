# AI Copilot: free local model with Ollama
**Why:** no paid API, no data leaves your PC. **Needs:** Docker Desktop, about 4 GB of free RAM and about 2 GB of disk for `llama3.2:3b`. Answers are slower on a CPU-only laptop.
1. Run `scripts\enable-local-ai.cmd`. It rewrites the `LLM_*` lines in `.env` (removing any old hosted key), starts the `ollama` container (profile `ai`, no published port, reachable only by the backend), downloads the model once, and restarts the backend.
2. Sign in as the Super Admin, open **AI Copilot settings**, click **Test connection**. Then ask the Copilot a question; the page shows `Mode: LLM`.
3. Stop with `docker compose --profile ai stop ollama`. Models live in the `ollama_data` volume; the normal build never downloads models.
**Other providers:** set `LLM_PROVIDER=openai-compatible` with `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL` (Groq, OpenRouter free models). Google's newer `AQ.` keys have been reported to fail on the OpenAI-compatible route, so prefer Ollama.
**Behaviour:** the Copilot is read-only, shows verified figures and cited policy passages separately from the model's text, times out after 120 s and falls back to figures only. Keys are read from `.env` on the server and never shown (the settings screen reports only whether a key exists).
