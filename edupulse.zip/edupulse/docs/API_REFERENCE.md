# API reference (all under /api/v1, HTTP Basic in dev, JSON unless stated)
| Area | Endpoints | Roles |
|---|---|---|
| Identity | GET /me | any signed-in user |
| Students | GET /students, GET /students/{id}, GET /students/{id}/summary, /prediction, /recommendations | staff |
| Success score | GET /success/overview?department=&segment=, GET /success/students/{id}, GET /success/data-quality | staff |
| Analytics and risk | GET /analytics/overview, GET /risk/overview, POST /predictions/what-if | staff |
| Support cases | POST/GET /interventions, GET /interventions/{id}, POST /{id}/transition, /{id}/actions, /{id}/actions/{aid}/complete, GET /interventions/metrics | staff |
| Import | GET /imports/{source}/template, POST /imports/{source}/preview and /commit (students, lms, placement, skills, feedback, engagement), GET /imports | admin |
| Knowledge base | GET /documents, POST /documents (admin), DELETE /documents/{id} (admin), POST /copilot/ask | staff |
| Governance | GET /governance/model, POST /governance/model/decision | admin |
| Audit | GET /audit/events?action=&limit= | admin, auditor |
Errors: 400 validation, 401 not signed in or locked, 403 role not allowed, 404 not found or another institution's record, 409 workflow conflict, 502 AI service unavailable.
