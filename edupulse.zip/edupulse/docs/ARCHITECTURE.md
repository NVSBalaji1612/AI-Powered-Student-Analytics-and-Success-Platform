# Architecture
```mermaid
flowchart LR
  B[React + Vite SPA] -->|/api/v1 Basic auth| API[Spring Boot 3, Java 21]
  API --> DB[(MySQL 8, Flyway)]
  API -->|/v1/predict, /v1/model| AI[FastAPI + scikit-learn]
  API -.optional.-> LLM[LLM provider, off by default]
```
Single institution id per authenticated user scopes every query (modular monolith, JdbcTemplate for reporting queries, JPA for students). Success Score is computed on request from stored records. Redis is provisioned but not used yet. Demo seed data lives in `db/demo` and is loaded only by the dev Compose file.
