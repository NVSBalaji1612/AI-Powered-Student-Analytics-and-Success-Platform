# Creating the first Super Admin (real installs)
1. In `.env` set `BOOTSTRAP_ADMIN_EMAIL`, `BOOTSTRAP_ADMIN_PASSWORD` (12+ characters, upper-case, lower-case, digit) and optionally `BOOTSTRAP_INSTITUTION_NAME`. Keep `DEMO_USERS_ENABLED=false`.
2. Start the stack. If no Super Admin exists, one is created (and an institution if none exists). The password is never logged. If one already exists, nothing happens.
3. Sign in, then **delete the BOOTSTRAP_ADMIN_PASSWORD line** from `.env` and run `docker compose up -d backend`.
4. Create other users in **User management**.
Demo accounts (`DEMO_USERS_ENABLED=true`) are for local demos only and are re-created with the demo password on each start.
