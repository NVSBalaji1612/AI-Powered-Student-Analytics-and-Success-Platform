# Demo script (about 4 minutes)
1. (20s) Problem: colleges hold attendance, marks, LMS, engagement, placement, skills and feedback in separate places. EduPulse joins them into one view per student. Show the "Data quality" table: 8 sources, coverage and gaps.
2. (40s) Dashboard: load as admin@inst-a.demo. Point at KPI cards, score distribution, segments, department averages, LMS trend. Open "How the score works".
3. (40s) Filter by department, then click a segment ("High academics, low placement readiness") and read its suggested action.
4. (50s) Open A-004. Show the driver chart: placement readiness pulls the score down. Show the sum of points equals the score. Later, as admin@inst-b.demo, open B-003 (no placement data) to show how missing data is handled.
5. (40s) Open A-007 (needs holistic support). Click "Open support case", then in Support cases move it through review, assignment, follow-up, and resolve with a note. Show outcome metrics.
6. (30s) Copilot: ask "What is the attendance policy?" and show verified numbers plus cited policy passages (no LLM key needed).
7. (20s) Isolation: switch to admin@inst-b.demo; show B sees only B students and different policies. Close with the loop: data, insight, explanation, human review, intervention, outcome.
