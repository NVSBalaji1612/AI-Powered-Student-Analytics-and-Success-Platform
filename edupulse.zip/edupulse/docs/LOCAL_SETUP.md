# Local setup, step by step (Windows)
Install once: Docker Desktop (running), Node 22, Python 3.12, Java 21 and Maven (only needed for `mvn test`).

1. Unzip the project, open **Command Prompt** in the project root (the folder with `docker-compose.yml`).
2. Create settings: `scripts\make-env.cmd`. This writes `.env` with demo passwords (it never overwrites an existing one).
3. Start the stack: `scripts\start.cmd` (first build takes several minutes).
4. Wait about a minute, then open http://localhost:8081/actuator/health. Expect `{"status":"UP"}`. If not: `docker compose ps -a` and `docker compose logs backend --tail 60`.
5. Frontend: `cd frontend`, `npm install`, `npm run dev`. Open http://localhost:5173.
6. Sign in with a demo account and the DEMO_PASSWORD from `.env`: `admin@inst-a.demo` (admin), `faculty@inst-a.demo` (faculty), `auditor@inst-a.demo` (auditor), `admin@inst-b.demo` (second institution).
7. AI tests one time: `cd ai-service`, `python -m venv .venv`, `.venv\Scripts\python.exe -m pip install -r requirements.txt pytest httpx`, `.venv\Scripts\python.exe -m pytest -q` (expect 7 passed).
8. Run everything: `scripts\run-checks.cmd` (about 75 checks; needs the stack running and the venv from step 7).

**Updating to a new zip:** copy the files over the project folder (do not delete it), keep `.env`. If the backend says `Migration checksum mismatch`, run `scripts\reset-demo.cmd` (this deletes the demo database only).
**Common problems:** port 8080 busy (we use 8081); `.env` missing gives `Access denied for user 'edupulse'` (run `scripts\make-env.cmd`); locked demo account after 5 wrong passwords (wait 15 minutes or restart the backend).

## Free Copilot (no paid plan)
The Copilot works without any model (it shows verified figures and the closest policy passage). To get written answers for free, set these in `.env`, then run `docker compose up -d backend`:
- **Google Gemini free tier:** `LLM_PROVIDER=openai-compatible`, `LLM_BASE_URL=https://generativelanguage.googleapis.com/v1beta/openai/`, `LLM_API_KEY=<key from Google AI Studio>`, `LLM_MODEL=gemini-2.5-flash`.
- **Ollama on your own PC (fully local, no key):** install Ollama, run `ollama pull llama3.2:3b`, then `LLM_PROVIDER=openai-compatible`, `LLM_BASE_URL=http://host.docker.internal:11434/v1`, `LLM_API_KEY=`, `LLM_MODEL=llama3.2:3b`.
- **Groq or OpenRouter free models:** same pattern; base URLs `https://api.groq.com/openai/v1` or `https://openrouter.ai/api/v1`, and copy a current free model name from the provider's model list.
Free hosted tiers may use prompts to improve their products and their limits change; use only synthetic data with them. Ollama keeps everything on your machine.
