# EduPulse AI: Progress (truthful status)
Sandbox: Python 3.12, Java 21, Node 22. No Maven Central access, so the Java backend is UNCOMPILED and its tests UNRUN. Docker not available.

## Verified
- ai-service: pytest 6 passed. Synthetic-data metrics (baseline ROC-AUC 0.816, PR-AUC 0.708) are NOT real-world evidence.
- frontend: `npm install && npm run build` (strict tsc + vite) run in sandbox; see result in chat.
## Written, NOT compiled/run
- backend: pom, Flyway V1 (institutions, users, student_profiles, audit_events), tenant-scoped student API, TenantGuard + test, authenticated AI proxy, demo users only when DEMO_USERS_ENABLED=true (fail closed otherwise), docker-compose backend service.
## Known gaps
- Auth is dev-grade httpBasic with in-memory demo users; no DB-backed users, no sessions/CSRF, MFA, lockout, audit writes.
- Not started: most modules (import, attendance, assessments, dashboard, interventions, RAG/copilot, reports, governance, e2e), most docs.
## Added since: demo seed (db/demo V2, synthetic, 2 institutions x 10 students), Students list in frontend, Dockerfile trains model. Backend `mvn test` passed on user machine (2 tests); full docker stack health UP on user machine.
## Verified on user machine: Docker stack up, login works, institution A student list shown. Backend port moved to 8081 (8080 taken by local Apache). Fixed principal bug in SecurityConfig.
## Stage 1 (written, NOT yet run on user machine): V3 schema (subjects, attendance_records, assessments, assessment_results), synthetic seed V4 (600 attendance rows, 180 results; students 3,7,14,18 are deliberately struggling), GET /api/v1/students/{id}/summary, student detail view.
## Test runner: scripts/run-all-checks.ps1 (see docs/TESTING.md).
## Stages 2+3 (written; Java NOT compiled here, frontend build verified): GET /api/v1/analytics/overview (KPIs, subject/department/weekly trend, min cohort 3), StudentFeatureService (features from stored records), GET /api/v1/students/{id}/prediction, GET /api/v1/risk/overview, audit_events rows written for prediction views, dashboard + risk + prediction UI. assignment_completion is not collected, so it is sent as missing.
## Stages 4-6 (written; Java NOT compiled here, frontend build verified): V5 schema (cases, actions, import_jobs, knowledge docs/chunks), V6 demo policies, interventions API + workflow + metrics + rule-based recommendations, student CSV import (preview/commit/history/template), documents + Copilot (DISABLED mode by default, Anthropic provider optional). See docs/KNOWN_LIMITATIONS.md.
## Stage 7 hackathon alignment (written; Java NOT compiled here, frontend build verified; scoring logic mirrored in Python against the seed data): V7 schema (academic, LMS, engagement, placement, skills, feedback), V8 synthetic data, Success Score service, /api/v1/success/* (overview, student detail, data-quality), Recharts dashboard, docs/SUCCESS_SCORE.md, DEMO_SCRIPT.md, HACKATHON_PITCH.md.
## Stage 8 (written; Java NOT compiled here, frontend build verified, AI pytest 7 passed here): DB users + roles + lockout + audit screen, model governance screen, CSV import for 5 more sources, new tabbed UI with login, CSV export, docs and helper scripts.
## Phase 1 upgrade (written; Java NOT compiled here, frontend build verified, compose YAML parsed): V10 user admin migration, AdminUserController, password change, BootstrapAdmin, AiAdminController, Ollama compose profile, Users/AI settings/Account screens, ~15 new checks, docs.
## Next
Run `cd backend && mvn test` locally, fix compile issues, then DB-backed users + cross-tenant MockMvc tests.
