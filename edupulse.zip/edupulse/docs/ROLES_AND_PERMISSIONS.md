# Roles and permissions (current implementation)
Roles are stored on each user (`users.role`) and enforced on the server in `SecurityConfig`; hiding a tab in the UI is not security. All data is scoped to the signed-in user's institution.

| Role (code name) | Shown as | Can do today |
|---|---|---|
| INSTITUTION_ADMIN | Super Admin | Everything in the institution: user management (create, edit role, activate/deactivate, reset password, soft delete), data import, documents, AI Copilot settings, model governance, audit log, all dashboards, support cases, Copilot |
| ACADEMIC_ANALYST | Administrator (analytics) | Dashboards, students, risk signals, analytics, support cases, Copilot (read-focused) |
| FACULTY, MENTOR | Faculty, Mentor | Same screens as analytics staff. NOT yet limited to assigned classes or departments |
| AUDITOR | Read-only auditor | Audit log only, plus My account |
| STUDENT | Student | Sign in and My account only. Student portal not built |
| PLATFORM_ADMIN | (reserved) | Cannot be assigned through the application |

Safeguards: nobody can change their own role or status; the last active Super Admin cannot be demoted, deactivated or deleted; roles can only be assigned from the list above; deleted users are kept (soft delete) and cannot sign in; every administrative action is written to the audit log.
Not built yet: configurable permissions per role, per-user overrides, department or course scoping for Administrators and Faculty, Parent, Librarian, Examination Controller and Finance roles.
