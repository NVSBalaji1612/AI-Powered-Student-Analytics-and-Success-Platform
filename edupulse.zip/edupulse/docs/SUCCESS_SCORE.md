# Student Success Score: short note
**Purpose.** One 0-100 number per student that combines academic, engagement, placement and wellbeing-related indicators so faculty can spot who may need support and see why. It is a decision-support signal for human review, not a judgment about a student's ability or character. All demo data is synthetic.

| Indicator group | Weight | How it is scaled to 0-100 |
|---|---|---|
| Academic performance | 30% | mean(average assessment %, CGPA x 10), minus 5 points per backlog, limited to 0-100 |
| Attendance | 20% | PRESENT / (PRESENT + ABSENT); excused sessions excluded |
| LMS engagement | 15% | mean(assignment completion %, login activity where 5+ logins a week = 100) |
| Co-curricular engagement | 10% | points (hackathon 2, certification 2, event 1, club 1), capped at 8, scaled to 100 |
| Placement readiness | 15% | mean of available aptitude, coding and mock-interview scores |
| Skills | 5% | mean of technical and soft-skill scores |
| Student feedback | 5% | mean of satisfaction and faculty feedback, rescaled from 1-5 |

**Combination.** Score = sum(weight x indicator) / sum(weights of indicators that exist). A missing indicator is skipped, never treated as zero, and the student's data completeness (share of weight available) is shown beside the score.

**Risk flags (rule based).** Academic risk: HIGH if academic < 50 or attendance < 65; MEDIUM if academic < 65 or attendance < 75. Placement risk: HIGH if placement readiness < 40; MEDIUM if < 55; UNKNOWN if no placement data. A separate machine-learning signal (trained on synthetic data, unapproved) is available per student.

**Segments (first match wins).** Needs holistic support (score < 50); High academics but low placement readiness; Placement-ready but academically at risk; Disengaged (LMS < 40 and co-curricular < 25); Star performers; On track. Each has a suggested action.

**Explainability.** Each indicator's contribution is its normalised weight times its score; its driver value is the weighted gap to the institution average. Bars show which indicators pull a student up or down. This is association, not cause.

**Limitations.** Weights and thresholds are expert defaults, not validated against real outcomes. Segments are descriptive. Small groups (< 3 students) are hidden in department comparisons.
