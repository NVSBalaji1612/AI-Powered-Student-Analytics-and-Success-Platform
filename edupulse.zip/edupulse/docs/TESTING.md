# Testing
Run everything: `scripts\run-checks.cmd` (Docker stack running; one-time venv in ai-service, see LOCAL_SETUP).
Covers: AI pytest (7), backend JUnit (6: tenant guard, workflow, CSV parser), frontend strict type-check and build, and about 70 live API checks: isolation across institutions, roles (admin, faculty, auditor), lockout, audit, governance, analytics, Success Score, segments, explanations, cases, imports, Copilot.
Not automated: browser end-to-end tests, frontend component tests, load tests, happy-path import commit.
