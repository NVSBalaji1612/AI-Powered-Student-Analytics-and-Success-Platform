# Upgrade plan toward a full education management system
**Phase 1 (done in this package):** repository audit; user administration with safeguards, soft delete, password change, audit; first-admin bootstrap; AI settings screen and a free local Ollama option; role matrix; new automated checks.
**Phase 2:** configurable roles and permissions tables, per-user overrides, department/course scoping, Administrator role limits.
**Phase 3:** departments, courses, subjects, batches, enrollments, timetable.
**Phase 4:** faculty attendance and marks entry, assignments and submissions, learning materials, examinations and results.
**Phase 5:** announcements and notifications, student portal, reports and exports, backup and restore procedure, Docker health checks and production profile.
**Phase 6:** browser end-to-end tests, dependency and container scans, TLS and session/OIDC login with CSRF.
Audit findings that shaped this plan: single-institution users with a fixed role list; HTTP Basic login (dev only); roles enforced by URL rules only; no academic structure tables (courses, batches) beyond subjects and assessments; Copilot was env-configured with no admin visibility; the uploaded zip contained a real `.env` with an API key and a full `node_modules` folder.
