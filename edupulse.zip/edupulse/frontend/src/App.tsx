import { useState } from "react";
import { call, errText } from "./api";
import Dashboard from "./Dashboard";
import Students from "./Students";
import { Analytics, Audit, Governance, RiskOverview, WhatIf } from "./Extras";
import { CopilotPanel, ImportPanel, InterventionsPanel } from "./Panels";
import { Account, AiSettings, ROLE_LABELS, Users } from "./Users";

type Me = { email: string; role: string; institutionId: number };
const STAFF = ["INSTITUTION_ADMIN", "FACULTY", "MENTOR", "ACADEMIC_ANALYST"];
const TABS: { id: string; label: string; roles: string[] }[] = [
  { id: "dashboard", label: "Success dashboard", roles: STAFF }, { id: "students", label: "Students", roles: STAFF },
  { id: "risk", label: "ML risk signals", roles: STAFF }, { id: "analytics", label: "Academic analytics", roles: STAFF },
  { id: "cases", label: "Support cases", roles: STAFF }, { id: "import", label: "Data import", roles: ["INSTITUTION_ADMIN"] },
  { id: "copilot", label: "Copilot", roles: STAFF }, { id: "whatif", label: "What-if simulator", roles: STAFF },
  { id: "governance", label: "AI governance", roles: ["INSTITUTION_ADMIN"] }, { id: "audit", label: "Security and audit", roles: ["INSTITUTION_ADMIN", "AUDITOR"] },
  { id: "users", label: "User management", roles: ["INSTITUTION_ADMIN"] }, { id: "ai", label: "AI Copilot settings", roles: ["INSTITUTION_ADMIN"] },
  { id: "account", label: "My account", roles: [...STAFF, "AUDITOR", "STUDENT"] },
];

export default function App() {
  const [user, setUser] = useState(""); const [pw, setPw] = useState(""); const [auth, setAuth] = useState(""); const [me, setMe] = useState<Me | null>(null);
  const [error, setError] = useState(""); const [tab, setTab] = useState(""); const [busy, setBusy] = useState(false);

  async function signIn() {
    setError(""); setBusy(true);
    try {
      const header = "Basic " + btoa(`${user.trim()}:${pw}`);
      const m = await call<Me>(header, "/api/v1/me");
      const first = TABS.find(t => t.roles.includes(m.role));
      setAuth(header); setMe(m); setTab(first ? first.id : ""); setPw("");
    } catch (e) {
      const t = errText(e);
      setError(t === "Not signed in" ? "Wrong username or password, or the account is temporarily locked." : t);
    } finally { setBusy(false); }
  }
  const signOut = () => { setAuth(""); setMe(null); setTab(""); };

  if (!me) return (<div className="login"><h1>EduPulse AI</h1><p>Intelligent Student Success &amp; Institutional Intelligence Platform</p>
    <div className="banner">Demo environment with synthetic data. Demo accounts such as admin@inst-a.demo, faculty@inst-a.demo and auditor@inst-a.demo use the password set in your .env file.</div>
    <label>Username <input aria-label="username" value={user} onChange={e => setUser(e.target.value)} autoComplete="username" /></label>
    <label>Password <input aria-label="password" type="password" value={pw} onChange={e => setPw(e.target.value)} onKeyDown={e => { if (e.key === "Enter") void signIn(); }} autoComplete="current-password" /></label>
    <button onClick={signIn} disabled={busy || !user || !pw}>{busy ? "Signing in..." : "Sign in"}</button>
    {error && <p role="alert" style={{ color: "#b00020" }}>{error}</p>}</div>);

  const allowed = TABS.filter(t => t.roles.includes(me.role));
  return (<div className="shell">
    <nav className="side"><div className="brand">EduPulse AI</div>
      {allowed.map(t => <button key={t.id} className={t.id === tab ? "navbtn active" : "navbtn"} onClick={() => setTab(t.id)}>{t.label}</button>)}
      <div className="who"><small>{me.email}<br />{ROLE_LABELS[me.role] ?? me.role} (institution {me.institutionId})</small><button onClick={signOut}>Sign out</button></div></nav>
    <div className="content"><div className="banner">Synthetic demo data. Signals support human review and are not decisions about students.</div>
      {tab === "dashboard" && <Dashboard auth={auth} />}{tab === "students" && <Students auth={auth} />}{tab === "risk" && <RiskOverview auth={auth} />}
      {tab === "analytics" && <Analytics auth={auth} />}{tab === "cases" && <InterventionsPanel auth={auth} />}{tab === "import" && <ImportPanel auth={auth} />}
      {tab === "copilot" && <CopilotPanel auth={auth} />}{tab === "whatif" && <WhatIf auth={auth} />}{tab === "governance" && <Governance auth={auth} />}
      {tab === "audit" && <Audit auth={auth} />}{tab === "users" && <Users auth={auth} selfEmail={me.email} />}{tab === "ai" && <AiSettings auth={auth} />}{tab === "account" && <Account auth={auth} me={me} />}</div></div>);
}
