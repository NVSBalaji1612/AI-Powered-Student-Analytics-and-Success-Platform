import { useEffect, useState } from "react";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { call, downloadCsv, errText, JSON_HEADERS } from "./api";

type Row = { id: number; code: string; name: string; department: string; successScore: number | null; completeness: number | null; segment: string; segmentLabel: string; academicRisk: string; placementRisk: string; components: Record<string, number | null> };
type Overview = {
  summary: { students: number; avgSuccess: number | null; highAcademicRisk: number; highPlacementRisk: number; avgCompletenessPercent: number | null };
  distribution: { label: string; count: number }[];
  segments: { code: string; label: string; count: number; action: string }[];
  departments: { department: string; students: number; avgSuccess: number | null; suppressed: boolean }[];
  components: { code: string; label: string; weight: number; mean: number | null }[];
  students: Row[]; lmsTrend: { weekStart: string; avgLogins: number | null; completionPercent: number | null }[];
  departmentsAvailable: string[]; method: { weights: { label: string; weight: number }[]; definitions: string[] };
};
type Driver = { code: string; label: string; weight: number; normalisedWeight: number | null; score: number | null; institutionMean: number | null; points: number | null; deltaPoints: number | null };
type Detail = { row: Row; suggestedAction: string; drivers: Driver[]; missingComponents: string[]; engagement: { category: string; title: string; occurredOn: string }[]; lmsWeeks: { weekStart: string; logins: number; due: number; submitted: number }[]; placement: Record<string, number | null>; notes: string[] };
type Quality = { source: string; studentsWithData: number; totalStudents: number; coveragePercent: number | null; note: string };
type Pred = { prediction: { probability: number; model_version: string; approval_status: string }; band: string };

const RISK: Record<string, string> = { HIGH: "#b3261e", MEDIUM: "#b26a00", LOW: "#1b7f3b", UNKNOWN: "#6b6f80" };
const SEG: Record<string, string> = { NEEDS_HOLISTIC_SUPPORT: "#b3261e", HIGH_ACADEMIC_LOW_PLACEMENT: "#b26a00", PLACEMENT_READY_ACADEMIC_RISK: "#8a4fff", DISENGAGED: "#6b6f80", STAR_PERFORMER: "#1b7f3b", ON_TRACK: "#3b3fc4" };
const Badge = ({ text, color }: { text: string; color: string }) => <span className="badge" style={{ background: color }}>{text}</span>;
const red = { color: "#b00020" } as const;

export default function Dashboard({ auth }: { auth: string }) {
  const [ov, setOv] = useState<Overview | null>(null); const [detail, setDetail] = useState<Detail | null>(null);
  const [quality, setQuality] = useState<Quality[] | null>(null); const [pred, setPred] = useState<Pred | null>(null);
  const [dept, setDept] = useState(""); const [seg, setSeg] = useState(""); const [error, setError] = useState(""); const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false); const [showMethod, setShowMethod] = useState(false);
  useEffect(() => { void load("", ""); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  async function run(f: () => Promise<void>) { setError(""); setInfo(""); try { await f(); } catch (e) { setError(errText(e)); } }
  async function load(d: string, s: string) {
    await run(async () => {
      setLoading(true);
      try {
        const q = new URLSearchParams(); if (d) q.set("department", d); if (s) q.set("segment", s);
        setOv(await call<Overview>(auth, `/api/v1/success/overview?${q.toString()}`));
      } finally { setLoading(false); }
    });
  }
  const pickDept = (d: string) => { setDept(d); void load(d, seg); };
  const pickSeg = (s: string) => { setSeg(s); void load(dept, s); };
  const open = (id: number) => run(async () => { setPred(null); setDetail(await call<Detail>(auth, `/api/v1/success/students/${id}`)); });
  const loadQuality = () => run(async () => setQuality(await call<Quality[]>(auth, "/api/v1/success/data-quality")));
  const runPrediction = (id: number) => run(async () => setPred(await call<Pred>(auth, `/api/v1/students/${id}/prediction`)));
  const openCase = (r: Row) => run(async () => {
    const d = await call<{ info: { id: number } }>(auth, "/api/v1/interventions", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ studentId: r.id, reason: `Success dashboard: ${r.segmentLabel}`.slice(0, 300) }) });
    setInfo(`Support case ${d.info.id} created for ${r.code}. Manage it in Support cases below.`);
  });

  return (<section><h2>Student success dashboard</h2>
    <div className="banner">Synthetic demo data. Scores are decision support for human review, not judgments about students.</div>
    <button onClick={() => load(dept, seg)} disabled={loading}>{loading ? "Loading..." : "Load success dashboard"}</button>
    <button onClick={() => setShowMethod(!showMethod)}>How the score works</button>
    {ov && <button onClick={() => downloadCsv("success_scores.csv", ["code", "name", "department", "success_score", "data_completeness_pct", "segment", "academic_risk", "placement_risk"], ov.students.map(r => [r.code, r.name, r.department, r.successScore, r.completeness, r.segmentLabel, r.academicRisk, r.placementRisk]))}>Export list (CSV)</button>}
    {error && <p role="alert" style={red}>{error}</p>}{info && <p>{info}</p>}
    {showMethod && ov && <div><h3>Weights</h3><table><tbody>{ov.method.weights.map(w => <tr key={w.label}><td>{w.label}</td><td>{Math.round(w.weight * 100)}%</td></tr>)}</tbody></table>
      <ul>{ov.method.definitions.map(d => <li key={d}><small>{d}</small></li>)}</ul></div>}
    {ov && <div>
      <div>Department <select aria-label="department" value={dept} onChange={e => pickDept(e.target.value)}><option value="">All</option>{ov.departmentsAvailable.map(d => <option key={d}>{d}</option>)}</select>
        {" "}Segment <select aria-label="segment" value={seg} onChange={e => pickSeg(e.target.value)}><option value="">All</option>{ov.segments.map(s => <option key={s.code} value={s.code}>{s.label}</option>)}</select></div>
      <div className="cards">
        <div className="card"><b>{ov.summary.students}</b><span>Students in view</span></div>
        <div className="card"><b>{ov.summary.avgSuccess ?? "n/a"}</b><span>Average Success Score</span></div>
        <div className="card"><b>{ov.summary.highAcademicRisk}</b><span>High academic risk</span></div>
        <div className="card"><b>{ov.summary.highPlacementRisk}</b><span>High placement risk</span></div>
        <div className="card"><b>{ov.summary.avgCompletenessPercent ?? "n/a"}%</b><span>Data completeness</span></div>
      </div>
      <div className="grid2">
        <div><h3>Success Score distribution</h3><ResponsiveContainer width="100%" height={220}><BarChart data={ov.distribution}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="label" /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="count" fill="#3b3fc4" /></BarChart></ResponsiveContainer></div>
        <div><h3>Segments</h3><ResponsiveContainer width="100%" height={220}><BarChart layout="vertical" data={ov.segments}><CartesianGrid strokeDasharray="3 3" /><XAxis type="number" allowDecimals={false} /><YAxis type="category" dataKey="label" width={200} tick={{ fontSize: 11 }} /><Tooltip /><Bar dataKey="count">{ov.segments.map(s => <Cell key={s.code} fill={SEG[s.code] ?? "#3b3fc4"} />)}</Bar></BarChart></ResponsiveContainer></div>
        <div><h3>Average score by department</h3><ResponsiveContainer width="100%" height={220}><BarChart data={ov.departments.map(d => ({ name: d.suppressed ? `${d.department} (hidden)` : d.department, avg: d.avgSuccess ?? 0 }))}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis domain={[0, 100]} /><Tooltip /><Bar dataKey="avg" fill="#14a3c7" /></BarChart></ResponsiveContainer><small>Groups under 3 students are hidden.</small></div>
        <div><h3>Indicator averages (0-100)</h3><ResponsiveContainer width="100%" height={220}><BarChart layout="vertical" data={ov.components.map(c => ({ label: c.label, mean: c.mean ?? 0 }))}><CartesianGrid strokeDasharray="3 3" /><XAxis type="number" domain={[0, 100]} /><YAxis type="category" dataKey="label" width={170} tick={{ fontSize: 11 }} /><Tooltip /><Bar dataKey="mean" fill="#7a5af8" /></BarChart></ResponsiveContainer></div>
        <div><h3>LMS activity by week</h3><ResponsiveContainer width="100%" height={220}><LineChart data={ov.lmsTrend}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="weekStart" tick={{ fontSize: 10 }} /><YAxis /><Tooltip /><Legend /><Line type="monotone" dataKey="avgLogins" name="Avg logins" stroke="#3b3fc4" /><Line type="monotone" dataKey="completionPercent" name="Assignment completion %" stroke="#14a3c7" /></LineChart></ResponsiveContainer></div>
      </div>
      <h3>Segments and suggested actions</h3>
      <table><thead><tr><th>Segment</th><th>Students</th><th>Suggested action</th><th></th></tr></thead><tbody>{ov.segments.map(s => <tr key={s.code}><td><Badge text={s.label} color={SEG[s.code] ?? "#3b3fc4"} /></td><td>{s.count}</td><td>{s.action}</td><td><button onClick={() => pickSeg(s.code)}>Filter</button></td></tr>)}</tbody></table>
      <h3>Students (lowest Success Score first)</h3>
      {ov.students.length === 0 ? <p>No students match these filters.</p> : <table><thead><tr><th>Code</th><th>Name</th><th>Department</th><th>Score</th><th>Data</th><th>Segment</th><th>Academic risk</th><th>Placement risk</th></tr></thead>
        <tbody>{ov.students.map(r => <tr key={r.id} className="click" onClick={() => open(r.id)}><td>{r.code}</td><td>{r.name}</td><td>{r.department}</td><td><b>{r.successScore}</b></td><td>{r.completeness}%</td><td><Badge text={r.segmentLabel} color={SEG[r.segment] ?? "#3b3fc4"} /></td><td><Badge text={r.academicRisk} color={RISK[r.academicRisk] ?? "#6b6f80"} /></td><td><Badge text={r.placementRisk} color={RISK[r.placementRisk] ?? "#6b6f80"} /></td></tr>)}</tbody></table>}
      <small>Click a student to see what drives their score.</small>
    </div>}
    {detail && <div><h3>{detail.row.code}: {detail.row.name} (score {detail.row.successScore}, data {detail.row.completeness}%)</h3>
      <p><Badge text={detail.row.segmentLabel} color={SEG[detail.row.segment] ?? "#3b3fc4"} /> Suggested: {detail.suggestedAction}</p>
      <div className="grid2"><div><h3>What drives the score (points vs institution average)</h3>
        <ResponsiveContainer width="100%" height={240}><BarChart layout="vertical" data={detail.drivers.map(d => ({ label: d.label, delta: d.deltaPoints ?? 0 }))}><CartesianGrid strokeDasharray="3 3" /><XAxis type="number" /><YAxis type="category" dataKey="label" width={170} tick={{ fontSize: 11 }} /><Tooltip /><Bar dataKey="delta">{detail.drivers.map(d => <Cell key={d.code} fill={(d.deltaPoints ?? 0) < 0 ? "#b3261e" : "#1b7f3b"} />)}</Bar></BarChart></ResponsiveContainer></div>
        <div><table><thead><tr><th>Indicator</th><th>Score</th><th>Avg</th><th>Weight</th><th>Points</th></tr></thead><tbody>{detail.drivers.map(d => <tr key={d.code}><td>{d.label}</td><td>{d.score}</td><td>{d.institutionMean}</td><td>{d.normalisedWeight}%</td><td>{d.points}</td></tr>)}</tbody></table>
          {detail.missingComponents.length > 0 && <p><small>Missing data (skipped, not counted as zero): {detail.missingComponents.join(", ")}</small></p>}</div></div>
      {detail.engagement.length > 0 && <p><small>Recent engagement: {detail.engagement.map(e => `${e.category} - ${e.title}`).join("; ")}</small></p>}
      {Object.keys(detail.placement).length > 0 && <p><small>Placement scores: aptitude {detail.placement.aptitude ?? "missing"}, coding {detail.placement.coding ?? "missing"}, mock interview {detail.placement.mockInterview ?? "missing"}</small></p>}
      <button onClick={() => openCase(detail.row)}>Open support case</button> <button onClick={() => runPrediction(detail.row.id)}>Run ML academic-risk signal</button>
      {pred && <span> ML signal: {(pred.prediction.probability * 100).toFixed(0)}% ({pred.band}), model {pred.prediction.model_version}, {pred.prediction.approval_status}</span>}
      {detail.notes.map(n => <p key={n}><small>{n}</small></p>)}</div>}
    <h3>Data quality</h3><button onClick={loadQuality}>Check data coverage</button>
    {quality && <table><thead><tr><th>Source</th><th>Students with data</th><th>Coverage</th><th>Notes</th></tr></thead><tbody>{quality.map(q => <tr key={q.source}><td>{q.source}</td><td>{q.studentsWithData} / {q.totalStudents}</td><td>{q.coveragePercent}%</td><td><small>{q.note}</small></td></tr>)}</tbody></table>}
  </section>);
}
