import { useEffect, useState } from "react";
import { CartesianGrid, Legend, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { call, errText, JSON_HEADERS } from "./api";
const red = { color: "#b00020" } as const;

type Metric = { label: string; attendancePercent: number | null; averageScorePercent: number | null; students: number; suppressed: boolean };
type Overview = { activeStudents: number; attendancePercent: number | null; averageScorePercent: number | null; missingResultPercent: number | null; bySubject: Metric[]; byDepartment: Metric[]; attendanceTrend: { weekStart: string; attendancePercent: number | null; sessions: number }[]; definitions: string[] };
const MetricTable = ({ rows }: { rows: Metric[] }) => <table><thead><tr><th>Group</th><th>Students</th><th>Attendance %</th><th>Avg score %</th></tr></thead>
  <tbody>{rows.map(m => <tr key={m.label}><td>{m.label}</td><td>{m.students}</td>{m.suppressed ? <td colSpan={2}>hidden (cohort too small)</td> : <><td>{m.attendancePercent ?? "n/a"}</td><td>{m.averageScorePercent ?? "n/a"}</td></>}</tr>)}</tbody></table>;

export function Analytics({ auth }: { auth: string }) {
  const [ov, setOv] = useState<Overview | null>(null); const [error, setError] = useState("");
  const load = async () => { setError(""); try { setOv(await call<Overview>(auth, "/api/v1/analytics/overview")); } catch (e) { setError(errText(e)); } };
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (<section><h2>Academic analytics</h2>{error && <p role="alert" style={red}>{error}</p>}{!ov && !error && <p>Loading...</p>}
    {ov && <div><div className="cards"><div className="card"><b>{ov.activeStudents}</b><span>Students</span></div><div className="card"><b>{ov.attendancePercent ?? "n/a"}%</b><span>Attendance</span></div>
      <div className="card"><b>{ov.averageScorePercent ?? "n/a"}%</b><span>Average score</span></div><div className="card"><b>{ov.missingResultPercent ?? "n/a"}%</b><span>Missing results</span></div></div>
      <div className="grid2"><div><h3>By subject</h3><MetricTable rows={ov.bySubject} /></div><div><h3>By department</h3><MetricTable rows={ov.byDepartment} /></div></div>
      <h3>Weekly attendance</h3><ResponsiveContainer width="100%" height={220}><LineChart data={ov.attendanceTrend}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="weekStart" tick={{ fontSize: 10 }} /><YAxis domain={[0, 100]} /><Tooltip /><Legend /><Line type="monotone" dataKey="attendancePercent" name="Attendance %" stroke="#3b3fc4" /></LineChart></ResponsiveContainer>
      {ov.definitions.map(d => <p key={d}><small>{d}</small></p>)}</div>}</section>);
}

type RiskRow = { studentId: number; studentCode: string; probability: number; band: string; topFactor: string | null; missingInputs: string[] };
export function RiskOverview({ auth }: { auth: string }) {
  const [rows, setRows] = useState<RiskRow[] | null>(null); const [error, setError] = useState(""); const [info, setInfo] = useState("");
  const load = async () => { setError(""); setRows(null); try { setRows(await call<RiskRow[]>(auth, "/api/v1/risk/overview")); } catch (e) { setError(errText(e)); } };
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const openCase = async (r: RiskRow) => {
    setError(""); setInfo("");
    try { const d = await call<{ info: { id: number } }>(auth, "/api/v1/interventions", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ studentId: r.studentId, reason: "Flagged for support review from ML risk signal" }) }); setInfo(`Support case ${d.info.id} created for ${r.studentCode}.`); }
    catch (e) { setError(errText(e)); }
  };
  return (<section><h2>ML risk signals (highest first)</h2><p><small>Advisory signals for human review. The demo model is trained on synthetic data and is unapproved.</small></p>
    {error && <p role="alert" style={red}>{error}</p>}{info && <p>{info}</p>}{!rows && !error && <p>Loading (one model call per student)...</p>}
    {rows && <table><thead><tr><th>Student</th><th>Signal</th><th>Band</th><th>Main factor</th><th>Missing inputs</th><th></th></tr></thead>
      <tbody>{rows.map(r => <tr key={r.studentId}><td>{r.studentCode}</td><td>{(r.probability * 100).toFixed(0)}%</td><td>{r.band}</td><td>{r.topFactor ?? "-"}</td><td>{r.missingInputs.length}</td><td><button onClick={() => openCase(r)}>Open support case</button></td></tr>)}</tbody></table>}</section>);
}

const FIELDS = ["prev_score_mean", "score_slope", "attendance_pct", "attendance_slope", "assignment_completion", "missing_score_rate"] as const;
type WI = { probability: number; model_version: string; approval_status: string; factors: { feature: string; contribution: number; direction: string }[]; missing_inputs: string[]; notes: string[] };
export function WhatIf({ auth }: { auth: string }) {
  const [vals, setVals] = useState<Record<string, string>>({}); const [res, setRes] = useState<WI | null>(null); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  const run = async () => {
    setBusy(true); setError(""); setRes(null);
    const body: Record<string, number> = {}; FIELDS.forEach(f => { if (vals[f] !== undefined && vals[f] !== "") body[f] = Number(vals[f]); });
    try { setRes(await call<WI>(auth, "/api/v1/predictions/what-if", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify(body) })); } catch (e) { setError(errText(e)); } finally { setBusy(false); }
  };
  return (<section><h2>What-if simulator (hypothetical, never saved as a record)</h2>
    <p><small>Percent fields 0-100, slopes -50 to 50, missing_score_rate 0-1. Blank fields are treated as missing.</small></p>
    {FIELDS.map(f => <div key={f}><label>{f} <input type="number" value={vals[f] ?? ""} onChange={e => setVals({ ...vals, [f]: e.target.value })} /></label></div>)}
    <button onClick={run} disabled={busy}>{busy ? "Running..." : "Run simulation"}</button>
    {error && <p role="alert" style={red}>{error}</p>}
    {res && <div><h3>Hypothetical risk signal: {(res.probability * 100).toFixed(0)}%</h3><p><small>Model {res.model_version} ({res.approval_status}). Missing inputs: {res.missing_inputs.join(", ") || "none"}</small></p>
      <ul>{res.factors.map(f => <li key={f.feature}>{f.feature}: {f.direction} risk ({f.contribution.toFixed(2)})</li>)}</ul>{res.notes.map(n => <p key={n}><small>{n}</small></p>)}</div>}</section>);
}

type Gov = { model: { version: string; trained_at_utc: string; dataset: string; features: string[]; chosen: string; evaluation: Record<string, Record<string, unknown>>; approval_status: string; disclaimer: string };
  currentStatus: string; decisions: { id: number; modelVersion: string; decision: string; reason: string; decidedBy: string; decidedAt: string }[]; notes: string[] };
const METRICS = ["roc_auc", "pr_auc", "precision", "recall", "f1", "fpr", "fnr", "brier"];
export function Governance({ auth }: { auth: string }) {
  const [gov, setGov] = useState<Gov | null>(null); const [error, setError] = useState(""); const [decision, setDecision] = useState("REJECTED"); const [reason, setReason] = useState("");
  const load = async () => { setError(""); try { setGov(await call<Gov>(auth, "/api/v1/governance/model")); } catch (e) { setError(errText(e)); } };
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const submit = async () => {
    if (!gov) return; setError("");
    try { setGov(await call<Gov>(auth, "/api/v1/governance/model/decision", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ modelVersion: gov.model.version, decision, reason }) })); setReason(""); }
    catch (e) { setError(errText(e)); }
  };
  return (<section><h2>AI governance: model card and approval</h2>{error && <p role="alert" style={red}>{error}</p>}{!gov && !error && <p>Loading...</p>}
    {gov && <div><div className="cards"><div className="card"><b>{gov.currentStatus}</b><span>Your institution's decision for this version</span></div><div className="card"><b>{gov.model.approval_status}</b><span>Model status flag</span></div></div>
      <p>Version <b>{gov.model.version}</b>, trained {gov.model.trained_at_utc}, dataset {gov.model.dataset}, served model: {gov.model.chosen}</p>
      <p><small>{gov.model.disclaimer}</small></p><p><small>Features: {gov.model.features.join(", ")}</small></p>
      <h3>Evaluation on held-out later terms</h3>
      <table><thead><tr><th>Model</th>{METRICS.map(m => <th key={m}>{m}</th>)}<th>Confusion [[TN,FP],[FN,TP]]</th></tr></thead>
        <tbody>{Object.entries(gov.model.evaluation).map(([name, m]) => <tr key={name}><td>{name}</td>{METRICS.map(k => <td key={k}>{Number(m[k]).toFixed(3)}</td>)}<td>{JSON.stringify(m["confusion"])}</td></tr>)}</tbody></table>
      {gov.notes.map(n => <p key={n}><small>{n}</small></p>)}
      <h3>Record a decision</h3>
      <select aria-label="decision" value={decision} onChange={e => setDecision(e.target.value)}><option>APPROVED</option><option>REJECTED</option><option>RETIRED</option></select>{" "}
      <input aria-label="reason" placeholder="Reason (10+ characters)" value={reason} onChange={e => setReason(e.target.value)} size={50} /> <button onClick={submit}>Save decision</button>
      <h3>Decision history</h3>{gov.decisions.length === 0 ? <p>No decisions yet.</p> : <table><thead><tr><th>When</th><th>Version</th><th>Decision</th><th>By</th><th>Reason</th></tr></thead>
        <tbody>{gov.decisions.map(d => <tr key={d.id}><td>{d.decidedAt}</td><td>{d.modelVersion}</td><td>{d.decision}</td><td>{d.decidedBy}</td><td>{d.reason}</td></tr>)}</tbody></table>}</div>}</section>);
}

type Ev = { id: number; actor: string; action: string; resource: string; at: string };
export function Audit({ auth }: { auth: string }) {
  const [rows, setRows] = useState<Ev[] | null>(null); const [action, setAction] = useState(""); const [error, setError] = useState("");
  const load = async (a: string) => { setError(""); try { setRows(await call<Ev[]>(auth, `/api/v1/audit/events?limit=100${a ? `&action=${encodeURIComponent(a)}` : ""}`)); } catch (e) { setError(errText(e)); } };
  useEffect(() => { void load(""); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return (<section><h2>Security and audit events</h2><p><small>Read-only. Shows the latest 100 events for your institution (logins that failed, account lockouts, case changes, imports, model decisions, Copilot use). No passwords or question text are stored.</small></p>
    <input aria-label="action filter" placeholder="Filter by action, e.g. LOGIN_FAILED" value={action} onChange={e => setAction(e.target.value)} size={36} /> <button onClick={() => load(action)}>Apply</button>
    {error && <p role="alert" style={red}>{error}</p>}{!rows && !error && <p>Loading...</p>}
    {rows && (rows.length === 0 ? <p>No events.</p> : <table><thead><tr><th>Time (UTC)</th><th>Who</th><th>Action</th><th>Resource</th></tr></thead>
      <tbody>{rows.map(r => <tr key={r.id}><td>{r.at}</td><td>{r.actor}</td><td>{r.action}</td><td>{r.resource}</td></tr>)}</tbody></table>)}</section>);
}
