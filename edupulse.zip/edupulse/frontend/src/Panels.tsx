import { useState } from "react";
import { call, errText, JSON_HEADERS } from "./api";

type CaseRow = { id: number; studentId: number; studentCode: string; reason: string; status: string; assignedTo: string | null; openedAt: string | null; closedAt: string | null; outcomeNote: string | null; openAttendance: number | null; openScore: number | null; closeAttendance: number | null; closeScore: number | null };
type ActionRow = { id: number; type: string; note: string | null; dueDate: string | null; status: string };
type Detail = { info: CaseRow; actions: ActionRow[] };
const NEXT: Record<string, string[]> = { NEW: ["REVIEWED", "RESOLVED"], REVIEWED: ["ASSIGNED", "RESOLVED"], ASSIGNED: ["IN_PROGRESS"], IN_PROGRESS: ["FOLLOW_UP"], FOLLOW_UP: ["RESOLVED", "IN_PROGRESS"], RESOLVED: ["IN_PROGRESS"] };
const TYPES = ["TUTORING", "ASSIGNMENT_SUPPORT", "FACULTY_CONSULTATION", "ATTENDANCE_DISCUSSION", "STUDY_PLANNING", "COUNSELLING_REFERRAL", "FOLLOW_UP_MEETING"];
const red = { color: "#b00020" } as const;

export function InterventionsPanel({ auth }: { auth: string }) {
  const [cases, setCases] = useState<CaseRow[] | null>(null);
  const [detail, setDetail] = useState<Detail | null>(null);
  const [metrics, setMetrics] = useState<unknown>(null);
  const [error, setError] = useState(""); const [studentId, setStudentId] = useState(""); const [reason, setReason] = useState("");
  const [note, setNote] = useState(""); const [type, setType] = useState(TYPES[0]); const [due, setDue] = useState(""); const [anote, setAnote] = useState("");
  async function run<T>(f: () => Promise<T>): Promise<T | undefined> { setError(""); try { return await f(); } catch (e) { setError(errText(e)); return undefined; } }
  const loadCases = () => run(async () => setCases(await call<CaseRow[]>(auth, "/api/v1/interventions")));
  const open = (id: number) => run(async () => setDetail(await call<Detail>(auth, `/api/v1/interventions/${id}`)));
  const loadMetrics = () => run(async () => setMetrics(await call<unknown>(auth, "/api/v1/interventions/metrics")));
  const create = () => run(async () => {
    const d = await call<Detail>(auth, "/api/v1/interventions", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ studentId: Number(studentId), reason }) });
    setDetail(d); setReason(""); await loadCases();
  });
  const move = (to: string) => detail && run(async () => {
    const d = await call<Detail>(auth, `/api/v1/interventions/${detail.info.id}/transition`, { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ to, note }) });
    setDetail(d); setNote(""); await loadCases();
  });
  const addAction = () => detail && run(async () => {
    setDetail(await call<Detail>(auth, `/api/v1/interventions/${detail.info.id}/actions`, { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ type, note: anote, dueDate: due || null }) }));
    setAnote("");
  });
  const complete = (aid: number) => detail && run(async () => setDetail(await call<Detail>(auth, `/api/v1/interventions/${detail.info.id}/actions/${aid}/complete`, { method: "POST" })));
  return (<section><h2>Support cases (human review and follow-up)</h2>
    <div>Student id <input aria-label="student id" value={studentId} onChange={e => setStudentId(e.target.value)} size={4} /> Reason <input aria-label="reason" value={reason} onChange={e => setReason(e.target.value)} size={40} />
      <button onClick={create}>Create case</button> <button onClick={loadCases}>Load cases</button> <button onClick={loadMetrics}>Load outcome metrics</button></div>
    {error && <p role="alert" style={red}>{error}</p>}
    {cases && (cases.length === 0 ? <p>No cases yet.</p> : <table><thead><tr><th>Id</th><th>Student</th><th>Status</th><th>Assigned</th><th>Reason</th><th></th></tr></thead>
      <tbody>{cases.map(c => <tr key={c.id}><td>{c.id}</td><td>{c.studentCode}</td><td>{c.status}</td><td>{c.assignedTo ?? "-"}</td><td>{c.reason}</td><td><button onClick={() => open(c.id)}>Open</button></td></tr>)}</tbody></table>)}
    {detail && <div><h3>Case {detail.info.id}: {detail.info.studentCode} ({detail.info.status})</h3>
      <p>Attendance at open/close: {detail.info.openAttendance ?? "n/a"}% / {detail.info.closeAttendance ?? "n/a"}% | Avg score at open/close: {detail.info.openScore ?? "n/a"}% / {detail.info.closeScore ?? "n/a"}%</p>
      {detail.info.outcomeNote && <p>Resolution note: {detail.info.outcomeNote}</p>}
      <div>Note <input aria-label="note" value={note} onChange={e => setNote(e.target.value)} size={40} /> {(NEXT[detail.info.status] ?? []).map(t => <button key={t} onClick={() => move(t)}>Move to {t}</button>)}</div>
      <table><thead><tr><th>Action</th><th>Note</th><th>Due</th><th>Status</th><th></th></tr></thead><tbody>{detail.actions.map(a => <tr key={a.id}><td>{a.type}</td><td>{a.note ?? ""}</td><td>{a.dueDate ?? ""}</td><td>{a.status}</td><td>{a.status === "OPEN" && <button onClick={() => complete(a.id)}>Mark done</button>}</td></tr>)}</tbody></table>
      <div>Add follow-up <select aria-label="action type" value={type} onChange={e => setType(e.target.value)}>{TYPES.map(t => <option key={t}>{t}</option>)}</select> <input aria-label="due date" type="date" value={due} onChange={e => setDue(e.target.value)} /> <input aria-label="action note" value={anote} onChange={e => setAnote(e.target.value)} placeholder="note" /> <button onClick={addAction}>Add</button></div></div>}
    {metrics !== null && <pre>{JSON.stringify(metrics, null, 2)}</pre>}
  </section>);
}

type RowError = { row: number; message: string };
type Preview = { rowsTotal: number; validRows: number; rejectedRows: number; errors: RowError[]; sample: string[][] };
type ImportResult = { imported: number; rejected: number; errors: RowError[] };

export function ImportPanel({ auth }: { auth: string }) {
  const [source, setSource] = useState("students"); const [file, setFile] = useState<File | null>(null); const [error, setError] = useState(""); const [info, setInfo] = useState("");
  const [preview, setPreview] = useState<Preview | null>(null); const [history, setHistory] = useState<unknown>(null);
  async function run(f: () => Promise<void>) { setError(""); setInfo(""); try { await f(); } catch (e) { setError(errText(e)); } }
  const form = () => { if (!file) throw new Error("Choose a CSV file first"); const fd = new FormData(); fd.append("file", file); return fd; };
  const doPreview = () => run(async () => setPreview(await call<Preview>(auth, `/api/v1/imports/${source}/preview`, { method: "POST", body: form() })));
  const doCommit = () => run(async () => {
    const r = await call<ImportResult>(auth, `/api/v1/imports/${source}/commit`, { method: "POST", body: form() });
    setInfo(`Imported ${r.imported} rows, rejected ${r.rejected}.`); setPreview(null);
  });
  const template = () => run(async () => {
    const r = await fetch(`/api/v1/imports/${source}/template`, { headers: { Authorization: auth } });
    if (!r.ok) throw new Error(r.status === 401 ? "Not signed in" : `Request failed (${r.status})`);
    const url = URL.createObjectURL(await r.blob()); const a = document.createElement("a"); a.href = url; a.download = `${source}_template.csv`; a.click(); URL.revokeObjectURL(url);
  });
  return (<section><h2>CSV import (validate, preview, then import)</h2>
    <select aria-label="import source" value={source} onChange={e => { setSource(e.target.value); setPreview(null); setInfo(""); }}>{["students", "lms", "placement", "skills", "feedback", "engagement"].map(x => <option key={x}>{x}</option>)}</select> <button onClick={template}>Download template</button> <input aria-label="csv file" type="file" accept=".csv,text/csv" onChange={e => setFile(e.target.files?.[0] ?? null)} />
    <button onClick={doPreview}>Preview</button> <button onClick={doCommit}>Import valid rows</button> <button onClick={() => run(async () => setHistory(await call<unknown>(auth, "/api/v1/imports")))}>History</button>
    {error && <p role="alert" style={red}>{error}</p>}{info && <p>{info}</p>}
    {preview && <div><p>{preview.rowsTotal} rows: {preview.validRows} valid, {preview.rejectedRows} rejected. Nothing is saved until you click Import.</p>
      <ul>{preview.errors.map(e => <li key={e.row}>Row {e.row}: {e.message}</li>)}</ul></div>}
    {history !== null && <pre>{JSON.stringify(history, null, 2)}</pre>}
  </section>);
}

type Doc = { id: number; title: string; uploadedBy: string; chunks: number };
type Source = { documentTitle: string; chunk: number; snippet: string };
type Answer = { mode: string; answer: string; evidence: { label: string; value: string }[]; sources: Source[]; notes: string[] };

export function CopilotPanel({ auth }: { auth: string }) {
  const [docs, setDocs] = useState<Doc[] | null>(null); const [file, setFile] = useState<File | null>(null);
  const [q, setQ] = useState(""); const [ans, setAns] = useState<Answer | null>(null); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  async function run(f: () => Promise<void>) { setError(""); try { await f(); } catch (e) { setError(errText(e)); } }
  const loadDocs = () => run(async () => setDocs(await call<Doc[]>(auth, "/api/v1/documents")));
  const upload = () => run(async () => {
    if (!file) throw new Error("Choose a .txt or .md file first");
    const fd = new FormData(); fd.append("file", file);
    await call<Doc>(auth, "/api/v1/documents", { method: "POST", body: fd }); await loadDocs();
  });
  const remove = (id: number) => run(async () => { await call<unknown>(auth, `/api/v1/documents/${id}`, { method: "DELETE" }); await loadDocs(); });
  const ask = () => run(async () => {
    setBusy(true); setAns(null);
    try { setAns(await call<Answer>(auth, "/api/v1/copilot/ask", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ question: q }) })); } finally { setBusy(false); }
  });
  return (<section><h2>Copilot and knowledge base</h2>
    <div><button onClick={loadDocs}>Load documents</button> <input aria-label="document file" type="file" accept=".txt,.md" onChange={e => setFile(e.target.files?.[0] ?? null)} /> <button onClick={upload}>Upload</button></div>
    {docs && (docs.length === 0 ? <p>No documents.</p> : <ul>{docs.map(d => <li key={d.id}>{d.title} ({d.chunks} passages) <button onClick={() => remove(d.id)}>Delete</button></li>)}</ul>)}
    <div>Question <input aria-label="question" value={q} onChange={e => setQ(e.target.value)} size={50} /> <button onClick={ask} disabled={busy}>{busy ? "Asking..." : "Ask"}</button></div>
    {error && <p role="alert" style={red}>{error}</p>}
    {ans && <div><p><strong>Mode: {ans.mode}</strong></p><p>{ans.answer}</p>
      <h4>Verified data</h4><ul>{ans.evidence.map(e => <li key={e.label}>{e.label}: {e.value}</li>)}</ul>
      <h4>Policy passages (untrusted text)</h4>{ans.sources.length === 0 ? <p>No matching passages.</p> : <ul>{ans.sources.map((s, i) => <li key={i}><em>{s.documentTitle}</em> (passage {s.chunk}): {s.snippet}</li>)}</ul>}
      {ans.notes.map(n => <p key={n}><small>{n}</small></p>)}</div>}
  </section>);
}
