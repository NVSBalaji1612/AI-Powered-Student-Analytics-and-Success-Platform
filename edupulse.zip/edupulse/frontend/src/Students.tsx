import { useEffect, useState } from "react";
import { call, errText } from "./api";

type Student = { id: number; studentCode: string; fullName: string; department: string };
type Att = { subjectCode: string; present: number; absent: number; percent: number | null };
type Res = { subjectCode: string; assessment: string; maxMarks: number; marks: number | null; status: string; heldOn: string };
type Summary = { studentId: number; studentCode: string; fullName: string; attendance: Att[]; overallAttendancePercent: number | null; results: Res[]; averageScorePercent: number | null; definitions: string[] };
type Pred = { prediction: { probability: number; model_version: string; approval_status: string; factors: { feature: string; contribution: number; direction: string }[]; missing_inputs: string[] }; features: Record<string, number | null>; featureNotes: string[]; band: string; guidance: string };
const red = { color: "#b00020" } as const;

export default function Students({ auth }: { auth: string }) {
  const [students, setStudents] = useState<Student[] | null>(null); const [q, setQ] = useState("");
  const [sum, setSum] = useState<Summary | null>(null); const [pred, setPred] = useState<Pred | null>(null); const [error, setError] = useState("");
  async function run(f: () => Promise<void>) { setError(""); try { await f(); } catch (e) { setError(errText(e)); } }
  const load = () => run(async () => setStudents((await call<{ content: Student[] }>(auth, "/api/v1/students?size=100")).content));
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const open = (id: number) => run(async () => { setPred(null); setSum(await call<Summary>(auth, `/api/v1/students/${id}/summary`)); });
  const predict = (id: number) => run(async () => setPred(await call<Pred>(auth, `/api/v1/students/${id}/prediction`)));
  const shown = (students ?? []).filter(s => `${s.studentCode} ${s.fullName} ${s.department}`.toLowerCase().includes(q.trim().toLowerCase()));
  return (<section><h2>Students</h2>
    <input aria-label="search students" placeholder="Search by code, name or department" value={q} onChange={e => setQ(e.target.value)} size={40} /> <button onClick={load}>Reload</button>
    {error && <p role="alert" style={red}>{error}</p>}
    {students === null ? <p>Loading...</p> : shown.length === 0 ? <p>No students match.</p> :
      <table><thead><tr><th>Code</th><th>Name</th><th>Department</th><th></th></tr></thead>
        <tbody>{shown.map(s => <tr key={s.id}><td>{s.studentCode}</td><td>{s.fullName}</td><td>{s.department}</td><td><button onClick={() => open(s.id)}>View</button></td></tr>)}</tbody></table>}
    {sum && <div><h3>{sum.studentCode}: {sum.fullName}</h3>
      <p>Overall attendance: {sum.overallAttendancePercent ?? "n/a"}% | Average score: {sum.averageScorePercent ?? "n/a"}%</p>
      <table><thead><tr><th>Subject</th><th>Present</th><th>Absent</th><th>Attendance %</th></tr></thead><tbody>{sum.attendance.map(a => <tr key={a.subjectCode}><td>{a.subjectCode}</td><td>{a.present}</td><td>{a.absent}</td><td>{a.percent ?? "n/a"}</td></tr>)}</tbody></table>
      <table><thead><tr><th>Date</th><th>Subject</th><th>Assessment</th><th>Marks</th><th>Status</th></tr></thead><tbody>{sum.results.map((r, i) => <tr key={i}><td>{r.heldOn}</td><td>{r.subjectCode}</td><td>{r.assessment}</td><td>{r.marks === null ? "-" : `${r.marks}/${r.maxMarks}`}</td><td>{r.status}</td></tr>)}</tbody></table>
      {sum.definitions.map(t => <p key={t}><small>{t}</small></p>)}
      <button onClick={() => predict(sum.studentId)}>Run ML academic-risk signal</button>
      {pred && <div><h4>Risk signal {(pred.prediction.probability * 100).toFixed(0)}% ({pred.band}), model {pred.prediction.model_version} ({pred.prediction.approval_status})</h4>
        <p><small>Inputs: {Object.entries(pred.features).map(([k, v]) => `${k}=${v ?? "missing"}`).join(", ")}</small></p>
        <ul>{pred.prediction.factors.map(f => <li key={f.feature}>{f.feature}: {f.direction} risk ({f.contribution.toFixed(2)})</li>)}</ul>
        <p><small>{pred.guidance}</small></p></div>}</div>}
  </section>);
}
