import { useEffect, useState } from "react";
import { call, errText, JSON_HEADERS } from "./api";
const red = { color: "#b00020" } as const;

export const ROLE_LABELS: Record<string, string> = { INSTITUTION_ADMIN: "Super Admin", FACULTY: "Faculty", MENTOR: "Mentor", ACADEMIC_ANALYST: "Administrator (analytics)", STUDENT: "Student", AUDITOR: "Read-only auditor" };
const ROLE_OPTIONS = ["INSTITUTION_ADMIN", "FACULTY", "MENTOR", "ACADEMIC_ANALYST", "STUDENT", "AUDITOR"];
type U = { id: number; email: string; fullName: string | null; role: string; active: boolean; createdAt: string | null };
type UserPage = { content: U[]; page: number; size: number; total: number };

export function Users({ auth, selfEmail }: { auth: string; selfEmail: string }) {
  const [data, setData] = useState<UserPage | null>(null); const [q, setQ] = useState(""); const [roleFilter, setRoleFilter] = useState(""); const [page, setPage] = useState(0);
  const [error, setError] = useState(""); const [info, setInfo] = useState("");
  const [email, setEmail] = useState(""); const [name, setName] = useState(""); const [role, setRole] = useState("FACULTY"); const [pw, setPw] = useState("");
  const [resetFor, setResetFor] = useState<number | null>(null); const [resetPw, setResetPw] = useState("");
  async function load(p: number, query: string, rf: string) {
    setError("");
    try {
      const qs = new URLSearchParams({ page: String(p), size: "10" }); if (query.trim()) qs.set("q", query.trim()); if (rf) qs.set("role", rf);
      setData(await call<UserPage>(auth, `/api/v1/admin/users?${qs.toString()}`)); setPage(p);
    } catch (e) { setError(errText(e)); }
  }
  useEffect(() => { void load(0, "", ""); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  async function act(f: () => Promise<unknown>, msg: string) {
    setError(""); setInfo("");
    try { await f(); setInfo(msg); await load(page, q, roleFilter); } catch (e) { setError(errText(e)); }
  }
  const create = () => act(async () => {
    await call<U>(auth, "/api/v1/admin/users", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ email, fullName: name, role, password: pw }) });
    setEmail(""); setName(""); setPw("");
  }, "User created.");
  const update = (u: U, change: { role?: string; active?: boolean }, msg: string) => act(() => call<U>(auth, `/api/v1/admin/users/${u.id}`, { method: "PUT", headers: JSON_HEADERS, body: JSON.stringify(change) }), msg);
  const remove = (u: U) => { if (window.confirm(`Delete ${u.email}? The account is disabled and hidden but its records are kept for audit.`)) void act(() => call<unknown>(auth, `/api/v1/admin/users/${u.id}`, { method: "DELETE" }), "User deleted."); };
  const reset = (u: U) => act(async () => { await call<unknown>(auth, `/api/v1/admin/users/${u.id}/reset-password`, { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ password: resetPw }) }); setResetFor(null); setResetPw(""); }, "Password reset.");
  const pages = data ? Math.max(1, Math.ceil(data.total / data.size)) : 1;
  return (<section><h2>User management (Super Admin)</h2>
    <p><small>Passwords need 12+ characters with upper-case, lower-case and a digit. You cannot change your own role or status, and the last active Super Admin cannot be removed. Deleting disables the account and keeps its history.</small></p>
    <div className="cards" style={{ gridTemplateColumns: "1fr" }}><div className="card"><b style={{ fontSize: 15 }}>Create a user</b>
      <input aria-label="new email" placeholder="email" value={email} onChange={e => setEmail(e.target.value)} /> <input aria-label="new name" placeholder="full name (optional)" value={name} onChange={e => setName(e.target.value)} />{" "}
      <select aria-label="new role" value={role} onChange={e => setRole(e.target.value)}>{ROLE_OPTIONS.map(r => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}</select>{" "}
      <input aria-label="new password" type="password" placeholder="temporary password" value={pw} onChange={e => setPw(e.target.value)} /> <button onClick={create}>Create</button></div></div>
    <div><input aria-label="search users" placeholder="Search email or name" value={q} onChange={e => setQ(e.target.value)} />{" "}
      <select aria-label="filter role" value={roleFilter} onChange={e => { setRoleFilter(e.target.value); void load(0, q, e.target.value); }}><option value="">All roles</option>{ROLE_OPTIONS.map(r => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}</select>{" "}
      <button onClick={() => load(0, q, roleFilter)}>Search</button></div>
    {error && <p role="alert" style={red}>{error}</p>}{info && <p>{info}</p>}
    {!data ? <p>Loading...</p> : data.content.length === 0 ? <p>No users found.</p> :
      <table><thead><tr><th>Email</th><th>Name</th><th>Role</th><th>Status</th><th>Actions</th></tr></thead><tbody>{data.content.map(u => { const self = u.email === selfEmail; return (
        <tr key={u.id}><td>{u.email}</td><td>{u.fullName ?? ""}</td>
          <td><select aria-label={`role of ${u.email}`} value={u.role} disabled={self} onChange={e => void update(u, { role: e.target.value }, "Role updated.")}>{ROLE_OPTIONS.map(r => <option key={r} value={r}>{ROLE_LABELS[r]}</option>)}</select></td>
          <td>{u.active ? "Active" : "Inactive"}</td>
          <td>{self ? <small>(you)</small> : <>
            <button onClick={() => update(u, { active: !u.active }, u.active ? "User deactivated." : "User activated.")}>{u.active ? "Deactivate" : "Activate"}</button>
            <button onClick={() => { setResetFor(resetFor === u.id ? null : u.id); setResetPw(""); }}>Reset password</button>
            <button onClick={() => remove(u)}>Delete</button></>}
            {resetFor === u.id && <div><input aria-label="new password for user" type="password" placeholder="new password" value={resetPw} onChange={e => setResetPw(e.target.value)} /> <button onClick={() => reset(u)}>Save</button></div>}</td></tr>); })}</tbody></table>}
    {data && <p><button disabled={page <= 0} onClick={() => load(page - 1, q, roleFilter)}>Previous</button> Page {page + 1} of {pages} ({data.total} users) <button disabled={page + 1 >= pages} onClick={() => load(page + 1, q, roleFilter)}>Next</button></p>}
  </section>);
}

type AiStatus = { provider: string; model: string; baseUrlHost: string | null; apiKeyConfigured: boolean; enabled: boolean; hint: string };
export function AiSettings({ auth }: { auth: string }) {
  const [st, setSt] = useState<AiStatus | null>(null); const [result, setResult] = useState<{ ok: boolean; message: string } | null>(null); const [error, setError] = useState(""); const [busy, setBusy] = useState(false);
  const load = async () => { setError(""); try { setSt(await call<AiStatus>(auth, "/api/v1/admin/ai/status")); } catch (e) { setError(errText(e)); } };
  useEffect(() => { void load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  const test = async () => { setBusy(true); setError(""); setResult(null); try { setResult(await call<{ ok: boolean; message: string }>(auth, "/api/v1/admin/ai/test", { method: "POST" })); } catch (e) { setError(errText(e)); } finally { setBusy(false); } };
  return (<section><h2>AI Copilot settings</h2>{error && <p role="alert" style={red}>{error}</p>}
    {st && <div><div className="cards"><div className="card"><b>{st.enabled ? "Connected" : "Not connected"}</b><span>Language model</span></div><div className="card"><b style={{ fontSize: 16 }}>{st.provider}</b><span>Provider</span></div>
      <div className="card"><b style={{ fontSize: 16 }}>{st.model || "none"}</b><span>Model</span></div><div className="card"><b style={{ fontSize: 16 }}>{st.baseUrlHost ?? "none"}</b><span>Server host</span></div></div>
      <p>API key configured: {st.apiKeyConfigured ? "yes (never shown)" : "no"}</p><p><small>{st.hint}</small></p>
      <button onClick={test} disabled={busy}>{busy ? "Testing..." : "Test connection"}</button>
      {result && <p role="status" style={{ color: result.ok ? "#1b7f3b" : "#b00020" }}>{result.ok ? "Working. " : "Failed. "}{result.message}</p>}
      <p><small>Settings are read from the server's .env file; the browser never sees keys. Without a model the Copilot still shows verified figures and cited policy passages. Free local setup: run scripts\enable-local-ai.cmd.</small></p></div>}</section>);
}

export function Account({ auth, me }: { auth: string; me: { email: string; role: string; institutionId: number } }) {
  const [cur, setCur] = useState(""); const [nw, setNw] = useState(""); const [again, setAgain] = useState(""); const [error, setError] = useState(""); const [info, setInfo] = useState("");
  const submit = async () => {
    setError(""); setInfo("");
    if (nw !== again) { setError("The new passwords do not match."); return; }
    try { await call<unknown>(auth, "/api/v1/me/password", { method: "POST", headers: JSON_HEADERS, body: JSON.stringify({ currentPassword: cur, newPassword: nw }) }); setInfo("Password changed. Sign in again with the new password."); setCur(""); setNw(""); setAgain(""); }
    catch (e) { setError(errText(e)); }
  };
  return (<section><h2>My account</h2><p>{me.email} - {ROLE_LABELS[me.role] ?? me.role} (institution {me.institutionId})</p>
    {me.role === "STUDENT" && <p><small>Your account works, but the student portal (courses, assignments, marks) is not built yet.</small></p>}
    <h3>Change password</h3><div><input aria-label="current password" type="password" placeholder="current password" value={cur} onChange={e => setCur(e.target.value)} /></div>
    <div><input aria-label="new password" type="password" placeholder="new password (12+ chars)" value={nw} onChange={e => setNw(e.target.value)} /></div>
    <div><input aria-label="repeat new password" type="password" placeholder="repeat new password" value={again} onChange={e => setAgain(e.target.value)} /></div>
    <button onClick={submit} disabled={!cur || !nw}>Change password</button>{error && <p role="alert" style={red}>{error}</p>}{info && <p>{info}</p>}</section>);
}
