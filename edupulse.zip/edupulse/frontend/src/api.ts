export async function call<T>(auth: string, path: string, init: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = { Authorization: auth, ...((init.headers as Record<string, string> | undefined) ?? {}) };
  const r = await fetch(path, { ...init, headers });
  if (!r.ok) {
    let msg = `Request failed (${r.status})`;
    try { const j = (await r.json()) as { message?: string }; if (j.message) msg = j.message; } catch { /* no JSON body */ }
    throw new Error(r.status === 401 ? "Not signed in" : msg);
  }
  return (await r.json()) as T;
}
export const errText = (e: unknown): string => (e instanceof Error ? e.message : "Unexpected error");
export const JSON_HEADERS = { "Content-Type": "application/json" };

/** CSV cell escaping with formula-injection protection (text that starts with = + - @ gets a leading apostrophe). */
export function csvCell(v: unknown): string {
  let s = v === null || v === undefined ? "" : String(v);
  if (typeof v !== "number" && /^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return `"${s.replace(/"/g, '""')}"`;
}
export function downloadCsv(name: string, header: string[], rows: unknown[][]): void {
  const text = [header, ...rows].map(r => r.map(csvCell).join(",")).join("\r\n");
  const url = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
  const a = document.createElement("a"); a.href = url; a.download = name; a.click(); URL.revokeObjectURL(url);
}
