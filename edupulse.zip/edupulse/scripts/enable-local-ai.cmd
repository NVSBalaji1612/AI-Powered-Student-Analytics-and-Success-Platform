@echo off
REM Free local Copilot: updates .env, starts the Ollama container, downloads the model once (about 2 GB), restarts the backend.
powershell -ExecutionPolicy Bypass -File scripts\set-local-ai.ps1
docker compose --profile ai up -d ollama
docker compose exec ollama ollama pull llama3.2:3b
docker compose up -d backend
echo.
echo Done. Sign in as the Super Admin, open "AI Copilot settings" and click Test connection.
