@echo off
REM Creates .env with demo values if it does not exist. Run from the project root.
if exist .env (
  echo .env already exists - leaving it unchanged.
) else (
  (
    echo MYSQL_ROOT_PASSWORD=RootPass2026Edu
    echo MYSQL_PASSWORD=EduDbPass2026
    echo JWT_OR_SESSION_SECRET=SessionSecret2026Edu
    echo LLM_PROVIDER=disabled
    echo LLM_API_KEY=
    echo DEMO_USERS_ENABLED=true
    echo DEMO_PASSWORD=DemoLogin2026Edu
  ) > .env
  echo Created .env with DEMO values. Change them for anything beyond local demos.
)
