@echo off
REM Deletes the demo database and rebuilds everything (use after updating database files).
docker compose down -v
call scripts\make-env.cmd
docker compose up --build -d
