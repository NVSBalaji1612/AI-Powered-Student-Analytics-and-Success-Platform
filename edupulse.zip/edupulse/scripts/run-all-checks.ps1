# EduPulse AI - run all checks. Usage (from project root):  powershell -ExecutionPolicy Bypass -File scripts\run-all-checks.ps1
# Requires: Docker stack running (docker compose up -d), Python venv in ai-service\.venv, Maven, Node.
$ErrorActionPreference = "Continue"
$root = Split-Path -Parent $PSScriptRoot
$results = @()
function Record($name, $ok, $detail) { $script:results += [pscustomobject]@{ Check = $name; Result = $(if ($ok) { "PASS" } else { "FAIL" }); Detail = $detail } }

# 1. AI service unit tests
Push-Location "$root\ai-service"
$py = if (Test-Path ".venv\Scripts\python.exe") { ".venv\Scripts\python.exe" } else { Write-Host "NOTE: ai-service\.venv not found; create it (see docs/TESTING.md)" -ForegroundColor Yellow; "python" }
$out = & $py -m pytest -q 2>&1 | Out-String
Record "AI service pytest" ($LASTEXITCODE -eq 0) (($out -split "`n" | Where-Object { $_ -match "passed|failed|error" } | Select-Object -Last 1))
Pop-Location

# 2. Backend unit tests
Push-Location "$root\backend"
$out = & mvn -q test 2>&1 | Out-String
Record "Backend mvn test" ($LASTEXITCODE -eq 0) $(if ($LASTEXITCODE -eq 0) { "TenantGuardTest passed" } else { "see mvn output" })
Pop-Location

# 3. Frontend type-check and build
Push-Location "$root\frontend"
if (-not (Test-Path node_modules)) { npm install --silent 2>&1 | Out-Null }
$out = & npm run build 2>&1 | Out-String
Record "Frontend tsc + build" ($LASTEXITCODE -eq 0) $(if ($LASTEXITCODE -eq 0) { "built" } else { "see npm output" })
Pop-Location

# 4. Live API checks against the running stack
$pw = ((Get-Content "$root\.env" | Where-Object { $_ -like "DEMO_PASSWORD=*" }) -replace "DEMO_PASSWORD=", "").Trim()
function Auth($u) { "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("${u}:$pw")) }
function Call($path, $user) {
  $h = @{}; if ($user) { $h["Authorization"] = Auth $user }
  try { $r = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:8081$path" -Headers $h; return @{ Code = [int]$r.StatusCode; Body = $(if ($r.Content -is [byte[]]) { [Text.Encoding]::UTF8.GetString($r.Content) } else { $r.Content }) } }
  catch { $c = 0; if ($_.Exception.Response) { $c = [int]$_.Exception.Response.StatusCode }; return @{ Code = $c; Body = "" } }
}
$r = Call "/actuator/health" $null;                      Record "Health endpoint UP" ($r.Code -eq 200 -and $r.Body -match "UP") "HTTP $($r.Code)"
$r = Call "/api/v1/students" $null;                      Record "Unauthenticated request rejected" ($r.Code -eq 401) "HTTP $($r.Code)"
$r = Call "/api/v1/students?size=50" "admin@inst-a.demo"
$a = @(); if ($r.Code -eq 200) { $a = ($r.Body | ConvertFrom-Json).content }
Record "Institution A sees only its 10 students" ($a.Count -eq 10 -and -not ($a | Where-Object { $_.studentCode -notlike "A-*" })) "count=$($a.Count)"
$r = Call "/api/v1/students?size=50" "admin@inst-b.demo"
$b = @(); if ($r.Code -eq 200) { $b = ($r.Body | ConvertFrom-Json).content }
Record "Institution B sees only its 10 students" ($b.Count -eq 10 -and -not ($b | Where-Object { $_.studentCode -notlike "B-*" })) "count=$($b.Count)"
$r = Call "/api/v1/students/15" "admin@inst-a.demo";     Record "Cross-tenant student lookup returns 404" ($r.Code -eq 404) "HTTP $($r.Code)"
$r = Call "/api/v1/students/15/summary" "admin@inst-a.demo"; Record "Cross-tenant summary returns 404" ($r.Code -eq 404) "HTTP $($r.Code)"
$r = Call "/api/v1/students/3/summary" "admin@inst-a.demo"
$ok = $false; if ($r.Code -eq 200) { $s = $r.Body | ConvertFrom-Json; $ok = ($s.overallAttendancePercent -lt 80) }
Record "Struggling student A-003 shows low attendance" $ok "HTTP $($r.Code)"
$r = Call "/api/v1/students/1/summary" "admin@inst-a.demo"
$ok = $false; if ($r.Code -eq 200) { $s = $r.Body | ConvertFrom-Json; $ok = ($s.overallAttendancePercent -ge 80) }
Record "Typical student A-001 shows healthy attendance" $ok "HTTP $($r.Code)"
$r = Call "/api/v1/students/1/summary" "admin@inst-a.demo"
$ok = $false; if ($r.Code -eq 200) { $s = $r.Body | ConvertFrom-Json; $ok = -not ($s.results | Where-Object { $_.status -ne "SCORED" -and $null -ne $_.marks }) }
Record "Missing/withdrawn marks never counted as zero" $ok "A-001 results"

# Stage 2: analytics
$r = Call "/api/v1/analytics/overview" "admin@inst-a.demo"
$o = $null; if ($r.Code -eq 200) { $o = $r.Body | ConvertFrom-Json }
Record "Analytics: A overview has 10 students and 3 subjects" ($o -and $o.activeStudents -eq 10 -and @($o.bySubject).Count -eq 3) "HTTP $($r.Code)"
Record "Analytics: attendance and score are valid percentages" ($o -and $o.attendancePercent -gt 0 -and $o.attendancePercent -le 100 -and $o.averageScorePercent -gt 0 -and $o.averageScorePercent -le 100) "att=$($o.attendancePercent) score=$($o.averageScorePercent)"
Record "Analytics: department groups of 3+ students are shown" ($o -and @($o.byDepartment).Count -gt 0 -and -not (@($o.byDepartment) | Where-Object { $_.suppressed })) "departments=$(@($o.byDepartment).Count)"
$r = Call "/api/v1/analytics/overview" $null; Record "Analytics requires login" ($r.Code -eq 401) "HTTP $($r.Code)"
# Stage 3: predictions from real stored records
$r = Call "/api/v1/risk/overview" "admin@inst-a.demo"
$rk = @(); if ($r.Code -eq 200) { $t = ConvertFrom-Json $r.Body; $rk = @($t | Sort-Object probability -Descending) }
$top3 = @($rk | Select-Object -First 3 | ForEach-Object { $_.studentCode })
Record "Risk overview: 10 students, A-003 and A-007 rank in top 3" ($rk.Count -eq 10 -and ($top3 -contains "A-003") -and ($top3 -contains "A-007")) "top3=$($top3 -join ',')"
$r = Call "/api/v1/risk/overview" "admin@inst-b.demo"
$rb = @(); if ($r.Code -eq 200) { $t = ConvertFrom-Json $r.Body; $rb = @($t) }
Record "Risk overview: B sees only B students" ($rb.Count -eq 10 -and -not ($rb | Where-Object { $_.studentCode -notlike "B-*" })) "count=$($rb.Count)"
$r3 = Call "/api/v1/students/3/prediction" "admin@inst-a.demo"; $r1 = Call "/api/v1/students/1/prediction" "admin@inst-a.demo"
$p3 = $null; $p1 = $null
if ($r3.Code -eq 200) { $p3 = $r3.Body | ConvertFrom-Json }
if ($r1.Code -eq 200) { $p1 = $r1.Body | ConvertFrom-Json }
Record "Prediction: A-003 risk higher than A-001" ($p3 -and $p1 -and $p3.prediction.probability -gt $p1.prediction.probability) "A-003=$($p3.prediction.probability) A-001=$($p1.prediction.probability)"
Record "Prediction: missing assignment data reported, not invented" ($p3 -and ($p3.prediction.missing_inputs -contains "assignment_completion")) "missing_inputs checked"
$r = Call "/api/v1/students/15/prediction" "admin@inst-a.demo"; Record "Prediction: cross-tenant returns 404" ($r.Code -eq 404) "HTTP $($r.Code)"

# ---------- Stages 4-6 helpers ----------
$UA = "admin@inst-a.demo"; $UB = "admin@inst-b.demo"
function Txt($c) { if ($c -is [byte[]]) { [Text.Encoding]::UTF8.GetString($c) } else { $c } }
function Send($method, $path, $user, $obj) {
  $h = @{}; if ($user) { $h["Authorization"] = Auth $user }
  $body = "{}"; if ($null -ne $obj) { $body = $obj | ConvertTo-Json -Compress }
  try { $r = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:8081$path" -Method $method -Headers $h -ContentType "application/json" -Body $body; return @{ Code = [int]$r.StatusCode; Body = (Txt $r.Content) } }
  catch { $c = 0; if ($_.Exception.Response) { $c = [int]$_.Exception.Response.StatusCode }; return @{ Code = $c; Body = "" } }
}
function Upload($path, $user, $file, $fields) {
  $out = Join-Path $env:TEMP "edupulse_resp.txt"; if (Test-Path $out) { Remove-Item $out }
  $cmd = @("-s", "-o", $out, "-w", '%{http_code}')
  if ($user) { $cmd += @("-u", "${user}:$pw") }
  $cmd += @("-F", "file=@$file")
  foreach ($f in $fields) { $cmd += @("-F", $f) }
  $code = & curl.exe @cmd "http://localhost:8081$path"
  $body = ""; if (Test-Path $out) { $body = Get-Content $out -Raw }
  return @{ Code = [int]$code; Body = $body }
}

# Stage 4: interventions (human review, follow-up, outcome)
$r = Send "Post" "/api/v1/interventions" $UA @{ studentId = 3; reason = "Automated check: risk signal review" }
$caseId = $null
if ($r.Code -eq 200) { $caseId = (ConvertFrom-Json $r.Body).info.id }
elseif ($r.Code -eq 409) { $l = ConvertFrom-Json (Call "/api/v1/interventions" $UA).Body; $caseId = @($l | Where-Object { $_.studentCode -eq "A-003" -and $_.status -ne "RESOLVED" })[0].id }
Record "Cases: create (or reuse) a case for A-003" ($null -ne $caseId) "caseId=$caseId"
if ($caseId) {
  $cb = Call "/api/v1/interventions/$caseId" $UB;  Record "Cases: other institution cannot open the case" ($cb.Code -eq 404) "HTTP $($cb.Code)"
  $cn = Send "Post" "/api/v1/interventions/$caseId/transition" $UA @{ to = "NEW" }; Record "Cases: invalid transition rejected with 409" ($cn.Code -eq 409) "HTTP $($cn.Code)"
  $next = @{ NEW = "REVIEWED"; REVIEWED = "ASSIGNED"; ASSIGNED = "IN_PROGRESS"; IN_PROGRESS = "FOLLOW_UP" }
  $status = (ConvertFrom-Json (Call "/api/v1/interventions/$caseId" $UA).Body).info.status; $guard = 0
  while ($status -ne "FOLLOW_UP" -and $status -ne "RESOLVED" -and $guard -lt 6) {
    $t = Send "Post" "/api/v1/interventions/$caseId/transition" $UA @{ to = $next[$status] }
    if ($t.Code -ne 200) { break }
    $status = (ConvertFrom-Json $t.Body).info.status; $guard++
  }
  Record "Cases: workflow reaches FOLLOW_UP in order" ($status -eq "FOLLOW_UP") "status=$status"
  $ca = Send "Post" "/api/v1/interventions/$caseId/actions" $UA @{ type = "FOLLOW_UP_MEETING"; note = "Automated check"; dueDate = "2026-12-31" }
  $actId = $null; if ($ca.Code -eq 200) { $actId = @((ConvertFrom-Json $ca.Body).actions)[-1].id }
  $cc = $null; if ($actId) { $cc = Send "Post" "/api/v1/interventions/$caseId/actions/$actId/complete" $UA $null }
  Record "Cases: follow-up action added and completed" ($ca.Code -eq 200 -and $cc -and $cc.Code -eq 200 -and (@((ConvertFrom-Json $cc.Body).actions) | Where-Object { $_.id -eq $actId }).status -eq "DONE") "action=$actId"
  $rn = Send "Post" "/api/v1/interventions/$caseId/transition" $UA @{ to = "RESOLVED" }; Record "Cases: resolving without a note is rejected (400)" ($rn.Code -eq 400) "HTTP $($rn.Code)"
  $rr = Send "Post" "/api/v1/interventions/$caseId/transition" $UA @{ to = "RESOLVED"; note = "Automated check: resolved" }
  $fin = $null; if ($rr.Code -eq 200) { $fin = (ConvertFrom-Json $rr.Body).info }
  Record "Cases: resolved with before/after outcome measured" ($fin -and $fin.status -eq "RESOLVED" -and $null -ne $fin.closeAttendance -and $null -ne $fin.openAttendance) "close_att=$($fin.closeAttendance)"
}
$m = Call "/api/v1/interventions/metrics" $UA; $mj = $null; if ($m.Code -eq 200) { $mj = ConvertFrom-Json $m.Body }
Record "Cases: outcome metrics show a resolved case" ($mj -and $mj.byStatus.RESOLVED -ge 1) "resolved=$($mj.byStatus.RESOLVED)"
$cl = Call "/api/v1/interventions" $UB; Record "Cases: institution B sees none of A's cases" ($cl.Code -eq 200 -and $cl.Body.Trim() -eq "[]") "HTTP $($cl.Code)"
$rc = Call "/api/v1/students/3/recommendations" $UA; $rcj = @(); if ($rc.Code -eq 200) { $rcj = ConvertFrom-Json $rc.Body }
Record "Recommendations: A-003 gets an attendance conversation rule" (@($rcj | Where-Object { $_.type -eq "ATTENDANCE_DISCUSSION" }).Count -ge 1) "rules=$(@($rcj).Count)"

# Stage 5: CSV import (preview is read-only; commit is tested with an all-invalid file so no data changes)
$tmp = Join-Path $env:TEMP "edupulse_import_test.csv"; $newCode = "T" + (Get-Date -Format "MMddHHmmss")
@("student_code,full_name,department", "$newCode,Import Test Student,Mathematics", "A-001,Duplicate Of Existing,Mathematics", "A-777,=cmd|calc,Mathematics") | Set-Content -Encoding ascii $tmp
$tpl = Call "/api/v1/imports/students/template" $UA; Record "Import: template downloads with the correct header" ($tpl.Code -eq 200 -and $tpl.Body -match "student_code,full_name,department") "HTTP $($tpl.Code)"
$pv = Upload "/api/v1/imports/students/preview" $UA $tmp @(); $pj = $null; if ($pv.Code -eq 200) { $pj = ConvertFrom-Json $pv.Body }
Record "Import: preview counts 3 rows, 1 valid, 2 rejected" ($pj -and $pj.rowsTotal -eq 3 -and $pj.validRows -eq 1 -and $pj.rejectedRows -eq 2) "HTTP $($pv.Code)"
Record "Import: duplicate and formula-injection rows are flagged" ($pj -and (@($pj.errors | Where-Object { $_.message -like "*already exists*" }).Count -eq 1) -and (@($pj.errors | Where-Object { $_.message -like "*formula*" }).Count -eq 1)) "errors listed"
$bad = Join-Path $env:TEMP "edupulse_import_bad.csv"; @("student_code,full_name,department", "A-001,Duplicate Of Existing,Mathematics") | Set-Content -Encoding ascii $bad
$cm = Upload "/api/v1/imports/students/commit" $UA $bad @(); $cj = $null; if ($cm.Code -eq 200) { $cj = ConvertFrom-Json $cm.Body }
Record "Import: commit never overwrites existing students" ($cj -and $cj.imported -eq 0 -and $cj.rejected -eq 1) "HTTP $($cm.Code)"
$nu = Upload "/api/v1/imports/students/preview" $null $tmp @(); Record "Import: requires login" ($nu.Code -eq 401) "HTTP $($nu.Code)"

# Stage 6: knowledge base and Copilot
$ask = Send "Post" "/api/v1/copilot/ask" $UA @{ question = "What is the attendance policy?" }; $aj = $null; if ($ask.Code -eq 200) { $aj = ConvertFrom-Json $ask.Body }
Record "Copilot: A gets A's policy passages and verified data" ($aj -and @($aj.evidence).Count -ge 3 -and @($aj.sources | Where-Object { $_.documentTitle -like "*Institution A*" }).Count -ge 1) "mode=$($aj.mode)"
$askb = Send "Post" "/api/v1/copilot/ask" $UB @{ question = "What is the attendance policy?" }; $bj = $null; if ($askb.Code -eq 200) { $bj = ConvertFrom-Json $askb.Body }
Record "Copilot: B never receives A's documents" ($bj -and @($bj.sources).Count -ge 1 -and @($bj.sources | Where-Object { $_.documentTitle -like "*Institution A*" }).Count -eq 0) "B sources=$(@($bj.sources).Count)"
$doc = Join-Path $env:TEMP "edupulse_zebra.txt"; "Zebra Submission Policy`r`n`r`nStudents must hand in zebra forms before Friday noon." | Set-Content -Encoding ascii $doc
$up = Upload "/api/v1/documents" $UA $doc @("title=EduPulse Zebra Test Doc"); $uj = $null; if ($up.Code -eq 200) { $uj = ConvertFrom-Json $up.Body }
Record "Documents: upload is chunked and stored" ($uj -and $uj.chunks -ge 1) "HTTP $($up.Code)"
$za = Send "Post" "/api/v1/copilot/ask" $UA @{ question = "What is the zebra forms policy?" }; $zj = $null; if ($za.Code -eq 200) { $zj = ConvertFrom-Json $za.Body }
Record "Copilot: retrieval finds the uploaded document" ($zj -and @($zj.sources | Where-Object { $_.documentTitle -like "*Zebra*" }).Count -ge 1) "sources=$(@($zj.sources).Count)"
$zb = Send "Post" "/api/v1/copilot/ask" $UB @{ question = "What is the zebra forms policy?" }; $zbj = $null; if ($zb.Code -eq 200) { $zbj = ConvertFrom-Json $zb.Body }
Record "Copilot: B cannot retrieve A's new document" ($zbj -and @($zbj.sources | Where-Object { $_.documentTitle -like "*Zebra*" }).Count -eq 0) "HTTP $($zb.Code)"
if ($uj) {
  $d1 = Send "Delete" "/api/v1/documents/$($uj.id)" $UB $null; Record "Documents: other institution cannot delete it (404)" ($d1.Code -eq 404) "HTTP $($d1.Code)"
  $d2 = Send "Delete" "/api/v1/documents/$($uj.id)" $UA $null; Record "Documents: owner can delete it" ($d2.Code -eq 200) "HTTP $($d2.Code)"
}
$na = Send "Post" "/api/v1/copilot/ask" $null @{ question = "hello there" }; Record "Copilot: requires login" ($na.Code -eq 401) "HTTP $($na.Code)"


# ---------- Stage 7: Student Success Score, segments, explainability, data quality ----------
function SegOf($j, $code) { (@($j.students) | Where-Object { $_.code -eq $code }).segment }
$so = Call "/api/v1/success/overview" $UA; $sj = $null; if ($so.Code -eq 200) { $sj = ConvertFrom-Json $so.Body }
$wsum = 0; if ($sj) { foreach ($w in @($sj.method.weights)) { $wsum += $w.weight } }
Record "Success score: 10 students, every score 0-100, weights sum to 1" ($sj -and $sj.summary.students -eq 10 -and -not (@($sj.students) | Where-Object { $_.successScore -lt 0 -or $_.successScore -gt 100 }) -and [math]::Abs($wsum - 1) -lt 0.0001) "students=$($sj.summary.students) weights=$wsum"
$g1 = SegOf $sj "A-001"; $g3 = SegOf $sj "A-003"; $g4 = SegOf $sj "A-004"; $g7 = SegOf $sj "A-007"; $g8 = SegOf $sj "A-008"
Record "Segments: star, high-academic/low-placement, placement-ready/academic-risk, holistic, disengaged" ($g1 -eq "STAR_PERFORMER" -and $g4 -eq "HIGH_ACADEMIC_LOW_PLACEMENT" -and $g3 -eq "PLACEMENT_READY_ACADEMIC_RISK" -and $g7 -eq "NEEDS_HOLISTIC_SUPPORT" -and $g8 -eq "DISENGAGED") "A-001=$g1 A-003=$g3 A-004=$g4 A-007=$g7 A-008=$g8"
$sbo = Call "/api/v1/success/overview" $UB; $sbj = $null; if ($sbo.Code -eq 200) { $sbj = ConvertFrom-Json $sbo.Body }
Record "Success score: institution B sees only its own 10 students" ($sbj -and $sbj.summary.students -eq 10 -and -not (@($sbj.students) | Where-Object { $_.code -notlike "B-*" })) "B students=$($sbj.summary.students)"
$b13 = $null; if ($sbj) { $b13 = @($sbj.students) | Where-Object { $_.code -eq "B-003" } }
Record "Missing placement data gives UNKNOWN risk and lower completeness (not zero)" ($b13 -and $b13.placementRisk -eq "UNKNOWN" -and $b13.completeness -lt 100) "B-003 completeness=$($b13.completeness)"
$dp = Call "/api/v1/success/overview?department=Mathematics" $UA; $dj = $null; if ($dp.Code -eq 200) { $dj = ConvertFrom-Json $dp.Body }
Record "Department filter returns only that department" ($dj -and @($dj.students).Count -gt 0 -and @($dj.students).Count -lt 10 -and -not (@($dj.students) | Where-Object { $_.department -ne "Mathematics" })) "rows=$(@($dj.students).Count)"
$sg = Call "/api/v1/success/overview?segment=STAR_PERFORMER" $UA; $sgj = $null; if ($sg.Code -eq 200) { $sgj = ConvertFrom-Json $sg.Body }
Record "Segment filter returns only that segment" ($sgj -and @($sgj.students).Count -ge 1 -and -not (@($sgj.students) | Where-Object { $_.segment -ne "STAR_PERFORMER" })) "rows=$(@($sgj.students).Count)"
$ex = Call "/api/v1/success/students/4" $UA; $exj = $null; if ($ex.Code -eq 200) { $exj = ConvertFrom-Json $ex.Body }
$ptsum = 0; if ($exj) { $ptsum = ($exj.drivers | Measure-Object -Property points -Sum).Sum }
Record "Explainable score: driver points add up to the Success Score" ($exj -and @($exj.drivers).Count -ge 5 -and [math]::Abs($ptsum - $exj.row.successScore) -lt 0.7) "sum=$ptsum score=$($exj.row.successScore)"
$low2 = @(); if ($exj) { $low2 = @($exj.drivers | Select-Object -First 2 | ForEach-Object { $_.code }) }
Record "Explainable score: A-004's weakest drivers include placement readiness" ($low2 -contains "PLACEMENT_READINESS") "weakest=$($low2 -join ',')"
$mx = Call "/api/v1/success/students/13" $UB; $mxj = $null; if ($mx.Code -eq 200) { $mxj = ConvertFrom-Json $mx.Body }
Record "Explainable score: missing indicators are listed, not hidden" ($mxj -and (@($mxj.missingComponents) -contains "Placement readiness")) "B-003 missing listed"
$cx = Call "/api/v1/success/students/15" $UA; Record "Success detail: cross-tenant student returns 404" ($cx.Code -eq 404) "HTTP $($cx.Code)"
$qd = Call "/api/v1/success/data-quality" $UA; $qdj = @(); if ($qd.Code -eq 200) { $qdj = ConvertFrom-Json $qd.Body }
$fbq = @($qdj | Where-Object { $_.source -eq "Feedback" })[0]
Record "Data quality: 8 sources reported and gaps visible (feedback below 100%)" (@($qdj).Count -eq 8 -and $fbq -and $fbq.coveragePercent -lt 100) "sources=$(@($qdj).Count) feedback=$($fbq.coveragePercent)"
$nu2 = Call "/api/v1/success/overview" $null; Record "Success overview requires login" ($nu2.Code -eq 401) "HTTP $($nu2.Code)"


# ---------- Stage 8: roles, lockout, audit, governance, other-source imports ----------
$UF = "faculty@inst-a.demo"; $UAU = "auditor@inst-a.demo"
function MeCode($user, $pass) {
  $h = @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("${user}:$pass")) }
  try { $r = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:8081/api/v1/me" -Headers $h; return [int]$r.StatusCode }
  catch { if ($_.Exception.Response) { return [int]$_.Exception.Response.StatusCode } else { return 0 } }
}
$me1 = Call "/api/v1/me" $UA; $mj1 = $null; if ($me1.Code -eq 200) { $mj1 = ConvertFrom-Json $me1.Body }
$me2 = Call "/api/v1/me" $UF; $mj2 = $null; if ($me2.Code -eq 200) { $mj2 = ConvertFrom-Json $me2.Body }
Record "Roles: /me reports the database role and institution" ($mj1 -and $mj1.role -eq "INSTITUTION_ADMIN" -and $mj1.institutionId -eq 1 -and $mj2 -and $mj2.role -eq "FACULTY") "admin=$($mj1.role) faculty=$($mj2.role)"
$f1 = Call "/api/v1/success/overview" $UF; Record "Roles: faculty can read the success dashboard" ($f1.Code -eq 200) "HTTP $($f1.Code)"
$f2 = Upload "/api/v1/imports/students/preview" $UF $tmp @(); Record "Roles: faculty cannot import data (403)" ($f2.Code -eq 403) "HTTP $($f2.Code)"
$f3 = Call "/api/v1/audit/events" $UF; Record "Roles: faculty cannot read the audit log (403)" ($f3.Code -eq 403) "HTTP $($f3.Code)"
$f4 = Call "/api/v1/governance/model" $UF; Record "Roles: faculty cannot open model governance (403)" ($f4.Code -eq 403) "HTTP $($f4.Code)"
$a1 = Call "/api/v1/audit/events" $UAU; $a2 = Call "/api/v1/students" $UAU
Record "Roles: auditor can read audit events but not student records" ($a1.Code -eq 200 -and $a2.Code -eq 403) "audit=$($a1.Code) students=$($a2.Code)"
1..5 | ForEach-Object { [void](MeCode "locktest@inst-a.demo" "wrong-password-$_") }
$lk = MeCode "locktest@inst-a.demo" $pw
Record "Security: 5 bad passwords lock the account even for the right password" ($lk -eq 401) "HTTP $lk"
$ae1 = Call "/api/v1/audit/events?action=LOGIN_FAILED&limit=5" $UA; $ae2 = Call "/api/v1/audit/events?action=ACCOUNT_LOCKED&limit=5" $UA
$lf = @(); if ($ae1.Code -eq 200) { $lf = @(ConvertFrom-Json $ae1.Body) }; $lc = @(); if ($ae2.Code -eq 200) { $lc = @(ConvertFrom-Json $ae2.Body) }
Record "Audit: failed logins and the lockout are recorded" ($lf.Count -ge 1 -and $lc.Count -ge 1) "failed=$($lf.Count) locked=$($lc.Count)"
$be = Call "/api/v1/audit/events?limit=200" $UB; $bej = @(); if ($be.Code -eq 200) { $bej = @(ConvertFrom-Json $be.Body) }
Record "Audit: institution B never sees institution A's events" ($be.Code -eq 200 -and -not ($bej | Where-Object { $_.actor -like "*inst-a*" })) "B events=$($bej.Count)"
$g = Call "/api/v1/governance/model" $UA; $gj = $null; if ($g.Code -eq 200) { $gj = ConvertFrom-Json $g.Body }
Record "Governance: model card shows version, evaluation and an unapproved flag" ($gj -and $gj.model.version -and $gj.model.evaluation.baseline_logreg.roc_auc -gt 0.6 -and $gj.model.approval_status -eq "UNAPPROVED_DEMO") "version=$($gj.model.version)"
if ($gj) {
  $d = Send "Post" "/api/v1/governance/model/decision" $UA @{ modelVersion = $gj.model.version; decision = "REJECTED"; reason = "Automated check: synthetic-data demo model is not validated for real decisions" }
  $dj = $null; if ($d.Code -eq 200) { $dj = ConvertFrom-Json $d.Body }
  Record "Governance: a human decision is recorded for this model version" ($dj -and $dj.currentStatus -eq "REJECTED" -and @($dj.decisions).Count -ge 1) "HTTP $($d.Code)"
  $d2 = Send "Post" "/api/v1/governance/model/decision" $UA @{ modelVersion = $gj.model.version; decision = "APPROVED"; reason = "short" }; Record "Governance: a decision without a real reason is rejected (400)" ($d2.Code -eq 400) "HTTP $($d2.Code)"
  $d3 = Send "Post" "/api/v1/governance/model/decision" $UF @{ modelVersion = $gj.model.version; decision = "APPROVED"; reason = "Faculty should not be able to approve models" }; Record "Governance: faculty cannot approve a model (403)" ($d3.Code -eq 403) "HTTP $($d3.Code)"
  $gb = Call "/api/v1/governance/model" $UB; $gbj = $null; if ($gb.Code -eq 200) { $gbj = ConvertFrom-Json $gb.Body }
  Record "Governance: institution B's decision status is independent (UNREVIEWED)" ($gbj -and $gbj.currentStatus -eq "UNREVIEWED") "B=$($gbj.currentStatus)"
}
$pl = Join-Path $env:TEMP "edupulse_placement.csv"
@("student_code,aptitude_score,coding_score,mock_interview_score,assessed_on", "B-003,50,50,50,2026-09-20", "B-001,60,60,60,2026-09-20", "B-999,60,60,60,2026-09-20", "B-002,150,60,60,2026-09-20") | Set-Content -Encoding ascii $pl
$pp = Upload "/api/v1/imports/placement/preview" $UB $pl @(); $ppj = $null; if ($pp.Code -eq 200) { $ppj = ConvertFrom-Json $pp.Body }
Record "Import placement: preview finds 1 valid row and 3 problems (existing, unknown student, out of range)" ($ppj -and $ppj.rowsTotal -eq 4 -and $ppj.validRows -eq 1 -and $ppj.rejectedRows -eq 3) "HTTP $($pp.Code)"
$fbf = Join-Path $env:TEMP "edupulse_feedback.csv"
@("student_code,satisfaction,faculty_feedback,recorded_on", "A-009,4.0,4.0,2026-10-02", "A-001,4.0,4.0,2026-10-01", "A-002,6,4,2026-10-02") | Set-Content -Encoding ascii $fbf
$fp = Upload "/api/v1/imports/feedback/preview" $UA $fbf @(); $fpj = $null; if ($fp.Code -eq 200) { $fpj = ConvertFrom-Json $fp.Body }
Record "Import feedback: preview finds 1 valid row, 1 duplicate and 1 out-of-range rating" ($fpj -and $fpj.rowsTotal -eq 3 -and $fpj.validRows -eq 1 -and $fpj.rejectedRows -eq 2) "HTTP $($fp.Code)"
$lt = Call "/api/v1/imports/lms/template" $UA; Record "Import: LMS template has the right header" ($lt.Code -eq 200 -and $lt.Body -match "student_code,week_start,logins") "HTTP $($lt.Code)"
$us = Call "/api/v1/imports/unknown/template" $UA; Record "Import: unknown source returns 404" ($us.Code -eq 404) "HTTP $($us.Code)"


# ---------- Phase 1 upgrade: user administration, password change, AI settings ----------
function CallAs($path, $user, $pass) {
  $h = @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("${user}:$pass")) }
  try { $r = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:8081$path" -Headers $h; return @{ Code = [int]$r.StatusCode; Body = (Txt $r.Content) } }
  catch { $c = 0; if ($_.Exception.Response) { $c = [int]$_.Exception.Response.StatusCode }; return @{ Code = $c; Body = "" } }
}
function SendAs($method, $path, $user, $pass, $obj) {
  $h = @{ Authorization = "Basic " + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes("${user}:$pass")) }
  try { $r = Invoke-WebRequest -UseBasicParsing -Uri "http://localhost:8081$path" -Method $method -Headers $h -ContentType "application/json" -Body ($obj | ConvertTo-Json -Compress); return @{ Code = [int]$r.StatusCode; Body = (Txt $r.Content) } }
  catch { $c = 0; if ($_.Exception.Response) { $c = [int]$_.Exception.Response.StatusCode }; return @{ Code = $c; Body = "" } }
}
$stamp = Get-Date -Format "MMddHHmmss"; $tmpEmail = "temp.$stamp@inst-a.demo"; $tmpPw = "Temp-Pass-2026-Xy"
$x1 = Call "/api/v1/admin/users" $UF; $x2 = Call "/api/v1/admin/users" $UAU
Record "Admin API: faculty and auditor cannot manage users (403)" ($x1.Code -eq 403 -and $x2.Code -eq 403) "faculty=$($x1.Code) auditor=$($x2.Code)"
$ul = Call "/api/v1/admin/users?size=100" $UA; $ulj = $null; if ($ul.Code -eq 200) { $ulj = ConvertFrom-Json $ul.Body }
Record "Admin API: user list shows only this institution's users" ($ulj -and @($ulj.content).Count -ge 4 -and -not (@($ulj.content) | Where-Object { $_.email -like "*inst-b*" })) "users=$(@($ulj.content).Count)"
$adminId = $null; if ($ulj) { $adminId = (@($ulj.content) | Where-Object { $_.email -eq $UA })[0].id }
$c1 = SendAs "Post" "/api/v1/admin/users" $UA $pw @{ email = $tmpEmail; fullName = "Temp User"; role = "FACULTY"; password = $tmpPw }
$c1j = $null; if ($c1.Code -eq 200) { $c1j = ConvertFrom-Json $c1.Body }
Record "Admin API: Super Admin can create a user" ($c1j -and $c1j.role -eq "FACULTY" -and $c1j.active) "HTTP $($c1.Code)"
$c2 = SendAs "Post" "/api/v1/admin/users" $UA $pw @{ email = "weak.$stamp@inst-a.demo"; role = "FACULTY"; password = "short1" }
$c3 = SendAs "Post" "/api/v1/admin/users" $UA $pw @{ email = "plat.$stamp@inst-a.demo"; role = "PLATFORM_ADMIN"; password = $tmpPw }
$c4 = SendAs "Post" "/api/v1/admin/users" $UA $pw @{ email = $tmpEmail; role = "FACULTY"; password = $tmpPw }
Record "Admin API: weak password 400, forbidden role 400, duplicate email 409" ($c2.Code -eq 400 -and $c3.Code -eq 400 -and $c4.Code -eq 409) "weak=$($c2.Code) role=$($c3.Code) dup=$($c4.Code)"
$m1 = CallAs "/api/v1/me" $tmpEmail $tmpPw; $m1j = $null; if ($m1.Code -eq 200) { $m1j = ConvertFrom-Json $m1.Body }
Record "Admin API: the new user can sign in with the assigned role" ($m1j -and $m1j.role -eq "FACULTY") "HTTP $($m1.Code)"
$s1 = SendAs "Put" "/api/v1/admin/users/$adminId" $UA $pw @{ role = "FACULTY" }; $s2 = SendAs "Put" "/api/v1/admin/users/$adminId" $UA $pw @{ active = $false }
Record "Safeguard: a Super Admin cannot demote or deactivate themselves (409)" ($s1.Code -eq 409 -and $s2.Code -eq 409) "role=$($s1.Code) status=$($s2.Code)"
$newId = $null; if ($c1j) { $newId = $c1j.id }
$r1 = $null; if ($newId) { $r1 = SendAs "Put" "/api/v1/admin/users/$newId" $UA $pw @{ role = "STUDENT" } }
$st1 = CallAs "/api/v1/students" $tmpEmail $tmpPw; $st2 = CallAs "/api/v1/me" $tmpEmail $tmpPw
Record "Roles: a user changed to STUDENT loses staff access but can still sign in" ($r1 -and $r1.Code -eq 200 -and $st1.Code -eq 403 -and $st2.Code -eq 200) "students=$($st1.Code) me=$($st2.Code)"
$xb = $null; if ($newId) { $xb = SendAs "Put" "/api/v1/admin/users/$newId" $UB $pw @{ active = $false } }
Record "Isolation: institution B's admin cannot modify institution A's user (404)" ($xb -and $xb.Code -eq 404) "HTTP $(if ($xb) { $xb.Code })"
$d1 = $null; if ($newId) { $d1 = SendAs "Put" "/api/v1/admin/users/$newId" $UA $pw @{ active = $false } }
$lg = CallAs "/api/v1/me" $tmpEmail $tmpPw
Record "Admin API: a deactivated user can no longer sign in" ($d1 -and $d1.Code -eq 200 -and $lg.Code -eq 401) "login=$($lg.Code)"
$del = $null; if ($newId) { $del = SendAs "Delete" "/api/v1/admin/users/$newId" $UA $pw $null; $del2 = SendAs "Delete" "/api/v1/admin/users/$newId" $UA $pw $null }
Record "Admin API: delete is soft (hidden afterwards, second delete returns 404)" ($del -and $del.Code -eq 200 -and $del2.Code -eq 404) "first=$($del.Code) second=$($del2.Code)"
$tmp2 = "temp2.$stamp@inst-a.demo"; $pw1 = "Temp-Pass-2026-Xy"; $pw2 = "Another-Pass-2027-Zq"
$e1 = SendAs "Post" "/api/v1/admin/users" $UA $pw @{ email = $tmp2; role = "AUDITOR"; password = $pw1 }; $e1j = $null; if ($e1.Code -eq 200) { $e1j = ConvertFrom-Json $e1.Body }
$p1 = SendAs "Post" "/api/v1/me/password" $tmp2 $pw1 @{ currentPassword = "wrong-current-1A"; newPassword = $pw2 }
$p2 = SendAs "Post" "/api/v1/me/password" $tmp2 $pw1 @{ currentPassword = $pw1; newPassword = "weak" }
$p3 = SendAs "Post" "/api/v1/me/password" $tmp2 $pw1 @{ currentPassword = $pw1; newPassword = $pw2 }
$o1 = CallAs "/api/v1/me" $tmp2 $pw1; $o2 = CallAs "/api/v1/me" $tmp2 $pw2
Record "Password change: wrong current 400, weak new 400, success 200, old password stops working" ($p1.Code -eq 400 -and $p2.Code -eq 400 -and $p3.Code -eq 200 -and $o1.Code -eq 401 -and $o2.Code -eq 200) "wrong=$($p1.Code) weak=$($p2.Code) ok=$($p3.Code) old=$($o1.Code) new=$($o2.Code)"
if ($e1j) { [void](SendAs "Delete" "/api/v1/admin/users/$($e1j.id)" $UA $pw $null) }
$ai = Call "/api/v1/admin/ai/status" $UA; $aij = $null; if ($ai.Code -eq 200) { $aij = ConvertFrom-Json $ai.Body }
$ai2 = Call "/api/v1/admin/ai/status" $UF
Record "AI settings: Super Admin sees status without any key value; faculty gets 403" ($aij -and $null -ne $aij.apiKeyConfigured -and ($ai.Body -notmatch "AQ\.|AIza") -and $ai2.Code -eq 403) "enabled=$($aij.enabled) provider=$($aij.provider)"
$ae = Call "/api/v1/audit/events?action=USER_CREATED&limit=5" $UA; $aej = @(); if ($ae.Code -eq 200) { $aej = @(ConvertFrom-Json $ae.Body) }
Record "Audit: user creation is recorded" ($aej.Count -ge 1) "events=$($aej.Count)"

try { $p = Invoke-RestMethod -Uri "http://localhost:8001/health"; Record "AI service health" ($p.status -eq "UP" -and $p.model_loaded) "model_loaded=$($p.model_loaded)" } catch { Record "AI service health" $false "unreachable" }

$results | Format-Table -AutoSize
$fail = @($results | Where-Object { $_.Result -eq "FAIL" }).Count
Write-Host "`n$($results.Count - $fail) of $($results.Count) checks passed." -ForegroundColor $(if ($fail) { "Red" } else { "Green" })
