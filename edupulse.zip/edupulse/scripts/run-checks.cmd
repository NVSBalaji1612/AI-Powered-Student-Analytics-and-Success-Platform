@echo off
powershell -ExecutionPolicy Bypass -File scripts\run-all-checks.ps1
