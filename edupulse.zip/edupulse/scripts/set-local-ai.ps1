# Switches the Copilot to the local Ollama container and removes any hosted-provider key from .env.
$p = Join-Path (Split-Path -Parent $PSScriptRoot) ".env"
$keep = @(); if (Test-Path $p) { $keep = @(Get-Content $p | Where-Object { $_ -notmatch '^\s*LLM_' }) }
$keep += @("LLM_PROVIDER=openai-compatible", "LLM_BASE_URL=http://ollama:11434/v1", "LLM_API_KEY=", "LLM_MODEL=llama3.2:3b")
Set-Content -Path $p -Value $keep -Encoding ascii
Write-Host "Updated .env for the local Ollama model (llama3.2:3b)."
