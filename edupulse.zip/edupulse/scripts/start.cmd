@echo off
REM Starts the whole stack. Run from the project root.
call scripts\make-env.cmd
docker compose up --build -d
echo.
echo Wait about a minute, then open http://localhost:8081/actuator/health (should show UP).
echo Frontend: cd frontend ^&^& npm install ^&^& npm run dev   then open http://localhost:5173
